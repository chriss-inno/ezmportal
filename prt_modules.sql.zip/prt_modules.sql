-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Sep 19, 2015 at 05:06 PM
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `portal`
--

-- --------------------------------------------------------

--
-- Table structure for table `prt_modules`
--

CREATE TABLE IF NOT EXISTS `prt_modules` (
`id` int(10) unsigned NOT NULL,
  `department_id` int(11) NOT NULL,
  `module_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `input_by` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `auth_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `auth_status` varchar(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'U',
  `status` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'enable',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `prt_modules`
--

INSERT INTO `prt_modules` (`id`, `department_id`, `module_name`, `description`, `input_by`, `auth_by`, `auth_status`, `status`, `created_at`, `updated_at`) VALUES
(1, 16, 'Printer', 'Printer', 'admin', '', 'U', 'enabled', '2015-09-18 12:04:07', '2015-09-18 12:04:07'),
(2, 16, 'Inward/Outward Calls', 'Inward/Outward Calls', 'admin', '', 'U', 'enabled', '2015-09-18 12:04:36', '2015-09-18 12:04:36'),
(3, 16, 'Inward/Outward Fax', 'Inward/Outward Fax', 'admin', '', 'U', 'enabled', '2015-09-18 12:04:56', '2015-09-18 12:04:56'),
(4, 16, 'Premises Maintenance/Renovation', 'Premises Maintenance/Renovation', 'admin', '', 'U', 'enabled', '2015-09-18 12:05:17', '2015-09-18 12:05:17'),
(5, 16, 'Fixed Assets', 'Fixed Assets', 'admin', '', 'U', 'enabled', '2015-09-18 12:05:36', '2015-09-18 12:05:36'),
(6, 16, 'Electricity', 'Electricity', 'admin', '', 'U', 'enabled', '2015-09-18 12:07:36', '2015-09-18 12:07:36'),
(7, 16, 'Water', 'Water', 'admin', '', 'U', 'enabled', '2015-09-18 12:07:55', '2015-09-18 12:07:55'),
(8, 16, 'Security', 'Security', 'admin', '', 'U', 'enabled', '2015-09-18 12:08:15', '2015-09-18 12:08:15'),
(9, 16, 'Archives', 'Archives', 'admin', '', 'U', 'enabled', '2015-09-18 12:08:32', '2015-09-18 12:08:32'),
(10, 16, 'Stationery', 'Stationery', 'admin', '', 'U', 'enabled', '2015-09-18 12:08:48', '2015-09-18 12:08:48'),
(11, 16, 'Printing', 'Printing', 'admin', '', 'U', 'enabled', '2015-09-18 12:09:06', '2015-09-18 12:09:06'),
(12, 16, 'Mgt &amp; AMCs / Lease Agreement', 'Mgt &amp; AMCs / Lease Agreement', 'admin', '', 'U', 'enabled', '2015-09-18 12:09:54', '2015-09-18 12:09:54'),
(13, 16, 'Mgt. Of Orders/ LPOs / Invoices', 'Mgt. Of Orders/ LPOs / Invoices', 'admin', '', 'U', 'enabled', '2015-09-18 12:10:12', '2015-09-18 12:10:12'),
(14, 16, 'TIC/TRA', 'TIC/TRA', 'admin', '', 'U', 'enabled', '2015-09-18 12:10:34', '2015-09-18 12:10:34'),
(15, 16, 'Petty Cash', 'Petty Cash', 'admin', '', 'U', 'enabled', '2015-09-18 12:10:51', '2015-09-18 12:10:51'),
(16, 16, 'Brand & Image of Bank', 'Brand & Image of Bank', 'admin', '', 'U', 'enabled', '2015-09-18 12:11:25', '2015-09-18 12:11:25'),
(17, 16, 'Liaison with Branch Managers', 'Liaison with Branch Managers', 'admin', '', 'U', 'enabled', '2015-09-18 12:11:46', '2015-09-18 12:11:46'),
(18, 16, 'Work Permits for Expatriate Staff', 'Work Permits for Expatriate Staff', 'admin', '', 'U', 'enabled', '2015-09-18 12:12:06', '2015-09-18 12:12:06'),
(19, 16, 'Reception - Visitors', 'Reception - Visitors', 'admin', '', 'U', 'enabled', '2015-09-18 12:12:22', '2015-09-18 12:12:22'),
(20, 16, 'Note Counting Machine', 'Note Counting Machine', 'admin', '', 'U', 'enabled', '2015-09-18 12:12:39', '2015-09-18 12:12:39'),
(21, 16, 'Photocopy Machine', 'Photocopy Machine', 'admin', '', 'U', 'enabled', '2015-09-18 12:12:57', '2015-09-18 12:12:57'),
(22, 16, 'Other', 'Other', 'admin', '', 'U', 'enabled', '2015-09-18 12:13:23', '2015-09-18 12:13:23'),
(23, 1, 'Flexcube', 'Flexcube', 'admin', '', 'U', 'enabled', '2015-09-18 12:31:24', '2015-09-18 12:31:24'),
(24, 1, 'Network', 'Network', 'admin', '', 'U', 'enabled', '2015-09-18 12:31:50', '2015-09-18 12:31:50'),
(25, 1, 'Software/Application', 'Software/Application', 'admin', '', 'U', 'enabled', '2015-09-18 12:32:11', '2015-09-18 12:32:11'),
(26, 1, 'Emails', 'Emails', 'admin', '', 'U', 'enabled', '2015-09-18 12:32:27', '2015-09-18 12:32:27'),
(27, 1, 'PC General', 'PC General', 'admin', '', 'U', 'enabled', '2015-09-18 12:32:48', '2015-09-18 12:32:48'),
(28, 1, 'Biometric', 'Biometric', 'admin', '', 'U', 'enabled', '2015-09-18 12:33:06', '2015-09-18 12:33:06'),
(29, 1, 'Scanner', 'Scanner', 'admin', '', 'U', 'enabled', '2015-09-18 12:33:29', '2015-09-18 12:33:29'),
(30, 1, 'Business Objects - BO', 'Business Objects - BO', 'admin', '', 'U', 'enabled', '2015-09-18 12:33:45', '2015-09-18 12:33:45'),
(31, 1, 'Black Berry Services', 'Black Berry Services', 'admin', '', 'U', 'enabled', '2015-09-18 12:34:06', '2015-09-18 12:34:06'),
(32, 1, 'SWIFT', 'SWIFT', 'admin', '', 'U', 'enabled', '2015-09-18 12:34:32', '2015-09-18 12:34:32'),
(33, 1, 'Shared Folder - S Drive', 'Shared Folder - S Drive', 'admin', '', 'U', 'enabled', '2015-09-18 12:34:52', '2015-09-18 12:34:52'),
(34, 1, 'EMS', 'EMS', 'admin', '', 'U', 'enabled', '2015-09-18 12:35:13', '2015-09-18 12:35:13'),
(35, 1, 'STP', 'STP', 'admin', '', 'U', 'enabled', '2015-09-18 12:35:28', '2015-09-18 12:35:28');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `prt_modules`
--
ALTER TABLE `prt_modules`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `prt_modules`
--
ALTER TABLE `prt_modules`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=36;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
