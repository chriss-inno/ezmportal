-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Sep 29, 2015 at 07:30 PM
-- Server version: 5.6.21
-- PHP Version: 5.5.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `portal`
--

-- --------------------------------------------------------

--
-- Table structure for table `prt_branches`
--

CREATE TABLE IF NOT EXISTS `prt_branches` (
`id` int(10) unsigned NOT NULL,
  `branch_code` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `branch_Name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `input_by` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `auth_by` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `auth_status` varchar(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'U',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `prt_branches`
--

INSERT INTO `prt_branches` (`id`, `branch_code`, `branch_Name`, `description`, `status`, `input_by`, `auth_by`, `auth_status`, `created_at`, `updated_at`) VALUES
(1, '000', 'BANK M Head Office', ' BANK M Head Office', 'enabled', 'admin', '', 'U', '2015-09-15 12:29:19', '2015-09-15 12:29:19'),
(3, '002', 'BANK M  Kisutu Money Shoppe', ' ', 'enabled', 'admin', '', 'U', '2015-09-15 12:30:04', '2015-09-15 12:30:33'),
(4, '003', 'BANK M  Uhuru Money Shoppe', ' BANK M  Uhuru Money Shoppe', 'enabled', 'admin', '', 'U', '2015-09-15 12:30:46', '2015-09-15 12:30:46'),
(5, '005', 'BANK M  Arusha Money Shoppe', ' BANK M  Arusha Money Shoppe', 'enabled', 'admin', '', 'U', '2015-09-15 12:31:12', '2015-09-15 12:31:12'),
(6, '006', 'BANK M  Mwanza Money Shoppe', ' BANK M  Mwanza Money Shoppe', 'enabled', 'admin', '', 'U', '2015-09-15 12:31:33', '2015-09-15 12:31:33');

-- --------------------------------------------------------

--
-- Table structure for table `prt_departments`
--

CREATE TABLE IF NOT EXISTS `prt_departments` (
`id` int(10) unsigned NOT NULL,
  `department_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `receive_query` int(11) NOT NULL DEFAULT '0',
  `status` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `branch_id` int(11) NOT NULL,
  `input_by` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `auth_by` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `auth_status` varchar(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'U',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `prt_departments`
--

INSERT INTO `prt_departments` (`id`, `department_name`, `description`, `receive_query`, `status`, `branch_id`, `input_by`, `auth_by`, `auth_status`, `created_at`, `updated_at`) VALUES
(1, 'ICT  ', 'ICT  HQ', 1, 'enabled', 1, 'admin', '', 'U', '2015-09-15 12:42:45', '2015-09-18 11:50:13'),
(2, 'Finance  ', 'Finance  ', 0, 'enabled', 1, 'admin', '', 'U', '2015-09-15 12:45:45', '2015-09-15 12:45:45'),
(3, 'Operations Department', 'Operations Department', 0, 'enabled', 1, 'admin', '', 'U', '2015-09-15 12:46:46', '2015-09-15 12:46:46'),
(4, 'Communication  ', 'Communication  ', 0, 'enabled', 1, 'admin', '', 'U', '2015-09-15 12:47:02', '2015-09-15 12:47:02'),
(5, 'Commercial Department ', 'Commercial Department ', 0, 'enabled', 1, 'admin', '', 'U', '2015-09-15 12:47:15', '2015-09-15 12:47:15'),
(6, 'Regional Relationships', 'Regional Relationships', 0, 'enabled', 1, 'admin', '', 'U', '2015-09-15 12:47:30', '2015-09-15 12:47:30'),
(7, 'Risk  ', 'Risk  ', 0, 'enabled', 1, 'admin', '', 'U', '2015-09-15 12:47:43', '2015-09-15 12:47:43'),
(8, 'Compliance  ', 'Compliance  ', 0, 'enabled', 1, 'admin', '', 'U', '2015-09-15 12:47:55', '2015-09-15 12:47:55'),
(9, 'Internal Audit ', 'Internal Audit ', 0, 'enabled', 1, 'admin', '', 'U', '2015-09-15 12:48:08', '2015-09-15 12:48:08'),
(10, 'Service Delivery', 'Service Delivery', 0, 'enabled', 1, 'admin', '', 'U', '2015-09-15 12:48:21', '2015-09-15 12:48:21'),
(12, 'Operations Department ', 'Operations Department ', 0, 'enabled', 3, 'admin', '', 'U', '2015-09-15 12:49:52', '2015-09-15 12:49:52'),
(13, 'Operations Department ', 'Operations Department ', 0, 'enabled', 4, 'admin', '', 'U', '2015-09-15 12:50:07', '2015-09-15 12:50:07'),
(14, 'Operations Department ', 'Operations Department ', 0, 'enabled', 5, 'admin', '', 'U', '2015-09-15 12:51:04', '2015-09-15 12:51:04'),
(15, 'Operations Department ', 'Operations Department ', 0, 'enabled', 6, 'admin', '', 'U', '2015-09-15 12:51:21', '2015-09-15 12:51:21'),
(16, 'Administration', 'Administration', 1, 'enabled', 1, 'admin', '', 'U', '2015-09-18 11:58:42', '2015-09-18 11:58:42');

-- --------------------------------------------------------

--
-- Table structure for table `prt_issues_daily_updates`
--

CREATE TABLE IF NOT EXISTS `prt_issues_daily_updates` (
`id` int(10) unsigned NOT NULL,
  `issue_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `current_update` text COLLATE utf8_unicode_ci NOT NULL,
  `input_by` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `display_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `auth_by` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `auth_status` varchar(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'U',
  `current_date` date NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `prt_issues_daily_updates`
--

INSERT INTO `prt_issues_daily_updates` (`id`, `issue_id`, `current_update`, `input_by`, `display_name`, `auth_by`, `auth_status`, `current_date`, `created_at`, `updated_at`) VALUES
(1, '1', 'We have checked with Sanjyot on which they just wanted confirmation for 50K needs to be replaced by 50 F or it is required for MT103 alone.\r\nWe updated as we need for only MT103 and we are waiting for their update.', 'admin', 'Portal Administrator', '', 'U', '2015-09-22', '2015-09-22 12:40:01', '2015-09-22 12:40:01'),
(2, '2', 'We are going to do some test today night.If everything goes well we will shift to the new server.', 'ibrahim.said', 'Ibrahim Said', '', 'U', '2015-09-22', '2015-09-22 13:28:09', '2015-09-22 13:28:09'),
(3, '5', 'We will run the scripts tomorrow on DR and share the output.', 'andrew.shiyo', 'Andrew Shiyo', '', 'U', '2015-09-22', '2015-09-22 13:53:26', '2015-09-22 13:53:26'),
(4, '1', 'Spoke with Sanjyot on the issue which needs close followup.', 'admin', 'Portal Administrator', '', 'U', '2015-09-23', '2015-09-23 17:16:03', '2015-09-23 17:16:03'),
(5, '5', 'Spoke with Sanjyot on the issue which needs close followup', 'admin', 'Portal Administrator', '', 'U', '2015-09-23', '2015-09-23 17:16:17', '2015-09-23 17:16:17'),
(6, '3', 'Spoke with Sanjyot on the issue which needs close followup', 'admin', 'Portal Administrator', '', 'U', '2015-09-23', '2015-09-23 17:16:29', '2015-09-23 17:16:29'),
(7, '4', 'Spoke with Sanjyot on the issue which needs close followup', 'admin', 'Portal Administrator', '', 'U', '2015-09-23', '2015-09-23 17:16:41', '2015-09-23 17:16:41'),
(8, '2', 'We will conduct live test on saturday', 'admin', 'Portal Administrator', '', 'U', '2015-09-23', '2015-09-23 17:18:09', '2015-09-23 17:18:09'),
(9, '1', 'Sanjyot wanted debug for transaction which got posted with 50F,  we discussed over the chat and updated in MOS as follow, we can''t pull the debug of 50F from flexcube as the modification from 50K to 50F was done on SWIFT screen. \r\n\r\nSanjyot will look into it and update further.', 'andrew.shiyo', 'Andrew Shiyo', '', 'U', '2015-09-25', '2015-09-25 16:31:06', '2015-09-25 16:31:06'),
(10, '3', 'As per our chat with Sanjyot, \r\nThis issue will be sorted after applying the fix from the different pending issue on MOS (SR 3-11188887361) which will be applied in production after testing being done and finished successfully.', 'augustino.udambe', 'Augustino Udambe', '', 'U', '2015-09-25', '2015-09-25 16:48:43', '2015-09-25 16:48:43'),
(11, '4', 'We sent the requested spool file and package bodies as requested for the way forward .\r\n', 'augustino.udambe', 'Augustino Udambe', '', 'U', '2015-09-25', '2015-09-25 17:08:25', '2015-09-25 17:08:25'),
(12, '5', 'We have applied the fix in UAT and updated the same in MOS', 'andrew.shiyo', 'Andrew Shiyo', '', 'U', '2015-09-26', '2015-09-26 12:27:40', '2015-09-26 12:27:40'),
(13, '5', 'We will be applying the fix in production today after EOD', 'augustino.udambe', 'Augustino Udambe', '', 'U', '2015-09-28', '2015-09-28 16:24:33', '2015-09-28 16:24:33'),
(14, '3', 'This issue will be closed after applying the fix from issue ( SR 3-11188887361 ) and working fine.', 'augustino.udambe', 'Augustino Udambe', '', 'U', '2015-09-28', '2015-09-28 16:27:14', '2015-09-28 16:27:14'),
(15, '4', 'We need to test the fix in UAT sent by Oracle for the way forward.', 'augustino.udambe', 'Augustino Udambe', '', 'U', '2015-09-28', '2015-09-28 16:28:35', '2015-09-28 16:28:35'),
(16, '1', 'Awaiting for the update from Oracle after attaching the package body  ( ISPKS_ADV1 ) which was requested from their end.', 'augustino.udambe', 'Augustino Udambe', '', 'U', '2015-09-28', '2015-09-28 16:30:05', '2015-09-28 16:30:05'),
(17, '5', 'We applied the fix yesterday after EOD and finished successfully, we are waiting for the update from Oracle for the way forward.', 'augustino.udambe', 'Augustino Udambe', '', 'U', '2015-09-29', '2015-09-29 13:49:43', '2015-09-29 13:49:43'),
(18, '1', 'We updated the requested debug during authorization, we are waiting for their reply for the way forward.', 'augustino.udambe', 'Augustino Udambe', '', 'U', '2015-09-29', '2015-09-29 13:52:33', '2015-09-29 13:52:33'),
(19, '4', 'The fix sent was not working, we have attached the debug for more details and awaiting for their reply.', 'augustino.udambe', 'Augustino Udambe', '', 'U', '2015-09-29', '2015-09-29 14:00:15', '2015-09-29 14:00:15'),
(20, '3', 'This issue is in parallel with the issue SR 3-11188887361', 'augustino.udambe', 'Augustino Udambe', '', 'U', '2015-09-29', '2015-09-29 14:01:30', '2015-09-29 14:01:30'),
(21, '6', 'This is new issue raised today', 'augustino.udambe', 'Augustino Udambe', '', 'U', '2015-09-29', '2015-09-29 14:08:15', '2015-09-29 14:08:15'),
(22, '7', 'This is new issue raised today', 'augustino.udambe', 'Augustino Udambe', '', 'U', '2015-09-29', '2015-09-29 14:12:47', '2015-09-29 14:12:47');

-- --------------------------------------------------------

--
-- Table structure for table `prt_login_histories`
--

CREATE TABLE IF NOT EXISTS `prt_login_histories` (
`id` int(10) unsigned NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `prt_messages`
--

CREATE TABLE IF NOT EXISTS `prt_messages` (
`id` int(10) unsigned NOT NULL,
  `query_id` int(11) NOT NULL,
  `sender` int(11) NOT NULL,
  `receiver` int(11) NOT NULL,
  `group_id` int(11) DEFAULT NULL,
  `message` text COLLATE utf8_unicode_ci NOT NULL,
  `sent_time` datetime NOT NULL,
  `received_time` datetime NOT NULL,
  `is_read` int(11) NOT NULL DEFAULT '0',
  `status` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `prt_migrations`
--

CREATE TABLE IF NOT EXISTS `prt_migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `prt_migrations`
--

INSERT INTO `prt_migrations` (`migration`, `batch`) VALUES
('2014_10_12_000000_create_users_table', 1),
('2014_10_12_100000_create_password_resets_table', 1),
('2015_08_28_115519_create_branches_table', 1),
('2015_08_28_120137_create_departments_table', 1),
('2015_08_28_152312_create_user_histories_table', 1),
('2015_08_28_152329_create_login_histories_table', 1),
('2015_09_03_140808_create_units_table', 1),
('2015_09_09_102651_create_user_rights_table', 1),
('2015_09_16_155825_create_modules_table', 1),
('2015_09_16_161310_create_tasks_table', 1),
('2015_09_16_162726_create_task_queries_table', 1),
('2015_09_16_165006_create_task_assignments_table', 1),
('2015_09_16_165037_create_services_table', 1),
('2015_09_16_165110_create_service_logs_table', 1),
('2015_09_17_213658_create_service_log_areas_table', 1),
('2015_09_19_042355_create_query_assignments_table', 1),
('2015_09_19_064926_create_messages_table', 1),
('2015_09_19_160002_create_rights_table', 1),
('2015_09_21_084143_create_oracle_supports_table', 1),
('2015_09_21_092011_create_issues_daily_updates_table', 1),
('2015_09_25_114643_create_user_modules_table', 2);

-- --------------------------------------------------------

--
-- Table structure for table `prt_modules`
--

CREATE TABLE IF NOT EXISTS `prt_modules` (
`id` int(10) unsigned NOT NULL,
  `department_id` int(11) NOT NULL,
  `module_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `input_by` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `auth_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `auth_status` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'U',
  `status` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'enable',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `prt_modules`
--

INSERT INTO `prt_modules` (`id`, `department_id`, `module_name`, `description`, `input_by`, `auth_by`, `auth_status`, `status`, `created_at`, `updated_at`) VALUES
(1, 16, 'Printer', 'Printer', 'admin', '', 'U', 'enabled', '2015-09-18 12:04:07', '2015-09-18 12:04:07'),
(2, 16, 'Inward/Outward Calls', 'Inward/Outward Calls', 'admin', '', 'U', 'enabled', '2015-09-18 12:04:36', '2015-09-18 12:04:36'),
(3, 16, 'Inward/Outward Fax', 'Inward/Outward Fax', 'admin', '', 'U', 'enabled', '2015-09-18 12:04:56', '2015-09-18 12:04:56'),
(4, 16, 'Premises Maintenance/Renovation', 'Premises Maintenance/Renovation', 'admin', '', 'U', 'enabled', '2015-09-18 12:05:17', '2015-09-18 12:05:17'),
(5, 16, 'Fixed Assets', 'Fixed Assets', 'admin', '', 'U', 'enabled', '2015-09-18 12:05:36', '2015-09-18 12:05:36'),
(6, 16, 'Electricity', 'Electricity', 'admin', '', 'U', 'enabled', '2015-09-18 12:07:36', '2015-09-18 12:07:36'),
(7, 16, 'Water', 'Water', 'admin', '', 'U', 'enabled', '2015-09-18 12:07:55', '2015-09-18 12:07:55'),
(8, 16, 'Security', 'Security', 'admin', '', 'U', 'enabled', '2015-09-18 12:08:15', '2015-09-18 12:08:15'),
(9, 16, 'Archives', 'Archives', 'admin', '', 'U', 'enabled', '2015-09-18 12:08:32', '2015-09-18 12:08:32'),
(10, 16, 'Stationery', 'Stationery', 'admin', '', 'U', 'enabled', '2015-09-18 12:08:48', '2015-09-18 12:08:48'),
(11, 16, 'Printing', 'Printing', 'admin', '', 'U', 'enabled', '2015-09-18 12:09:06', '2015-09-18 12:09:06'),
(12, 16, 'Mgt &amp; AMCs / Lease Agreement', 'Mgt &amp; AMCs / Lease Agreement', 'admin', '', 'U', 'enabled', '2015-09-18 12:09:54', '2015-09-18 12:09:54'),
(13, 16, 'Mgt. Of Orders/ LPOs / Invoices', 'Mgt. Of Orders/ LPOs / Invoices', 'admin', '', 'U', 'enabled', '2015-09-18 12:10:12', '2015-09-18 12:10:12'),
(14, 16, 'TIC/TRA', 'TIC/TRA', 'admin', '', 'U', 'enabled', '2015-09-18 12:10:34', '2015-09-18 12:10:34'),
(15, 16, 'Petty Cash', 'Petty Cash', 'admin', '', 'U', 'enabled', '2015-09-18 12:10:51', '2015-09-18 12:10:51'),
(16, 16, 'Brand & Image of Bank', 'Brand & Image of Bank', 'admin', '', 'U', 'enabled', '2015-09-18 12:11:25', '2015-09-18 12:11:25'),
(17, 16, 'Liaison with Branch Managers', 'Liaison with Branch Managers', 'admin', '', 'U', 'enabled', '2015-09-18 12:11:46', '2015-09-18 12:11:46'),
(18, 16, 'Work Permits for Expatriate Staff', 'Work Permits for Expatriate Staff', 'admin', '', 'U', 'enabled', '2015-09-18 12:12:06', '2015-09-18 12:12:06'),
(19, 16, 'Reception - Visitors', 'Reception - Visitors', 'admin', '', 'U', 'enabled', '2015-09-18 12:12:22', '2015-09-18 12:12:22'),
(20, 16, 'Note Counting Machine', 'Note Counting Machine', 'admin', '', 'U', 'enabled', '2015-09-18 12:12:39', '2015-09-18 12:12:39'),
(21, 16, 'Photocopy Machine', 'Photocopy Machine', 'admin', '', 'U', 'enabled', '2015-09-18 12:12:57', '2015-09-18 12:12:57'),
(22, 16, 'Other', 'Other', 'admin', '', 'U', 'enabled', '2015-09-18 12:13:23', '2015-09-18 12:13:23'),
(23, 1, 'Flexcube', 'Flexcube', 'admin', '', 'U', 'enabled', '2015-09-18 12:31:24', '2015-09-18 12:31:24'),
(24, 1, 'Network', 'Network', 'admin', '', 'U', 'enabled', '2015-09-18 12:31:50', '2015-09-18 12:31:50'),
(25, 1, 'Software/Application', 'Software/Application', 'admin', '', 'U', 'enabled', '2015-09-18 12:32:11', '2015-09-18 12:32:11'),
(26, 1, 'Emails', 'Emails', 'admin', '', 'U', 'enabled', '2015-09-18 12:32:27', '2015-09-18 12:32:27'),
(27, 1, 'PC General', 'PC General', 'admin', '', 'U', 'enabled', '2015-09-18 12:32:48', '2015-09-18 12:32:48'),
(28, 1, 'Biometric', 'Biometric', 'admin', '', 'U', 'enabled', '2015-09-18 12:33:06', '2015-09-18 12:33:06'),
(29, 1, 'Scanner', 'Scanner', 'admin', '', 'U', 'enabled', '2015-09-18 12:33:29', '2015-09-18 12:33:29'),
(30, 1, 'Business Objects - BO', 'Business Objects - BO', 'admin', '', 'U', 'enabled', '2015-09-18 12:33:45', '2015-09-18 12:33:45'),
(31, 1, 'Black Berry Services', 'Black Berry Services', 'admin', '', 'U', 'enabled', '2015-09-18 12:34:06', '2015-09-18 12:34:06'),
(32, 1, 'SWIFT', 'SWIFT', 'admin', '', 'U', 'enabled', '2015-09-18 12:34:32', '2015-09-18 12:34:32'),
(33, 1, 'Shared Folder - S Drive', 'Shared Folder - S Drive', 'admin', '', 'U', 'enabled', '2015-09-18 12:34:52', '2015-09-18 12:34:52'),
(34, 1, 'EMS', 'EMS', 'admin', '', 'U', 'enabled', '2015-09-18 12:35:13', '2015-09-18 12:35:13'),
(35, 1, 'STP', 'STP', 'admin', '', 'U', 'enabled', '2015-09-18 12:35:28', '2015-09-18 12:35:28');

-- --------------------------------------------------------

--
-- Table structure for table `prt_oracle_supports`
--

CREATE TABLE IF NOT EXISTS `prt_oracle_supports` (
`id` int(10) unsigned NOT NULL,
  `issue_title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `sr_number` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `product` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `contact` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `date_opened` datetime NOT NULL,
  `date_closed` datetime DEFAULT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `current_status` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `input_by` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `auth_by` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email_sent` varchar(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `auth_status` varchar(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'U',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `prt_oracle_supports`
--

INSERT INTO `prt_oracle_supports` (`id`, `issue_title`, `description`, `sr_number`, `product`, `contact`, `date_opened`, `date_closed`, `status`, `current_status`, `input_by`, `auth_by`, `email_sent`, `auth_status`, `created_at`, `updated_at`) VALUES
(1, 'Changes On Swift Line - 50k To 50f', '<p><span style="color: rgb(0, 61, 91); font-family: Tahoma, Verdana, Helvetica, sans-serif; font-size: 11px; line-height: normal; background-color: rgb(250, 250, 250);">Hi,&nbsp;</span></p>\r\n', '3-11382512271', 'Oracle FLEXCUBE Universal Banking', 'Augustino', '2015-09-16 00:00:00', NULL, 'Opened', 'Review Update', 'admin', '', 'N', 'U', '2015-09-22 12:33:07', '2015-09-29 14:14:11'),
(2, 'File Transfers (ftp) From/to The Jems Server To The Swift Box', '<p><span style="color: rgb(0, 61, 91); font-family: Tahoma, Verdana, Helvetica, sans-serif; font-size: 11px; line-height: normal; background-color: rgb(250, 250, 250);">Hi Team,&nbsp;</span></p>\r\n', '3-11254458561', 'Oracle FLEXCUBE Universal Banking', 'Andrew', '2015-08-25 00:00:00', NULL, 'Closed', 'Review Update', 'augustino.udambe', '', 'N', 'U', '2015-09-22 12:45:45', '2015-09-28 16:02:16'),
(3, 'Lc Authorization Process Being Slower', '<p><span style="color: rgb(0, 61, 91); font-family: Tahoma, Verdana, Helvetica, sans-serif; font-size: 11px; line-height: normal; background-color: rgb(250, 250, 250);">LC authorization process is taking longer (ranging from 14 mts to 40 mts). I have generated TKPROF for a sample process. From the TKPROF I could see that the query below is taking longer time.&nbsp;</span><br style="color: rgb(0, 61, 91); font-family: Tahoma, Verdana, Helvetica, sans-serif; font-size: 11px; line-height: normal; background-color: rgb(250, 250, 250);" />\r\n<br style="color: rgb(0, 61, 91); font-family: Tahoma, Verdana, Helvetica, sans-serif; font-size: 11px; line-height: normal; background-color: rgb(250, 250, 250);" />\r\n<span style="color: rgb(0, 61, 91); font-family: Tahoma, Verdana, Helvetica, sans-serif; font-size: 11px; line-height: normal; background-color: rgb(250, 250, 250);">SELECT ADV.MSG_TYPE MSG_TYPE, ADV.MEDIUM ADV_MEDIA, ADV.SUPPRESS SUPPRESS,&nbsp;</span><br style="color: rgb(0, 61, 91); font-family: Tahoma, Verdana, Helvetica, sans-serif; font-size: 11px; line-height: normal; background-color: rgb(250, 250, 250);" />\r\n<span style="color: rgb(0, 61, 91); font-family: Tahoma, Verdana, Helvetica, sans-serif; font-size: 11px; line-height: normal; background-color: rgb(250, 250, 250);">ADV.PRIORITY PRIORITY, ADV.PARTY_ID CIF_ID, ADV.PARTY_NAME PARTY_NAME,&nbsp;</span><br style="color: rgb(0, 61, 91); font-family: Tahoma, Verdana, Helvetica, sans-serif; font-size: 11px; line-height: normal; background-color: rgb(250, 250, 250);" />\r\n<span style="color: rgb(0, 61, 91); font-family: Tahoma, Verdana, Helvetica, sans-serif; font-size: 11px; line-height: normal; background-color: rgb(250, 250, 250);">ADV.ADDRESS_LINE1 LINE1, ADV.ADDRESS_LINE2 LINE2, ADV.ADDRESS_LINE3 LINE3,&nbsp;</span><br style="color: rgb(0, 61, 91); font-family: Tahoma, Verdana, Helvetica, sans-serif; font-size: 11px; line-height: normal; background-color: rgb(250, 250, 250);" />\r\n<span style="color: rgb(0, 61, 91); font-family: Tahoma, Verdana, Helvetica, sans-serif; font-size: 11px; line-height: normal; background-color: rgb(250, 250, 250);">ADV.ADDRESS_LINE4 LINE4, VW.LANG_CODE ADV_LANG, VW.CONTRACT_REF_NO VU_REF,&nbsp;</span><br style="color: rgb(0, 61, 91); font-family: Tahoma, Verdana, Helvetica, sans-serif; font-size: 11px; line-height: normal; background-color: rgb(250, 250, 250);" />\r\n<span style="color: rgb(0, 61, 91); font-family: Tahoma, Verdana, Helvetica, sans-serif; font-size: 11px; line-height: normal; background-color: rgb(250, 250, 250);">VW.EVENT_SEQ_NO VU_ESN, VW.MSG_TYPE VU_MSG&nbsp;</span><br style="color: rgb(0, 61, 91); font-family: Tahoma, Verdana, Helvetica, sans-serif; font-size: 11px; line-height: normal; background-color: rgb(250, 250, 250);" />\r\n<span style="color: rgb(0, 61, 91); font-family: Tahoma, Verdana, Helvetica, sans-serif; font-size: 11px; line-height: normal; background-color: rgb(250, 250, 250);">FROM&nbsp;</span><br style="color: rgb(0, 61, 91); font-family: Tahoma, Verdana, Helvetica, sans-serif; font-size: 11px; line-height: normal; background-color: rgb(250, 250, 250);" />\r\n<span style="color: rgb(0, 61, 91); font-family: Tahoma, Verdana, Helvetica, sans-serif; font-size: 11px; line-height: normal; background-color: rgb(250, 250, 250);">CSTBS_CONTRACT_EVENT_ADVICE ADV, LCVWS_ADVICE_LANGUAGE VW WHERE ADV.MODULE =&nbsp;</span><br style="color: rgb(0, 61, 91); font-family: Tahoma, Verdana, Helvetica, sans-serif; font-size: 11px; line-height: normal; background-color: rgb(250, 250, 250);" />\r\n<span style="color: rgb(0, 61, 91); font-family: Tahoma, Verdana, Helvetica, sans-serif; font-size: 11px; line-height: normal; background-color: rgb(250, 250, 250);">&#39;LC&#39; AND ADV.CONTRACT_REF_NO = :B2 AND ADV.EVENT_SEQ_NO = :B1 AND&nbsp;</span><br style="color: rgb(0, 61, 91); font-family: Tahoma, Verdana, Helvetica, sans-serif; font-size: 11px; line-height: normal; background-color: rgb(250, 250, 250);" />\r\n<span style="color: rgb(0, 61, 91); font-family: Tahoma, Verdana, Helvetica, sans-serif; font-size: 11px; line-height: normal; background-color: rgb(250, 250, 250);">VW.CONTRACT_REF_NO(+) = ADV.CONTRACT_REF_NO AND VW.EVENT_SEQ_NO(+) =&nbsp;</span><br style="color: rgb(0, 61, 91); font-family: Tahoma, Verdana, Helvetica, sans-serif; font-size: 11px; line-height: normal; background-color: rgb(250, 250, 250);" />\r\n<span style="color: rgb(0, 61, 91); font-family: Tahoma, Verdana, Helvetica, sans-serif; font-size: 11px; line-height: normal; background-color: rgb(250, 250, 250);">ADV.EVENT_SEQ_NO AND VW.MSG_TYPE(+) = ADV.MSG_TYPE AND ADV.SUPPRESS &lt;&gt;&#39;Y&#39;&nbsp;</span><br style="color: rgb(0, 61, 91); font-family: Tahoma, Verdana, Helvetica, sans-serif; font-size: 11px; line-height: normal; background-color: rgb(250, 250, 250);" />\r\n<br style="color: rgb(0, 61, 91); font-family: Tahoma, Verdana, Helvetica, sans-serif; font-size: 11px; line-height: normal; background-color: rgb(250, 250, 250);" />\r\n<br style="color: rgb(0, 61, 91); font-family: Tahoma, Verdana, Helvetica, sans-serif; font-size: 11px; line-height: normal; background-color: rgb(250, 250, 250);" />\r\n<span style="color: rgb(0, 61, 91); font-family: Tahoma, Verdana, Helvetica, sans-serif; font-size: 11px; line-height: normal; background-color: rgb(250, 250, 250);">However when the same query is run from the SQL prompt the statement gets executed in less than a second. TKPROF fine is attached FYR. Please advise further on this if I am missin gout something to read from TKPROF.&nbsp;</span></p>\r\n', '3-11404446621', 'Oracle FLEXCUBE Universal Banking', 'Andrew', '2015-09-19 00:00:00', NULL, 'Opened', 'Review Update', 'admin', '', 'N', 'U', '2015-09-22 12:53:28', '2015-09-29 14:13:55'),
(4, 'Tax Component Not Getting Applied', '<p><span style="color: rgb(0, 61, 91); font-family: Tahoma, Verdana, Helvetica, sans-serif; font-size: 11px; line-height: normal; background-color: rgb(250, 250, 250);">We need to define 10% TAX on all the commission/charges from LC module. We have done the product setup to collect 10% TAX. However TAX component is not getting collected when a LC is booked. Relevant screen shots of contract input and product definition are attached. Debug of sample contract input is also attached.&nbsp;</span></p>\r\n', '3-11332383641', 'Oracle FLEXCUBE Universal Banking', 'Andrew', '2015-09-07 00:00:00', NULL, 'Opened', 'Review Update', 'admin', '', 'N', 'U', '2015-09-22 12:58:58', '2015-09-29 14:13:47'),
(5, 'System Slowness', '<p><span style="color: rgb(0, 61, 91); font-family: Tahoma, Verdana, Helvetica, sans-serif; font-size: 11px; line-height: normal; background-color: rgb(250, 250, 250);">We kindly need your assistance,&nbsp;</span><br style="color: rgb(0, 61, 91); font-family: Tahoma, Verdana, Helvetica, sans-serif; font-size: 11px; line-height: normal; background-color: rgb(250, 250, 250);" />\r\n<br style="color: rgb(0, 61, 91); font-family: Tahoma, Verdana, Helvetica, sans-serif; font-size: 11px; line-height: normal; background-color: rgb(250, 250, 250);" />\r\n<span style="color: rgb(0, 61, 91); font-family: Tahoma, Verdana, Helvetica, sans-serif; font-size: 11px; line-height: normal; background-color: rgb(250, 250, 250);">For the past two weeks we have been experiencing system being slow during evening time, we have attached the AWR report for more details and we will provide more informations if required.&nbsp;</span><br style="color: rgb(0, 61, 91); font-family: Tahoma, Verdana, Helvetica, sans-serif; font-size: 11px; line-height: normal; background-color: rgb(250, 250, 250);" />\r\n<br style="color: rgb(0, 61, 91); font-family: Tahoma, Verdana, Helvetica, sans-serif; font-size: 11px; line-height: normal; background-color: rgb(250, 250, 250);" />\r\n<span style="color: rgb(0, 61, 91); font-family: Tahoma, Verdana, Helvetica, sans-serif; font-size: 11px; line-height: normal; background-color: rgb(250, 250, 250);">Please assist to check on priority as we are facing inconveniences a lot from users.&nbsp;</span><br style="color: rgb(0, 61, 91); font-family: Tahoma, Verdana, Helvetica, sans-serif; font-size: 11px; line-height: normal; background-color: rgb(250, 250, 250);" />\r\n<br style="color: rgb(0, 61, 91); font-family: Tahoma, Verdana, Helvetica, sans-serif; font-size: 11px; line-height: normal; background-color: rgb(250, 250, 250);" />\r\n<span style="color: rgb(0, 61, 91); font-family: Tahoma, Verdana, Helvetica, sans-serif; font-size: 11px; line-height: normal; background-color: rgb(250, 250, 250);">Looking forward to hear from you&nbsp;</span><br style="color: rgb(0, 61, 91); font-family: Tahoma, Verdana, Helvetica, sans-serif; font-size: 11px; line-height: normal; background-color: rgb(250, 250, 250);" />\r\n&nbsp;</p>\r\n', '3-11188887361', 'Oracle FLEXCUBE Universal Banking', 'Augustino', '2015-08-12 00:00:00', NULL, 'Opened', 'Solution offered', 'admin', '', 'N', 'U', '2015-09-22 13:06:42', '2015-09-29 14:14:04'),
(6, 'Customer Records', '<p><span style="color: rgb(0, 61, 91); font-family: Tahoma, Verdana, Helvetica, sans-serif; font-size: 11px; line-height: normal; background-color: rgb(250, 250, 250);">Hi ,&nbsp;</span><br style="color: rgb(0, 61, 91); font-family: Tahoma, Verdana, Helvetica, sans-serif; font-size: 11px; line-height: normal; background-color: rgb(250, 250, 250);" />\r\n<br style="color: rgb(0, 61, 91); font-family: Tahoma, Verdana, Helvetica, sans-serif; font-size: 11px; line-height: normal; background-color: rgb(250, 250, 250);" />\r\n<span style="color: rgb(0, 61, 91); font-family: Tahoma, Verdana, Helvetica, sans-serif; font-size: 11px; line-height: normal; background-color: rgb(250, 250, 250);">We have noticed that for any changes which we do under the signatory details&nbsp;</span><br style="color: rgb(0, 61, 91); font-family: Tahoma, Verdana, Helvetica, sans-serif; font-size: 11px; line-height: normal; background-color: rgb(250, 250, 250);" />\r\n<span style="color: rgb(0, 61, 91); font-family: Tahoma, Verdana, Helvetica, sans-serif; font-size: 11px; line-height: normal; background-color: rgb(250, 250, 250);">of the customer records , it does not get recorded under the sttb_field_log and sttb_record_log tables . We expect to have old value and new value like other transactions when changes are done .&nbsp;</span><br style="color: rgb(0, 61, 91); font-family: Tahoma, Verdana, Helvetica, sans-serif; font-size: 11px; line-height: normal; background-color: rgb(250, 250, 250);" />\r\n<br style="color: rgb(0, 61, 91); font-family: Tahoma, Verdana, Helvetica, sans-serif; font-size: 11px; line-height: normal; background-color: rgb(250, 250, 250);" />\r\n<span style="color: rgb(0, 61, 91); font-family: Tahoma, Verdana, Helvetica, sans-serif; font-size: 11px; line-height: normal; background-color: rgb(250, 250, 250);">Let me know if you require any additional details for this . This is compliance&nbsp;</span><br style="color: rgb(0, 61, 91); font-family: Tahoma, Verdana, Helvetica, sans-serif; font-size: 11px; line-height: normal; background-color: rgb(250, 250, 250);" />\r\n<span style="color: rgb(0, 61, 91); font-family: Tahoma, Verdana, Helvetica, sans-serif; font-size: 11px; line-height: normal; background-color: rgb(250, 250, 250);">requirement and request you to attend on priority.&nbsp;</span><br style="color: rgb(0, 61, 91); font-family: Tahoma, Verdana, Helvetica, sans-serif; font-size: 11px; line-height: normal; background-color: rgb(250, 250, 250);" />\r\n<br style="color: rgb(0, 61, 91); font-family: Tahoma, Verdana, Helvetica, sans-serif; font-size: 11px; line-height: normal; background-color: rgb(250, 250, 250);" />\r\n<span style="color: rgb(0, 61, 91); font-family: Tahoma, Verdana, Helvetica, sans-serif; font-size: 11px; line-height: normal; background-color: rgb(250, 250, 250);">I am available online on audambe@gmail.com&nbsp;</span></p>\r\n', 'SR 3-11447196121', 'Oracle FLEXCUBE Universal Banking', 'Augustino', '2015-09-29 00:00:00', NULL, 'Opened', 'New', 'augustino.udambe', '', 'N', 'U', '2015-09-29 14:06:35', '2015-09-29 14:12:05'),
(7, 'Ic - Accruals Getting Skipped Intermittently', '<p><span style="color: rgb(0, 61, 91); font-family: Tahoma, Verdana, Helvetica, sans-serif; font-size: 11px; line-height: normal; background-color: rgb(250, 250, 250);">Hi,&nbsp;</span><br style="color: rgb(0, 61, 91); font-family: Tahoma, Verdana, Helvetica, sans-serif; font-size: 11px; line-height: normal; background-color: rgb(250, 250, 250);" />\r\n<br style="color: rgb(0, 61, 91); font-family: Tahoma, Verdana, Helvetica, sans-serif; font-size: 11px; line-height: normal; background-color: rgb(250, 250, 250);" />\r\n<span style="color: rgb(0, 61, 91); font-family: Tahoma, Verdana, Helvetica, sans-serif; font-size: 11px; line-height: normal; background-color: rgb(250, 250, 250);">It has been noted that the IC accruals are getting skipped intermittently. This was simulated during EOD of 27/Sep/2015. Debug of IC EOD batch is attached FYR. Also IC.sql spool of a sample account where daily accruals was expected is also attached. Please note the accruals would catch-up the next day. However we would want the accruals not getting skipped at all.&nbsp;</span></p>\r\n', 'SR 3-11449644981', 'Oracle FLEXCUBE Universal Banking', 'Augustino', '2015-09-29 00:00:00', NULL, 'Opened', 'New', 'admin', '', 'N', 'U', '2015-09-29 14:11:42', '2015-09-29 14:13:31');

-- --------------------------------------------------------

--
-- Table structure for table `prt_password_resets`
--

CREATE TABLE IF NOT EXISTS `prt_password_resets` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `prt_query_assignments`
--

CREATE TABLE IF NOT EXISTS `prt_query_assignments` (
`id` int(10) unsigned NOT NULL,
  `query_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `assigned_date` datetime NOT NULL,
  `assigned_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `prt_rights`
--

CREATE TABLE IF NOT EXISTS `prt_rights` (
`id` int(10) unsigned NOT NULL,
  `right_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `input_by` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `auth_by` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `auth_status` varchar(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'U',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `prt_rights`
--

INSERT INTO `prt_rights` (`id`, `right_name`, `description`, `status`, `input_by`, `auth_by`, `auth_status`, `created_at`, `updated_at`) VALUES
(1, 'ICT User', '<p>ICT User</p>\r\n', 'enabled', 'admin', '', 'U', '2015-09-23 07:28:36', '2015-09-23 07:28:36'),
(2, 'Administrator', '<p>Administrator</p>\r\n', 'enabled', 'admin', '', 'U', '2015-09-23 07:29:35', '2015-09-23 07:29:35'),
(3, 'Normal User', '<p>Normal User</p>\r\n', 'enabled', 'admin', '', 'U', '2015-09-23 07:30:09', '2015-09-23 07:30:09');

-- --------------------------------------------------------

--
-- Table structure for table `prt_services`
--

CREATE TABLE IF NOT EXISTS `prt_services` (
`id` int(10) unsigned NOT NULL,
  `service_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `input_by` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `auth_by` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `auth_status` varchar(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'U',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `prt_service_logs`
--

CREATE TABLE IF NOT EXISTS `prt_service_logs` (
`id` int(10) unsigned NOT NULL,
  `service_id` int(11) NOT NULL,
  `log_title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `reason` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `start_time` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `end_time` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `remarks` text COLLATE utf8_unicode_ci,
  `logdate` date NOT NULL,
  `status` date NOT NULL,
  `input_by` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `prt_service_log_areas`
--

CREATE TABLE IF NOT EXISTS `prt_service_log_areas` (
`id` int(10) unsigned NOT NULL,
  `serviceLog_id` int(11) NOT NULL,
  `area_affected` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `area_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `prt_tasks`
--

CREATE TABLE IF NOT EXISTS `prt_tasks` (
`id` int(10) unsigned NOT NULL,
  `department_id` int(11) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `task_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `task_description` text COLLATE utf8_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_by` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `prt_task_assignments`
--

CREATE TABLE IF NOT EXISTS `prt_task_assignments` (
`id` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `prt_task_queries`
--

CREATE TABLE IF NOT EXISTS `prt_task_queries` (
`id` int(10) unsigned NOT NULL,
  `query_code` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `reporting_Date` datetime NOT NULL,
  `from_department` int(11) NOT NULL,
  `from_branch` int(11) NOT NULL,
  `to_department` int(11) NOT NULL,
  `to_branch` int(11) NOT NULL,
  `module` int(11) NOT NULL,
  `report_by` int(11) NOT NULL,
  `critical_level` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `reference_file` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `current_stage` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `assigned` int(11) NOT NULL DEFAULT '0',
  `closed` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `prt_units`
--

CREATE TABLE IF NOT EXISTS `prt_units` (
`id` int(10) unsigned NOT NULL,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `department_id` int(11) NOT NULL DEFAULT '0',
  `unit_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `input_by` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `auth_by` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `auth_status` varchar(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'U',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `prt_units`
--

INSERT INTO `prt_units` (`id`, `parent_id`, `department_id`, `unit_name`, `status`, `input_by`, `auth_by`, `auth_status`, `created_at`, `updated_at`) VALUES
(2, 0, 3, 'Clearing Unit  ', 'enabled', 'admin', '', 'U', '2015-09-17 08:18:46', '2015-09-17 08:18:46'),
(3, 0, 3, 'Funds Transfer Unit', 'enabled', 'admin', '', 'U', '2015-09-17 08:25:45', '2015-09-17 08:25:45'),
(4, 0, 3, 'Client Support services Unit', 'enabled', 'admin', '', 'U', '2015-09-17 08:26:55', '2015-09-17 08:26:55'),
(5, 0, 3, 'Sovereign Processing Unit', 'enabled', 'admin', '', 'U', '2015-09-17 08:27:27', '2015-09-17 08:27:27'),
(6, 0, 3, 'Centralized Operations ', 'enabled', 'admin', '', 'U', '2015-09-17 08:29:30', '2015-09-17 08:29:30'),
(7, 0, 3, 'Treasury Back Office', 'enabled', 'admin', '', 'U', '2015-09-17 08:31:15', '2015-09-17 08:31:15'),
(8, 0, 3, 'Products Delivery section ', 'enabled', 'admin', '', 'U', '2015-09-17 08:34:03', '2015-09-17 08:34:03'),
(9, 8, 3, 'Cash In Transit  ', 'enabled', 'admin', '', 'U', '2015-09-17 08:34:28', '2015-09-17 08:34:28'),
(10, 0, 3, 'Administration Department  ', 'enabled', 'admin', '', 'U', '2015-09-17 08:35:34', '2015-09-17 08:35:34'),
(11, 0, 3, 'Human Resources Department', 'enabled', 'admin', '', 'U', '2015-09-17 08:35:46', '2015-09-17 08:35:46'),
(12, 0, 3, 'Training & Development  ', 'enabled', 'admin', '', 'U', '2015-09-17 08:35:55', '2015-09-17 08:35:55'),
(13, 0, 3, 'Operations ', 'enabled', 'admin', '', 'U', '2015-09-17 08:36:12', '2015-09-17 08:36:12'),
(14, 0, 3, 'Cash Management  ', 'enabled', 'admin', '', 'U', '2015-09-17 08:36:23', '2015-09-17 08:36:23'),
(15, 0, 3, 'Customer Care ', 'enabled', 'admin', '', 'U', '2015-09-17 08:36:34', '2015-09-17 08:36:34'),
(16, 0, 3, 'Branch Management Unit', 'enabled', 'admin', '', 'U', '2015-09-17 08:36:41', '2015-09-17 08:36:41'),
(17, 0, 3, 'Trade Finance Section ', 'enabled', 'admin', '', 'U', '2015-09-17 08:36:49', '2015-09-17 08:36:49'),
(18, 0, 5, 'Transactional Banking', 'enabled', 'admin', '', 'U', '2015-09-17 08:38:47', '2015-09-17 08:38:47'),
(19, 0, 5, 'Corporate Banking', 'enabled', 'admin', '', 'U', '2015-09-17 08:38:55', '2015-09-17 08:38:55'),
(20, 0, 5, 'Insititutional Banking ', 'enabled', 'admin', '', 'U', '2015-09-17 08:39:04', '2015-09-17 08:39:04'),
(21, 0, 6, 'Director  ', 'enabled', 'admin', '', 'U', '2015-09-17 08:39:51', '2015-09-17 08:39:51'),
(22, 0, 7, 'Credit Operations ', 'enabled', 'admin', '', 'U', '2015-09-17 08:40:34', '2015-09-17 08:40:34'),
(23, 0, 7, 'Credit Risk', 'enabled', 'admin', '', 'U', '2015-09-17 08:40:43', '2015-09-17 08:40:43'),
(24, 0, 7, 'Legal & Documentation', 'enabled', 'admin', '', 'U', '2015-09-17 08:40:51', '2015-09-17 08:40:51'),
(25, 0, 7, 'Credit  ', 'enabled', 'admin', '', 'U', '2015-09-17 08:40:57', '2015-09-17 08:40:57'),
(26, 0, 7, 'Sales  ', 'enabled', 'admin', '', 'U', '2015-09-17 08:41:03', '2015-09-17 08:41:03'),
(27, 0, 7, 'Forex  ', 'enabled', 'admin', '', 'U', '2015-09-17 08:41:09', '2015-09-17 08:41:09'),
(28, 0, 7, 'Treasury  ', 'enabled', 'admin', '', 'U', '2015-09-17 08:41:15', '2015-09-17 08:41:15');

-- --------------------------------------------------------

--
-- Table structure for table `prt_users`
--

CREATE TABLE IF NOT EXISTS `prt_users` (
`id` int(10) unsigned NOT NULL,
  `first_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `middle_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `last_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `designation` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `bmno` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `user_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'normal',
  `right_id` int(11) DEFAULT '1',
  `branch_id` int(11) NOT NULL,
  `department_id` int(11) NOT NULL,
  `last_login` datetime DEFAULT NULL,
  `last_success_login` datetime DEFAULT NULL,
  `last_logout` datetime DEFAULT NULL,
  `last_failed_login` datetime DEFAULT NULL,
  `login_attempt` int(11) DEFAULT NULL,
  `locked` int(11) NOT NULL,
  `block` int(11) NOT NULL,
  `query_exemption` varchar(3) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'No',
  `exemption_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `query_description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `exemption_start_date` date DEFAULT NULL,
  `exemption_end_date` date DEFAULT NULL,
  `profile_image` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `input_by` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `auth_by` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Inactive',
  `auth_status` varchar(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'U',
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `prt_users`
--

INSERT INTO `prt_users` (`id`, `first_name`, `middle_name`, `last_name`, `designation`, `email`, `phone`, `username`, `bmno`, `password`, `user_type`, `right_id`, `branch_id`, `department_id`, `last_login`, `last_success_login`, `last_logout`, `last_failed_login`, `login_attempt`, `locked`, `block`, `query_exemption`, `exemption_type`, `query_description`, `exemption_start_date`, `exemption_end_date`, `profile_image`, `input_by`, `auth_by`, `status`, `auth_status`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Portal', NULL, 'Administrator', 'System Administrator', '', ' ', 'admin', NULL, '$2y$10$xlQ4GoULhqVqGzdBH9Bo0.zcG93QaKelDIH40liBNonRkd32S1gEi', 'Administrator', 1, 1, 1, '2015-09-29 05:12:40', '2015-09-29 05:12:40', '2015-09-29 06:25:03', NULL, NULL, 0, 0, 'No', NULL, NULL, NULL, NULL, NULL, 'admin', '', '', 'U', 'tZCRm8fWW83hXO0vJAwgO6XsN37DiCmXqEjIeaFg0qQiC9drxodNPpHBcDay', '2015-09-22 12:23:17', '2015-09-29 15:25:03'),
(2, 'Andrew', NULL, 'Shiyo', 'Manager Application Software', 'andrew.shiyo@bankm.com', '+255754639490', 'andrew.shiyo', NULL, '$2y$10$0HXHMFDYlCEGUXLiCPp4U..6MYTYbmGauxTvk4ia4zA.G6F9sHTcG', 'normal', 1, 1, 1, '2015-09-26 03:24:00', '2015-09-26 03:24:00', '2015-09-26 03:27:46', NULL, NULL, 0, 0, 'No', NULL, NULL, NULL, NULL, NULL, '', '', 'Active', 'U', '0jl9nl7NYMasF0RWURXzYnBmDzhUuF09s0t4NyqYYKlsDs55GkLiHNSLZ8pk', '2015-09-22 12:46:38', '2015-09-26 12:27:46'),
(4, 'Adolph', NULL, 'Mwakalinga', 'Application Software, Manager ICT', 'adolph.mwakalinga@bankm.com', '0714687484 ', 'adolph.mwakalinga', NULL, '$2y$10$Kig/I5x63iy25u.ITY7CHuUlnRCpQPFaUktNbQSzQnueSLiqn6T6O', 'normal', 1, 1, 1, '2015-09-22 04:01:33', '2015-09-22 04:01:33', NULL, NULL, NULL, 0, 0, 'No', NULL, NULL, NULL, NULL, NULL, 'admin', '', 'Active', 'U', NULL, '2015-09-22 13:01:04', '2015-09-25 17:00:52'),
(6, 'Ibrahim', NULL, 'Said', 'ICT MANAGER TECH MANAGER', 'ibrahim.said@bankm.com', '0717957521   ', 'ibrahim.said', NULL, '$2y$10$MQLwyvYfzYvizHiEI47n5eRlc/Yjqxx/Vg54YCOToBMKRA.PlcRjq', 'normal', 1, 1, 1, '2015-09-22 04:26:00', '2015-09-22 04:26:00', NULL, NULL, NULL, 0, 0, 'No', NULL, NULL, NULL, NULL, NULL, 'admin', '', 'Active', 'U', NULL, '2015-09-22 13:25:47', '2015-09-25 15:07:23'),
(13, 'Innocent', '', 'Christopher', 'Asst Manager Application Software', 'innocent.christopher@bankm.com', '0714991449     ', 'innocent.christopher', NULL, '$2y$10$vEwVCo7Yutl9U2GyyeTuOe9ptY96w7fJc9gHg2VZlGYltMiTDklja', 'normal', 1, 1, 1, NULL, NULL, NULL, NULL, NULL, 0, 0, 'No', 'Leave', 'User has gone to annual leave', '2015-09-26', '2015-10-25', NULL, 'admin', '', 'Active', 'U', NULL, '2015-09-23 09:24:50', '2015-09-25 17:06:22'),
(14, 'Augustino', NULL, 'Udambe', 'Manager ICT | Application Software', 'augustino.udambe@bankm.com', '0782230483', 'augustino.udambe', NULL, '$2y$10$OE.scDTW2s09ajclMtx6BeNkIBXq77.aiC1JfRTYPNnS1Syfkcg8m', 'normal', 1, 1, 1, '2015-09-29 04:48:26', '2015-09-29 04:48:26', NULL, NULL, NULL, 0, 0, 'No', NULL, NULL, NULL, NULL, NULL, '', '', 'Active', 'U', 'BXOFTXvLHgnWtTYlNn2z4MLqN9P9E9bn2l3Xt6ZtwdZ4zN106NLRhHRx9vMK', '2015-09-25 16:37:44', '2015-09-29 13:48:26'),
(15, 'Rajen', NULL, 'Mistry', 'Dy.Manager ICT - Technical Support', 'rajen.mistry@bankm.com', '+255 688 938 730', 'rajen.mistry', NULL, '$2y$10$EzVMhEDWRCBIVv7ZbKmn2exc5F5AdTn/bY2.s/yEqlgyNMaE23No2', 'normal', 1, 1, 1, NULL, NULL, NULL, NULL, NULL, 0, 0, 'No', NULL, NULL, NULL, NULL, NULL, '', '', 'Inactive', 'U', NULL, '2015-09-29 15:34:13', '2015-09-29 15:34:13');

-- --------------------------------------------------------

--
-- Table structure for table `prt_user_histories`
--

CREATE TABLE IF NOT EXISTS `prt_user_histories` (
`id` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `prt_user_modules`
--

CREATE TABLE IF NOT EXISTS `prt_user_modules` (
`id` int(10) unsigned NOT NULL,
  `user_id` int(11) NOT NULL,
  `module_id` int(11) NOT NULL,
  `input_by` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `auth_by` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `auth_status` varchar(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'U',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `prt_user_modules`
--

INSERT INTO `prt_user_modules` (`id`, `user_id`, `module_id`, `input_by`, `auth_by`, `auth_status`, `created_at`, `updated_at`) VALUES
(34, 14, 23, 'admin', '', 'U', '2015-09-25 16:59:25', '2015-09-25 16:59:25'),
(35, 14, 25, 'admin', '', 'U', '2015-09-25 16:59:26', '2015-09-25 16:59:26'),
(36, 14, 30, 'admin', '', 'U', '2015-09-25 16:59:26', '2015-09-25 16:59:26'),
(37, 14, 34, 'admin', '', 'U', '2015-09-25 16:59:26', '2015-09-25 16:59:26'),
(38, 14, 35, 'admin', '', 'U', '2015-09-25 16:59:26', '2015-09-25 16:59:26'),
(39, 4, 23, 'admin', '', 'U', '2015-09-25 17:04:11', '2015-09-25 17:04:11'),
(40, 4, 25, 'admin', '', 'U', '2015-09-25 17:04:11', '2015-09-25 17:04:11'),
(41, 4, 34, 'admin', '', 'U', '2015-09-25 17:04:12', '2015-09-25 17:04:12'),
(42, 4, 35, 'admin', '', 'U', '2015-09-25 17:04:12', '2015-09-25 17:04:12'),
(43, 13, 23, 'admin', '', 'U', '2015-09-25 17:05:33', '2015-09-25 17:05:33'),
(44, 13, 25, 'admin', '', 'U', '2015-09-25 17:05:33', '2015-09-25 17:05:33'),
(45, 13, 32, 'admin', '', 'U', '2015-09-25 17:05:33', '2015-09-25 17:05:33'),
(46, 13, 34, 'admin', '', 'U', '2015-09-25 17:05:33', '2015-09-25 17:05:33'),
(47, 13, 35, 'admin', '', 'U', '2015-09-25 17:05:33', '2015-09-25 17:05:33');

-- --------------------------------------------------------

--
-- Table structure for table `prt_user_rights`
--

CREATE TABLE IF NOT EXISTS `prt_user_rights` (
`id` int(10) unsigned NOT NULL,
  `right_id` int(11) NOT NULL,
  `module` int(11) NOT NULL DEFAULT '0',
  `viw` int(11) NOT NULL DEFAULT '0',
  `edi` int(11) NOT NULL DEFAULT '0',
  `del` int(11) NOT NULL DEFAULT '0',
  `inp` int(11) NOT NULL DEFAULT '0',
  `aut` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `prt_user_rights`
--

INSERT INTO `prt_user_rights` (`id`, `right_id`, `module`, `viw`, `edi`, `del`, `inp`, `aut`, `created_at`, `updated_at`) VALUES
(1, 1, 8, 0, 0, 0, 0, 0, '2015-09-23 07:28:36', '2015-09-23 07:28:36'),
(2, 1, 9, 0, 0, 0, 0, 0, '2015-09-23 07:28:36', '2015-09-23 07:28:36'),
(3, 1, 10, 0, 0, 0, 0, 0, '2015-09-23 07:28:36', '2015-09-23 07:28:36'),
(4, 2, 1, 0, 0, 0, 0, 0, '2015-09-23 07:29:35', '2015-09-23 07:29:35'),
(5, 2, 2, 0, 0, 0, 0, 0, '2015-09-23 07:29:35', '2015-09-23 07:29:35'),
(6, 2, 3, 0, 0, 0, 0, 0, '2015-09-23 07:29:35', '2015-09-23 07:29:35'),
(7, 2, 4, 0, 0, 0, 0, 0, '2015-09-23 07:29:35', '2015-09-23 07:29:35'),
(8, 2, 5, 0, 0, 0, 0, 0, '2015-09-23 07:29:35', '2015-09-23 07:29:35'),
(9, 2, 6, 0, 0, 0, 0, 0, '2015-09-23 07:29:35', '2015-09-23 07:29:35'),
(10, 2, 7, 0, 0, 0, 0, 0, '2015-09-23 07:29:35', '2015-09-23 07:29:35'),
(11, 2, 8, 0, 0, 0, 0, 0, '2015-09-23 07:29:35', '2015-09-23 07:29:35'),
(12, 2, 9, 0, 0, 0, 0, 0, '2015-09-23 07:29:35', '2015-09-23 07:29:35'),
(13, 2, 10, 0, 0, 0, 0, 0, '2015-09-23 07:29:35', '2015-09-23 07:29:35'),
(14, 3, 1, 0, 0, 0, 0, 0, '2015-09-23 07:30:09', '2015-09-23 07:30:09'),
(15, 3, 2, 0, 0, 0, 0, 0, '2015-09-23 07:30:09', '2015-09-23 07:30:09'),
(16, 3, 3, 0, 0, 0, 0, 0, '2015-09-23 07:30:09', '2015-09-23 07:30:09'),
(17, 3, 8, 0, 0, 0, 0, 0, '2015-09-23 07:30:09', '2015-09-23 07:30:09');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `prt_branches`
--
ALTER TABLE `prt_branches`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `prt_departments`
--
ALTER TABLE `prt_departments`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `prt_issues_daily_updates`
--
ALTER TABLE `prt_issues_daily_updates`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `prt_login_histories`
--
ALTER TABLE `prt_login_histories`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `prt_messages`
--
ALTER TABLE `prt_messages`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `prt_modules`
--
ALTER TABLE `prt_modules`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `prt_oracle_supports`
--
ALTER TABLE `prt_oracle_supports`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `prt_password_resets`
--
ALTER TABLE `prt_password_resets`
 ADD KEY `password_resets_email_index` (`email`), ADD KEY `password_resets_token_index` (`token`);

--
-- Indexes for table `prt_query_assignments`
--
ALTER TABLE `prt_query_assignments`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `prt_rights`
--
ALTER TABLE `prt_rights`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `prt_services`
--
ALTER TABLE `prt_services`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `prt_service_logs`
--
ALTER TABLE `prt_service_logs`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `prt_service_log_areas`
--
ALTER TABLE `prt_service_log_areas`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `prt_tasks`
--
ALTER TABLE `prt_tasks`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `prt_task_assignments`
--
ALTER TABLE `prt_task_assignments`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `prt_task_queries`
--
ALTER TABLE `prt_task_queries`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `task_queries_query_code_unique` (`query_code`);

--
-- Indexes for table `prt_units`
--
ALTER TABLE `prt_units`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `prt_users`
--
ALTER TABLE `prt_users`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `users_email_unique` (`email`), ADD UNIQUE KEY `users_phone_unique` (`phone`), ADD UNIQUE KEY `users_username_unique` (`username`);

--
-- Indexes for table `prt_user_histories`
--
ALTER TABLE `prt_user_histories`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `prt_user_modules`
--
ALTER TABLE `prt_user_modules`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `prt_user_rights`
--
ALTER TABLE `prt_user_rights`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `prt_branches`
--
ALTER TABLE `prt_branches`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `prt_departments`
--
ALTER TABLE `prt_departments`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `prt_issues_daily_updates`
--
ALTER TABLE `prt_issues_daily_updates`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=23;
--
-- AUTO_INCREMENT for table `prt_login_histories`
--
ALTER TABLE `prt_login_histories`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `prt_messages`
--
ALTER TABLE `prt_messages`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `prt_modules`
--
ALTER TABLE `prt_modules`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=36;
--
-- AUTO_INCREMENT for table `prt_oracle_supports`
--
ALTER TABLE `prt_oracle_supports`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `prt_query_assignments`
--
ALTER TABLE `prt_query_assignments`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `prt_rights`
--
ALTER TABLE `prt_rights`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `prt_services`
--
ALTER TABLE `prt_services`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `prt_service_logs`
--
ALTER TABLE `prt_service_logs`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `prt_service_log_areas`
--
ALTER TABLE `prt_service_log_areas`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `prt_tasks`
--
ALTER TABLE `prt_tasks`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `prt_task_assignments`
--
ALTER TABLE `prt_task_assignments`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `prt_task_queries`
--
ALTER TABLE `prt_task_queries`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `prt_units`
--
ALTER TABLE `prt_units`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=29;
--
-- AUTO_INCREMENT for table `prt_users`
--
ALTER TABLE `prt_users`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `prt_user_histories`
--
ALTER TABLE `prt_user_histories`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `prt_user_modules`
--
ALTER TABLE `prt_user_modules`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=48;
--
-- AUTO_INCREMENT for table `prt_user_rights`
--
ALTER TABLE `prt_user_rights`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=18;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
