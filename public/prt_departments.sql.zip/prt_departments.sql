-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Sep 19, 2015 at 05:06 PM
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `portal`
--

-- --------------------------------------------------------

--
-- Table structure for table `prt_departments`
--

CREATE TABLE IF NOT EXISTS `prt_departments` (
`id` int(10) unsigned NOT NULL,
  `department_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `receive_query` int(11) NOT NULL DEFAULT '0',
  `branch_id` int(11) NOT NULL,
  `input_by` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `auth_by` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `auth_status` varchar(1) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `prt_departments`
--

INSERT INTO `prt_departments` (`id`, `department_name`, `description`, `status`, `receive_query`, `branch_id`, `input_by`, `auth_by`, `auth_status`, `created_at`, `updated_at`) VALUES
(1, 'ICT  ', 'ICT  HQ', 'enabled', 1, 1, 'admin', '', 'U', '2015-09-15 12:42:45', '2015-09-18 11:50:13'),
(2, 'Finance  ', 'Finance  ', 'enabled', 0, 1, 'admin', '', 'U', '2015-09-15 12:45:45', '2015-09-15 12:45:45'),
(3, 'Operations Department', 'Operations Department', 'enabled', 0, 1, 'admin', '', 'U', '2015-09-15 12:46:46', '2015-09-15 12:46:46'),
(4, 'Communication  ', 'Communication  ', 'enabled', 0, 1, 'admin', '', 'U', '2015-09-15 12:47:02', '2015-09-15 12:47:02'),
(5, 'Commercial Department ', 'Commercial Department ', 'enabled', 0, 1, 'admin', '', 'U', '2015-09-15 12:47:15', '2015-09-15 12:47:15'),
(6, 'Regional Relationships', 'Regional Relationships', 'enabled', 0, 1, 'admin', '', 'U', '2015-09-15 12:47:30', '2015-09-15 12:47:30'),
(7, 'Risk  ', 'Risk  ', 'enabled', 0, 1, 'admin', '', 'U', '2015-09-15 12:47:43', '2015-09-15 12:47:43'),
(8, 'Compliance  ', 'Compliance  ', 'enabled', 0, 1, 'admin', '', 'U', '2015-09-15 12:47:55', '2015-09-15 12:47:55'),
(9, 'Internal Audit ', 'Internal Audit ', 'enabled', 0, 1, 'admin', '', 'U', '2015-09-15 12:48:08', '2015-09-15 12:48:08'),
(10, 'Service Delivery', 'Service Delivery', 'enabled', 0, 1, 'admin', '', 'U', '2015-09-15 12:48:21', '2015-09-15 12:48:21'),
(12, 'Operations Department ', 'Operations Department ', 'enabled', 0, 3, 'admin', '', 'U', '2015-09-15 12:49:52', '2015-09-15 12:49:52'),
(13, 'Operations Department ', 'Operations Department ', 'enabled', 0, 4, 'admin', '', 'U', '2015-09-15 12:50:07', '2015-09-15 12:50:07'),
(14, 'Operations Department ', 'Operations Department ', 'enabled', 0, 5, 'admin', '', 'U', '2015-09-15 12:51:04', '2015-09-15 12:51:04'),
(15, 'Operations Department ', 'Operations Department ', 'enabled', 0, 6, 'admin', '', 'U', '2015-09-15 12:51:21', '2015-09-15 12:51:21'),
(16, 'Administration', 'Administration', 'enabled', 1, 1, 'admin', '', 'U', '2015-09-18 11:58:42', '2015-09-18 11:58:42');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `prt_departments`
--
ALTER TABLE `prt_departments`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `prt_departments`
--
ALTER TABLE `prt_departments`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=17;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
