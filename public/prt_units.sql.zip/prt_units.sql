-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Sep 19, 2015 at 05:07 PM
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `portal`
--

-- --------------------------------------------------------

--
-- Table structure for table `prt_units`
--

CREATE TABLE IF NOT EXISTS `prt_units` (
`id` int(10) unsigned NOT NULL,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `department_id` int(11) NOT NULL DEFAULT '0',
  `unit_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `input_by` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `auth_by` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `auth_status` varchar(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'U',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `prt_units`
--

INSERT INTO `prt_units` (`id`, `parent_id`, `department_id`, `unit_name`, `status`, `input_by`, `auth_by`, `auth_status`, `created_at`, `updated_at`) VALUES
(2, 0, 3, 'Clearing Unit  ', 'enabled', 'admin', '', 'U', '2015-09-17 08:18:46', '2015-09-17 08:18:46'),
(3, 0, 3, 'Funds Transfer Unit', 'enabled', 'admin', '', 'U', '2015-09-17 08:25:45', '2015-09-17 08:25:45'),
(4, 0, 3, 'Client Support services Unit', 'enabled', 'admin', '', 'U', '2015-09-17 08:26:55', '2015-09-17 08:26:55'),
(5, 0, 3, 'Sovereign Processing Unit', 'enabled', 'admin', '', 'U', '2015-09-17 08:27:27', '2015-09-17 08:27:27'),
(6, 0, 3, 'Centralized Operations ', 'enabled', 'admin', '', 'U', '2015-09-17 08:29:30', '2015-09-17 08:29:30'),
(7, 0, 3, 'Treasury Back Office', 'enabled', 'admin', '', 'U', '2015-09-17 08:31:15', '2015-09-17 08:31:15'),
(8, 0, 3, 'Products Delivery section ', 'enabled', 'admin', '', 'U', '2015-09-17 08:34:03', '2015-09-17 08:34:03'),
(9, 8, 3, 'Cash In Transit  ', 'enabled', 'admin', '', 'U', '2015-09-17 08:34:28', '2015-09-17 08:34:28'),
(10, 0, 3, 'Administration Department  ', 'enabled', 'admin', '', 'U', '2015-09-17 08:35:34', '2015-09-17 08:35:34'),
(11, 0, 3, 'Human Resources Department', 'enabled', 'admin', '', 'U', '2015-09-17 08:35:46', '2015-09-17 08:35:46'),
(12, 0, 3, 'Training & Development  ', 'enabled', 'admin', '', 'U', '2015-09-17 08:35:55', '2015-09-17 08:35:55'),
(13, 0, 3, 'Operations ', 'enabled', 'admin', '', 'U', '2015-09-17 08:36:12', '2015-09-17 08:36:12'),
(14, 0, 3, 'Cash Management  ', 'enabled', 'admin', '', 'U', '2015-09-17 08:36:23', '2015-09-17 08:36:23'),
(15, 0, 3, 'Customer Care ', 'enabled', 'admin', '', 'U', '2015-09-17 08:36:34', '2015-09-17 08:36:34'),
(16, 0, 3, 'Branch Management Unit', 'enabled', 'admin', '', 'U', '2015-09-17 08:36:41', '2015-09-17 08:36:41'),
(17, 0, 3, 'Trade Finance Section ', 'enabled', 'admin', '', 'U', '2015-09-17 08:36:49', '2015-09-17 08:36:49'),
(18, 0, 5, 'Transactional Banking', 'enabled', 'admin', '', 'U', '2015-09-17 08:38:47', '2015-09-17 08:38:47'),
(19, 0, 5, 'Corporate Banking', 'enabled', 'admin', '', 'U', '2015-09-17 08:38:55', '2015-09-17 08:38:55'),
(20, 0, 5, 'Insititutional Banking ', 'enabled', 'admin', '', 'U', '2015-09-17 08:39:04', '2015-09-17 08:39:04'),
(21, 0, 6, 'Director  ', 'enabled', 'admin', '', 'U', '2015-09-17 08:39:51', '2015-09-17 08:39:51'),
(22, 0, 7, 'Credit Operations ', 'enabled', 'admin', '', 'U', '2015-09-17 08:40:34', '2015-09-17 08:40:34'),
(23, 0, 7, 'Credit Risk', 'enabled', 'admin', '', 'U', '2015-09-17 08:40:43', '2015-09-17 08:40:43'),
(24, 0, 7, 'Legal & Documentation', 'enabled', 'admin', '', 'U', '2015-09-17 08:40:51', '2015-09-17 08:40:51'),
(25, 0, 7, 'Credit  ', 'enabled', 'admin', '', 'U', '2015-09-17 08:40:57', '2015-09-17 08:40:57'),
(26, 0, 7, 'Sales  ', 'enabled', 'admin', '', 'U', '2015-09-17 08:41:03', '2015-09-17 08:41:03'),
(27, 0, 7, 'Forex  ', 'enabled', 'admin', '', 'U', '2015-09-17 08:41:09', '2015-09-17 08:41:09'),
(28, 0, 7, 'Treasury  ', 'enabled', 'admin', '', 'U', '2015-09-17 08:41:15', '2015-09-17 08:41:15');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `prt_units`
--
ALTER TABLE `prt_units`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `prt_units`
--
ALTER TABLE `prt_units`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=29;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
