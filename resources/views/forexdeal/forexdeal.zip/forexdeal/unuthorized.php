<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Bank M Portal</title>
<style type="text/css">
<!--
.style6 {font-size: 11px}
.style11 {font-family: tahoma; font-size: 11px; color: #0E3793; }
.style1 {	font-family: tahoma;
	font-size: 12px;
	color: #FFFFFF;
}
body {
	background-image: url(../../images/backgrounds/pagebg.png);
}
.style15 {
	font-size: 11px;
	color: #FFFFFF;
}
-->
</style>
<script type="text/javascript">
function validateForm()
{
var x=document.forms["SubmitDepartment"]["department"].value;
var atpos=x.indexOf("Please Select Department");
var dotpos=x.lastIndexOf(".");
if (atpos<1 || dotpos<atpos+2 || dotpos+2>=x.length)
  {
  alert("Not a valid Department Name");
  return false;
  }
}
</script>
</head>

<body>
<table width="100%" border="0" cellpadding="5" cellspacing="0">
  <tr>
    <td></td>
  </tr>
</table>
<form action="log-queriepage.php" method="get" name="SubmitDepartment" id="SubmitDepartment">
  <table width="98%" height="30"  border="0" align="center" cellpadding="0" cellspacing="0" class="style11" >
    <tr class="style6">
      <td width="29%" height="20" align="center" nowrap ><img src="../../../images/backgrounds/restricted.png" width="104" height="139"><br>
        <span class="style15">Authorize restricted<br>
You are not authorized to view the content of this module<br>
please contact ICT department for assistance </span></td>
    </tr>
  </table>
</form>
<p align="center"><span class="style1">
  
  
</span></p>
<p>&nbsp;</p>
</body>
</html>
