<?php
$con=mysql_connect("localhost","root","") or die(mysql_error());
$db_name= 'bmpl_forexdealportal';
mysql_select_db($db_name, $con) or die(mysql_error());
?>
