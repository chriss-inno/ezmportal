<?php
	session_start();
	
	
	
$user_id       = $_SESSION['SESS_USER_ID'];
$log_ipaddress = $_SERVER['REMOTE_ADDR']; 
$log_compuser  = gethostbyaddr($_SERVER['REMOTE_ADDR']);
$log_datetime  = date("d/m/y : H:i:s", time());
$log_activity  = "ForexDealAccessDenied";
$log_comment   = "PageOpened";
mysql_connect("localhost","root",""); 
mysql_select_db("bmpl_system") or die("Unable to select database");
@mysql_query("INSERT INTO sys_log(user_id, log_datetime, log_activity, log_comment, log_ipaddress, log_compuser)
VALUES('$user_id','$log_datetime','$log_activity','$log_comment','$log_ipaddress', '$log_compuser')");	
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Bank M Portal</title>
<style type="text/css">
<!--
.style6 {font-size: 11px}
.style11 {font-family: tahoma; font-size: 11px; color: #0E3793; }
.style1 {	font-family: tahoma;
	font-size: 12px;
	color: #FFFFFF;
}
.style12 {color: #FFFFFF}
body {
	background-image: url(../images/backgrounds/pagebg.png);
}
.style14 {color: #FFFFFF; font-size: 12px; }
a:link {
	color: #FFFFFF;
	text-decoration: none;
}
a:visited {
	text-decoration: none;
	color: #FFFFFF;
}
a:hover {
	text-decoration: none;
	color: #FFFFFF;
}
a:active {
	text-decoration: none;
	color: #FFFFFF;
}
-->
</style>
<script type="text/javascript">
function validateForm()
{
var x=document.forms["SubmitDepartment"]["department"].value;
var atpos=x.indexOf("Please Select Department");
var dotpos=x.lastIndexOf(".");
if (atpos<1 || dotpos<atpos+2 || dotpos+2>=x.length)
  {
  alert("Not a valid Department Name");
  return false;
  }
}
</script>
</head>

<body>
<table width="100%" border="0" cellpadding="5" cellspacing="0">
  <tr>
    <td></td>
  </tr>
</table>
<form action="../portal/log-queriepage.php" method="get" name="SubmitDepartment" id="SubmitDepartment">
  <table width="100%" height="408"  border="0" align="center" cellpadding="0" cellspacing="0" class="style11" style="border-left: 1px solid #7F9DB9; border-right: 1px solid #7F9DB9; border-top: 1px solid #7F9DB9; border-bottom: 1px solid #7F9DB9;">
    <tr class="style6">
      <td width="29%" height="406" align="center" nowrap ><p><img src="../images/backgrounds/bankMlogo.png" width="104" height="139"></p>
        <p><span class="style14"> <blink>Module on Maintainance </blink></span></p>
        <p class="style12">Bank M (Tanzania) Limited Services System Portal is a helpdesk web based application managed by the ICT software support group<br>
  allows users to post, retrieve various information and  log problems to ICT department or Administration department, ask clarifications <br>
  for functional and technical queries, track the problem reported, browse queries, seek <br>
  solutions to the standard problems faced. This web based tool is used to capture user <br>
  queries, track the closure mechanism, provide support for the powerful search facility and enables <br>
  us to keep our users updated on the status of the issue - round the clock and at every stage <br>
  right from issue logging to issue<a href="index.php"> r</a>esolution.</p>
        <p>&nbsp;</p>
      <p>&nbsp;</p></td>
    </tr>
  </table>
</form>
<p align="center"><span class="style1">
  
  
</span></p>
<p>&nbsp;</p>
</body>
</html>
