<?php
session_start();
$loginUser_id = $_SESSION['SESS_USER_ID'];
require_once('../../config/auth_content.php');
	
	
$user_id       = $_SESSION['SESS_USER_ID'];
$log_ipaddress = $_SERVER['REMOTE_ADDR']; 
$log_compuser  = gethostbyaddr($_SERVER['REMOTE_ADDR']);
$log_datetime  = date("d/m/y : H:i:s", time());
$log_activity  = "ForexDealInputSearchOpened";
$log_comment   = "PageOpened";
mysql_connect("localhost","root",""); 
mysql_select_db("bmpl_system") or die("Unable to select database");
@mysql_query("INSERT INTO sys_log(user_id, log_datetime, log_activity, log_comment, log_ipaddress, log_compuser)
VALUES('$user_id','$log_datetime','$log_activity','$log_comment','$log_ipaddress', '$log_compuser')");	
?>	
<style type="text/css">
<!--
.style24 {color: #0E3793}
.style24 {color: #0E3793}
.style25 {color: #0E3793}
.style25 {color: #0E3793}
.style26 {color: #0E3793}
.style26 {color: #0E3793}
a:link {
	text-decoration: none;
	color: #005DAE;
}
a:visited {
	text-decoration: none;
	color: #005DAE;
}
a:hover {
	text-decoration: none;
	color: #FE0003;
}
a:active {
	text-decoration: none;
	color: #005DAE;
}
.style32 {font-family: tahoma; font-size: 11px; color: #0E3793; }
.style32 {font-family: tahoma; font-size: 11px; color: #0E3793; }
.style33 {color: #0E3793}
.style33 {color: #0E3793}
.style35 {font-size: 14px}
.style35 {font-size: 14px}
.style27 {color: #0E3793}
.style27 {color: #0E3793}
.style28 {color: #0E3793}
.style28 {color: #0E3793}
.style36 {color: #0E3793}
.style36 {color: #0E3793}
.style37 {font-size: 11px}
.style37 {font-size: 11px}
.style39 {font-family: tahoma; font-size: 11px; color: #0E3793; }
.style39 {font-family: tahoma; font-size: 11px; color: #0E3793; }
.style41 {font-family: tahoma; font-size: 11px; color: #0E3793; }
.style41 {font-family: tahoma; font-size: 11px; color: #0E3793; }
body {
	background-image: url(images/pagebg.png);
}
.style43 {
	color: #FFFFFF;
	font-size: 11px;
}
.style44 {
	font-size: 12px;
	font-weight: bold;
	color: #FFFFFF;
}
.style2 {color: #0E3793;
	font-weight: bold;
}
.style3 {font-size: 11px;
	font-family: tahoma;
	color: #FFFFFF;
}
.style46 {font-family: tahoma; font-size: 11px; color: #0E3793; }
.style46 {font-family: tahoma; font-size: 11px; color: #0E3793; }
.style47 {color: #0E3793}
.style47 {color: #0E3793}
.style49 {font-size: 11px; font-family: tahoma; color: #FFFFFF; font-weight: bold; }
.style50 {color: #FFFFFF}
-->
</style>
<table width="100%" border="0" cellpadding="5" cellspacing="0">
  <tr>
    <td></td>
  </tr>
</table>
<table width="100%"  border="0" align="center" cellpadding="0" cellspacing="0" style="border-bottom: 1px solid #7F9DB9; border-left: 1px solid #7F9DB9; border-right: 1px solid #7F9DB9; border-top: 1px solid #7F9DB9; ">
  <tr>
    <td width="95%" height="20" nowrap ><table width="100%" height="20"  border="0" align="center" cellpadding="0" cellspacing="0" style="border-bottom: 1px solid #7F9DB9;">
        <tr >
          <td width="96%" height="19" nowrap bgcolor="#E1204F"><span class="style2">&nbsp;<span class="style3">FOREX DEAL</span></span></td>
        </tr>
    </table></td>
  </tr>
  <tr>
    <td height="648" valign="top" nowrap><div align="center">
      <p> </p>
      <table width="975"  border="0" align="center" cellpadding="0" cellspacing="0" >
        <tr>
          <td width="95%" height="20" nowrap class="style47" ><form name="form1" method="post" action="">
              <br/>
              <table width="93%" height="108"  border="0" align="center" cellpadding="0" cellspacing="0" class="style32" " >
                <tr class="style37">
                  <td width="28%" height="20" align="right" nowrap style="border-bottom: 1px solid #7F9DB9;"><div align="center" class="style44">
                    <div align="left" class="style3">
                      <table width="100%" height="31"  border="0" align="center" cellpadding="0" cellspacing="0" class="style32" >
                        <tr class="style35">
                          <td width="21%" height="31" align="left" nowrap ><div align="right" class="style43"></div></td>
                          <td width="79%" align="left" nowrap ><div align="left">
                              <table width="100%" height="35"  border="0" align="center" cellpadding="0" cellspacing="0" class="style32" >
                                <tr class="style35">
                                  <td width="2%" height="35" align="left" nowrap class="style49" >Search for a deal to edit or print </td>
                                  </tr>
                              </table>
                          </div></td>
                        </tr>
                      </table>
                    </div>
                  </div></td>
                </tr>
                <tr class="style37">
                  <td height="66" align="right" nowrap ><table width="100%" height="71"  border="0" align="center" cellpadding="0" cellspacing="0" class="style32" >
                      <tr class="style35">
                        <td width="21%" height="27" align="left" nowrap ><div align="right" class="style43">DEAL NO.</div></td>
                        <td width="79%" align="left" nowrap ><div align="left">
                            <table width="100%" height="20"  border="0" align="center" cellpadding="0" cellspacing="0" class="style32" >
                              <tr class="style35">
                                <td width="99%" height="20" align="left" nowrap ><div align="left"> <strong>
                                    <input name="number" class="style39" id="number" type="text" style="border-bottom: 1px solid #7F9DB9;text-transform:uppercase;" size="20">
                                </strong></div></td>
                              </tr>
                            </table>
                        </div></td>
                      </tr>
                      <tr class="style35">
                        <td height="17" align="left" nowrap >&nbsp;</td>
                        <td align="left" nowrap >&nbsp;</td>
                      </tr>
                      <tr class="style35">
                        <td height="27" align="left" nowrap >&nbsp;</td>
                        <td align="left" nowrap ><strong>
                          <input name="search" type="submit" class="style39" id="search" value="Search" >
                        </strong></td>
                      </tr>
                    </table>
                      </td>
                  <?php
    if (isset($_POST['search'])) 
    {
	    $number = $_POST['number'];
	    mysql_connect("localhost", "root", "") or die(mysql_error());
        mysql_select_db("bmpl_forexdealportal") or die(mysql_error());
        $result = mysql_query("SELECT * FROM fd_dealslip WHERE fds_deal_number = '$number' ") or die(mysql_error());  
        while($row = mysql_fetch_array( $result )) 
         {  
		$fds_deal_serial        = $row['fds_deal_serial'];	
		$fds_deal_number        = $row['fds_deal_number'];	
		$fds_deal_time          = $row['fds_deal_time'];	
		$fds_deal_date          = $row['fds_deal_date'];	
		$fds_value_date         = $row['fds_value_date'];	
		$fds_counter_party      = $row['fds_counter_party'];	
		$fds_curr_amount_bought = $row['fds_curr_amount_bought'];	
		$fds_rate               = $row['fds_rate'];	
		$fds_curr_amount_sold   = $row['fds_curr_amount_sold'];	
		$fds_confirmed_with     = $row['fds_confirmed_with'];	
		$fds_bankm_dealer       = $row['fds_bankm_dealer'];	
		$fds_mobile             = $row['fds_mobile'];	
		$fds_confirmed_time     = $row['fds_confirmed_time'];	
		$fds_spl_instruction    = $row['fds_spl_instruction']; 
		$fds_spl_email          = $row['fds_spl_email'];
         } 
	}
	
	?>
                </tr>
              </table>
            </form>
              </td>
        </tr>
        <tr>
          <td height="464" valign="top" nowrap><form action="forexdealsearchexe.php" method="post" name="forexdealslip" target="_blank" id="forexdealslip">
              <table width="93%" height="363"  border="0" align="center" cellpadding="0" cellspacing="0" class="style32"  >
                <tr class="style37">
                  <td width="28%" height="15" align="right" nowrap style="border-bottom: 1px solid #7F9DB9;"><div align="center" class="style44">
                    <table width="100%" height="31"  border="0" align="center" cellpadding="0" cellspacing="0" class="style32" >
                      <tr class="style35">
                        <td width="21%" height="31" align="left" nowrap ><div align="right" class="style43"></div></td>
                        <td width="79%" align="left" nowrap ><div align="left">
                            <table width="100%" height="35"  border="0" align="center" cellpadding="0" cellspacing="0" class="style32" >
                              <tr class="style35">
                                <td width="2%" height="35" align="left" nowrap class="style49" > Forex deal slip </td>
                              </tr>
                            </table>
                        </div></td>
                      </tr>
                    </table>
                    </div></td>
                </tr>
                <tr class="style37">
                  <td height="322" align="right" nowrap ><table width="100%" height="337"  border="0" align="center" cellpadding="0" cellspacing="0" class="style32" >
                      <tr class="style43">
                        <td width="15%" height="31" align="right" nowrap >&nbsp;</td>
                        <td width="15%" align="left" nowrap ><div align="left">DEAL NO: </div></td>
                        <td width="70%" align="left" nowrap ><div align="left">
                            <table width="100%" height="35"  border="0" align="center" cellpadding="0" cellspacing="0" class="style32" >
                              <tr class="style35">
                                <td width="32%" height="35" align="left" nowrap ><div align="left" class="style43"> <strong> <?php echo "$fds_deal_number"; ?>
                                          <input name="number1" type="hidden" class="style33" id="number1" style="border-bottom: 1px solid #7F9DB9;text-transform:uppercase;" value="<?php echo "$fds_deal_number"  ; ?>" size="17">
                                </strong></div></td>
                                <td width="15%" nowrap ><div align="left" class="style43">TIME: </div>
                                    <div align="left"></div></td>
                                <td width="53%" align="left" nowrap ><div align="left"> <strong>
                                    <input name="fds_deal_time" type="text" class="style39" id="fds_deal_time" style="border-bottom: 1px solid #7F9DB9; text-transform:uppercase;" value="<?php echo "$fds_deal_time"; ?>" size="8">
                                </strong></div></td>
                              </tr>
                            </table>
                        </div></td>
                      </tr>
                      <tr class="style43">
                        <td height="30" align="right" nowrap >&nbsp;</td>
                        <td align="left" nowrap ><div align="left">DEAL DATE: </div></td>
                        <td align="left" nowrap ><div align="left">
                            <table width="100%" height="35"  border="0" align="center" cellpadding="0" cellspacing="0" class="style32" >
                              <tr class="style35">
                                <td width="32%" height="35" align="left" nowrap ><div align="left">
                                    <input name="fds_deal_date" type="text" class="style39" id="fds_deal_date" style="border-bottom: 1px solid #7F9DB9;text-transform:uppercase;" value="<?php echo "$fds_deal_date"; ?>" size="8">
                                </div></td>
                                <td width="15%" nowrap ><div align="left" class="style43">VALUE DATE:</div>
                                    <div align="left"></div></td>
                                <td width="53%" align="left" nowrap ><div align="left">
                                    <input name="fds_value_date" type="text" class="style39" id="fds_value_date" style="border-bottom: 1px solid #7F9DB9;text-transform:uppercase;" value="<?php echo "$fds_value_date"; ?>" size="8">
                                </div></td>
                              </tr>
                            </table>
                        </div></td>
                      </tr>
                      <tr class="style43">
                        <td height="31" align="right" nowrap >&nbsp;</td>
                        <td align="left" nowrap ><div align="left">COUNTER PARTY: </div></td>
                        <td align="left" nowrap ><div align="left">
                            <input name="fds_counter_party" type="text" class="style39" id="fds_counter_party"  style="border-bottom: 1px solid #7F9DB9; text-transform:uppercase;" value="<?php echo "$fds_counter_party"; ?>" size="65">
                        </div></td>
                      </tr>
                      <tr class="style43">
                        <td height="35" align="right" nowrap >&nbsp;</td>
                        <td align="left" nowrap ><div align="left">CURR. &amp; AMOUNT SOLD:</div></td>
                        <td align="left" nowrap ><div align="left">
                            <input name="fds_curr_amount_sold" type="text" class="style39" id="fds_curr_amount_sold" style="border-bottom: 1px solid #7F9DB9;text-transform:uppercase;" value="<?php echo "$fds_curr_amount_sold"; ?>" size="17" >
                        </div></td>
                      </tr>
                      <tr class="style43">
                        <td height="35" align="right" nowrap >&nbsp;</td>
                        <td align="left" nowrap ><div align="left">RATE:</div></td>
                        <td align="left" nowrap ><div align="left">
                            <input name="fds_rate" type="text" class="style39" id="fds_rate" style="border-bottom: 1px solid #7F9DB9;text-transform:uppercase;" value="<?php echo "$fds_rate"; ?>" size="17">
                        </div></td>
                      </tr>
                      <tr class="style43">
                        <td height="35" align="right" nowrap >&nbsp;</td>
                        <td align="left" nowrap ><div align="left">CURR. &amp; AMOUNT BOUGHT :</div></td>
                        <td align="left" nowrap ><input name="fds_curr_amount_bought" type="text" class="style39" id="fds_curr_amount_bought" style="border-bottom: 1px solid #7F9DB9;text-transform:uppercase;" value="<?php echo "$fds_curr_amount_bought"; ?>" size="17">
                        </td>
                      </tr>
                      <tr class="style43">
                        <td height="35" align="right" nowrap >&nbsp;</td>
                        <td align="left" nowrap ><div align="left">DEAL CONFIRMED WITH: </div></td>
                        <td align="left" nowrap ><table width="100%" height="35"  border="0" align="center" cellpadding="0" cellspacing="0" class="style32" >
                            <tr class="style35">
                              <td width="33%" height="35" align="left" nowrap ><div align="left">
                                  <input name="fds_confirmed_with" type="text" class="style39" id="fds_confirmed_with" style="border-bottom: 1px solid #7F9DB9; text-transform:uppercase;" value="<?php echo "$fds_confirmed_with"; ?>" size="30">
                              </div></td>
                              <td width="14%" nowrap ><div align="left" class="style43">BANK M DEALER:</div>
                                  <div align="left"></div></td>
                              <td width="53%" align="left" nowrap ><div align="left">
                                  <input name="fds_bankm_dealer" type="text" class="style39" id="fds_bankm_dealer" style="border-bottom: 1px solid #7F9DB9; text-transform:uppercase;" value="<?php echo "$fds_bankm_dealer"; ?>" size="20">
                              </div></td>
                            </tr>
                        </table></td>
                      </tr>
                      <tr class="style43">
                        <td height="35" align="right" nowrap >&nbsp;</td>
                        <td align="left" nowrap ><div align="left">PHONE/ MOBILE NO.: </div></td>
                        <td align="left" nowrap ><table width="100%" height="35"  border="0" align="center" cellpadding="0" cellspacing="0" class="style32" >
                            <tr class="style35">
                              <td width="33%" height="35" align="left" nowrap ><div align="left">
                                  <input name="fds_mobile" type="text" class="style39" id="fds_mobile" style="border-bottom: 1px solid #7F9DB9;text-transform:uppercase;" value="<?php echo "$fds_mobile"; ?>" size="17">
                              </div></td>
                              <td width="14%" nowrap ><div align="left" class="style43">TIME: </div>
                                  <div align="left"></div></td>
                              <td width="53%" align="left" nowrap ><div align="left">
                                  <input name="fds_confirmed_time" type="text" class="style39" id="fds_confirmed_time" style="border-bottom: 1px solid #7F9DB9;text-transform:uppercase;" value="<?php echo "$fds_confirmed_time"; ?>" size="8">
                              </div></td>
                            </tr>
                        </table></td>
                      </tr>
                      <tr class="style43">
                        <td height="35" align="right" nowrap >&nbsp;</td>
                        <td align="left" nowrap ><div align="left">SPL. INSTRUCTION:</div></td>
                        <td align="left" nowrap ><input name="fds_spl_instruction" type="text" class="style39" id="fds_spl_instruction" style="border-bottom: 1px solid #7F9DB9; text-transform:uppercase;" value="<?php echo "$fds_spl_instruction"; ?>" size="65"></td>
                      </tr>
                      <tr class="style43">
                        <td height="35" align="right" nowrap >&nbsp;</td>
                        <td align="left" nowrap >CUSTOMER E-MAIL ID:</td>
                        <td align="left" nowrap ><input name="fds_spl_email" type="text" class="style46" id="fds_spl_email" style="border-bottom: 1px solid #7F9DB9; text-transform:uppercase;" value="<?php echo "$fds_spl_email"; ?>" size="65"></td>
                      </tr>
                  </table></td>
                </tr>
              </table>
              <table width="100%" height="62"  border="0" align="center" cellpadding="0" cellspacing="0" class="style32" >
                <tr class="style35">
                  <td height="31" align="left" nowrap style="border-bottom: 1px solid #7F9DB9;"><table width="100%" height="46"  border="0" align="center" cellpadding="0" cellspacing="0" class="style32" >
                      <tr class="style35">
                        <td height="17" align="left" nowrap >&nbsp;</td>
                        <td align="left" nowrap >&nbsp;</td>
                      </tr>
                      <tr class="style35">
                        <td width="21%" height="29" align="left" nowrap ><div align="right" class="style43"></div></td>
                        <td width="79%" align="left" nowrap ><div align="left">
                            <table width="100%" height="20"  border="0" align="center" cellpadding="0" cellspacing="0" class="style32" >
                              <tr class="style35">
                                <td width="2%" height="20" align="left" nowrap class="style49" >Action </td>
                              </tr>
                            </table>
                        </div></td>
                      </tr>
                  </table></td>
                </tr>
                <tr class="style35">
                  <td width="50%" height="31" align="left" nowrap ><div align="center">
                      <table width="100%" height="31"  border="0" align="center" cellpadding="0" cellspacing="0" class="style32" >
                        <tr class="style35">
                          <td width="21%" height="31" align="left" nowrap ><div align="right" class="style43"></div></td>
                          <td width="79%" align="left" nowrap ><div align="left">
                              <table width="100%" height="35"  border="0" align="center" cellpadding="0" cellspacing="0" class="style32" >
                                <tr class="style35">
                                  <td width="2%" align="left" nowrap >&nbsp;</td>
                                  <td width="98%" height="35" align="left" nowrap ><div align="left"> <strong><a href="index.php">
                                    <input type="button" class="style41" value="Back" >
&nbsp;</a>&nbsp;
<input name="editreprint" type="submit" class="style46" id="editreprint" value="Update and Print" >
&nbsp;&nbsp;
<input name="printonly" type="submit" class="style39" id="printonly" value="Print Only" >

                                        </strong></div></td>
                                </tr>
                              </table>
                          </div></td>
                        </tr>
                      </table>
                  </div></td>
                </tr>
              </table>
              </form></td>
        </tr>
      </table>
    </div></td>
  </tr>
</table>
<p></br>
</p>
