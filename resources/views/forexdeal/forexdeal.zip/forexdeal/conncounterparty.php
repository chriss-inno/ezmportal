<?php
session_start();
//connectiong to the databas

if(isset($_POST['save']))
{
	if(empty($_POST['cparty']))
	{
		$sms="Please enter customer name";
	}
	else
	{
		$cp=$_POST['cparty'];
	}
	if(empty($_POST['rm']))
	{
		$mrm="Please enter RM code";
	}
	else
	{
		$rm=$_POST['rm'];
	}
	if($sms||$mrm)
	{
		include'counterparty.php';
	}
	if($cp&&$rm)
	{
		include'connect.php';
		$sql=mysql_query("insert into fd_customer(customer,rm_code)values('".$cp."','".$rm."')");
		if($sq1)
		{
			$sms="OK";
			include'counterparty.php';
		}
	}
}
	
?>
