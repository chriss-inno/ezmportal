<html>
<head>
<script language="javascript">
function download()
{
	window.location='report.xls';
}
</script>
</head>
<body alink="#00FF66" link="#00CC00">
<h1 align="center"><a href="javascript:void(0);" onClick="download();">Download Excel Report</a></h1>
<?php
require_once("connect.php");
require_once("excelwriter.class.php");

$excel=new ExcelWriter("report.xls");
if($excel==false)	
echo $excel->error;

$myArr=array("S/N","BM","Last name","First name","Middle name","Birth date");
$excel->writeLine($myArr);

$qry=mysql_query("SELECT * FROM hs_hr_employee where emp_gender='1'");
if(mysql_num_rows($qry)>0)
{
	$i=1;
	while($res=mysql_fetch_array($qry))
	{
		$myArr=array($i,$res['employee_id'],$res['emp_lastname'],$res['emp_firstname'],$res['emp_middle_name'],$res['emp_birthdate']);
		$excel->writeLine($myArr);
		$i++;
	}
}
?>
</body>
</html>