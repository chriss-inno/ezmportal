<?php
class Days{
	
	public function calculateTime($date2,$date1)
	{
		 $diff=strtotime($date2)-strtotime($date1);
		$years = floor($diff / (60*60*24*365));
		return $years;
	}
}
?>