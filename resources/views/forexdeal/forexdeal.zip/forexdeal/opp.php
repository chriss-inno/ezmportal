<?php
session_start();
$loginUser_id = $_SESSION['SESS_USER_ID'];
require_once('../../config/auth_content.php');

$user_id       = $_SESSION['SESS_USER_ID'];
$log_ipaddress = $_SERVER['REMOTE_ADDR']; 
$log_compuser  = gethostbyaddr($_SERVER['REMOTE_ADDR']);
$log_datetime  = date("d/m/y : H:i:s", time());
$log_activity  = "ForexDealOppPageOpened";
$log_comment   = "PageOpened";
mysql_connect("localhost","root",""); 
mysql_select_db("bmpl_system") or die("Unable to select database");
@mysql_query("INSERT INTO sys_log(user_id, log_datetime, log_activity, log_comment, log_ipaddress, log_compuser)
VALUES('$user_id','$log_datetime','$log_activity','$log_comment','$log_ipaddress', '$log_compuser')");	
?>	
<script src="jquery.min.js" type="text/javascript"></script>
<script src="jqprint.0.3.js" type="text/javascript"></script>
<script language="javascript" type="text/javascript">
$(function() {
                $("#PrintVocab").click( function() {
                    $('#divToPrint').jqprint();
                    return false;
                });
             });
</script>
<style type="text/css">
<!--
.style6 {font-size: 11px}
-->
</style>
<style type="text/css">
<!--
.style1 {
	font-family: tahoma;
	color: #0E3793;
	font-size: 11px;
}
.style21 {font-family: tahoma; font-size: 11px; color: #0E3793; }
.style21 {font-family: tahoma; font-size: 11px; color: #0E3793; }
.style22 {font-size: 14px}
.style22 {font-size: 14px}
.style23 {font-size: 13px}
.style27 {font-size: 12px}
.style28 {
	font-size: 16px;
	font-weight: bold;
}
a {
	font-family: tahoma;
	font-size: 16px;
	color: #0E3793;
}
a:link {
	text-decoration: none;
}
a:visited {
	text-decoration: none;
	color: #0E3793;
}
a:hover {
	text-decoration: none;
	color: #0E3793;
}
a:active {
	text-decoration: none;
	color: #0E3793;
}
-->
</style>
<div align="center">

  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <form action="index.php" method="post" name="returnTomainPage" id="returnTomainPage">
    <span class="style1">
    <span class="style21">
    <?php			  
$number         = $_POST['number1'];
$dealtime       = $_POST['fds_deal_time'];
$dealdate       = $_POST['fds_deal_date'];
$valuedate      = $_POST['fds_value_date'];
$counterparty   = $_POST['fds_counter_party'];
$amtsold        = $_POST['fds_curr_amount_sold'];
$rate           = $_POST['fds_rate'];
$amtbought      = $_POST['fds_curr_amount_bought'];
$confirmdwith   = $_POST['fds_confirmed_with'];
$bnkmdealer     = $_POST['fds_bankm_dealer'];
$mobile         = $_POST['fds_mobile'];
$cnfrmdtime     = $_POST['fds_confirmed_time'];
$slpinstruction = $_POST['fds_spl_instruction'];
$splemail       = $_POST['fds_spl_email'];


	  
      if($number == "") 	
	                   {
					   echo'</br>';echo'</br>';
                       echo'<span class="style17"><span class="style36">Deal number details missing</span></span>';
                       echo'</br>';echo'</br>';
					   echo "<INPUT TYPE=button class=style11 VALUE=Back onClick=history.go(-1);return true;>";
				       exit; 
					   } 	 	 	 	 	 	 
      if($dealtime   == "")	
	                   {
					   echo'</br>';echo'</br>';
                       echo'<span class="style17"><span class="style36">Deal time details missing</span></span>';
                       echo'</br>';echo'</br>';
					   echo "<INPUT TYPE=button class=style11 VALUE=Back onClick=history.go(-1);return true;>";
				       exit; 
					   }  	 	 	 	 	 	 
      if($dealdate  == "") 	
	                   {
					   echo'</br>';echo'</br>';
                       echo'<span class="style17"><span class="style36">Deal date details missing</span></span>';
                       echo'</br>';echo'</br>';
					   echo "<INPUT TYPE=button class=style11 VALUE=Back onClick=history.go(-1);return true;>";
				       exit; 
					   }  	 	 	 	 
      if($valuedate  == "") 	
	                   {
					   echo'</br>';echo'</br>';
                       echo'<span class="style17"><span class="style36">Value date details missing</span></span>';
                       echo'</br>';echo'</br>';
					   echo "<INPUT TYPE=button class=style11 VALUE=Back onClick=history.go(-1);return true;>";
				       exit; 
					   }  	 	 	 	 	 
      if($counterparty == "") 
	                   {
					   echo'</br>';echo'</br>';
                       echo'<span class="style17"><span class="style36">Counter party details missing</span></span>';
                       echo'</br>';echo'</br>';
					   echo "<INPUT TYPE=button class=style11 VALUE=Back onClick=history.go(-1);return true;>";
				       exit; 
					   } 	 
					   	 	 	 	 	 
      if($amtbought == '') 
	                   {
					   echo'</br>';echo'</br>';
                       echo'<span class="style17"><span class="style36">Curr. amount bought details missing</span></span>';
                       echo'</br>';echo'</br>';
					   echo "<INPUT TYPE=button class=style11 VALUE=Back onClick=history.go(-1);return true;>";
				       exit; 
					   } 	 	 	 	 	 
      if($rate == '')  	
	                   {
					   echo'</br>';echo'</br>';
                       echo'<span class="style17"><span class="style36">Rate details missing</span></span>';
                       echo'</br>';echo'</br>';
					   echo "<INPUT TYPE=button class=style11 VALUE=Back onClick=history.go(-1);return true;>";
				       exit; 
					   }  	 	 	 
      if($amtsold == "")	
	                   {
					   echo'</br>';echo'</br>';
                       echo'<span class="style17"><span class="style36">Curr. amount sold details missing</span></span>';
                       echo'</br>';echo'</br>';
					   echo "<INPUT TYPE=button class=style11 VALUE=Back onClick=history.go(-1);return true;>";
				       exit; 
					   }  	 	 	 	 	 	 
      if($confirmdwith == "")	
	                   {
					   echo'</br>';echo'</br>';
                       echo'<span class="style17"><span class="style36">Confirmed with details missing</span></span>';
                       echo'</br>';echo'</br>';
					   echo "<INPUT TYPE=button class=style11 VALUE=Back onClick=history.go(-1);return true;>";
				       exit; 
					   }  	 	 	 	 	 	 
      	 
      if($mobile == "")	 
	                   {
					   echo'</br>';echo'</br>';
                       echo'<span class="style17"><span class="style36">Mobile details missing</span></span>';
                       echo'</br>';echo'</br>';
					   echo "<INPUT TYPE=button class=style11 VALUE=Back onClick=history.go(-1);return true;>";
				       exit; 
					   } 	 	 
					   
					   
	if($bnkmdealer == "")	 
	                   {
					   echo'</br>';echo'</br>';
                       echo'<span class="style17"><span class="style36">Bank M Dealer details missing</span></span>';
                       echo'</br>';echo'</br>';
					   echo "<INPUT TYPE=button class=style11 VALUE=Back onClick=history.go(-1);return true;>";
				       exit; 
					   } 	 
					   
					   
      if($cnfrmdtime == "") 
	                   {
					   echo'</br>';echo'</br>';
                       echo'<span class="style17"><span class="style36">Confirmed time details missing</span></span>';
                       echo'</br>';echo'</br>';
					   echo "<INPUT TYPE=button class=style11 VALUE=Back onClick=history.go(-1);return true;>";
				       exit; 
					   } 	 	 	 	 	 	 
      if($slpinstruction == "")
	                   {
					   echo'</br>';echo'</br>';
                       echo'<span class="style17"><span class="style36">Slp. instruction details missing</span></span>';
                       echo'</br>';echo'</br>';
					   echo "<INPUT TYPE=button class=style11 VALUE=Back onClick=history.go(-1);return true;>";
				       exit; 
					   } 
					   
		
					   
			   mysql_connect("localhost", "root", "") or die(mysql_error());
               mysql_select_db("bmpl_forexdealportal") or die(mysql_error());		   

               $qry = "UPDATE fd_dealslip SET fds_deal_time = UPPER('$dealtime'), fds_deal_date = UPPER('$dealdate'), fds_value_date = UPPER('$valuedate'), fds_counter_party = UPPER('$counterparty'), fds_curr_amount_bought = UPPER('$amtbought'), fds_rate = UPPER('$rate'), fds_curr_amount_sold = UPPER('$amtsold'), fds_confirmed_with = UPPER('$confirmdwith'), fds_bankm_dealer = UPPER('$bnkmdealer'), fds_mobile = UPPER('$mobile'), fds_confirmed_time = UPPER('$cnfrmdtime'), fds_spl_instruction = UPPER('$slpinstruction'), fds_spl_email = '$splemail' 
			   WHERE fds_deal_number = '$number'";
	           $result = @mysql_query($qry);
  
  
  ?>
    </span>    </span>
  </form>
  
  
  <?php
                       
					    
					    mysql_connect("localhost", "root", "") or die(mysql_error());
                        mysql_select_db("bmpl_forexdealportal") or die(mysql_error());
                        $result = mysql_query("SELECT * FROM fd_dealslip WHERE fds_deal_number = UPPER('$number') ") or die(mysql_error());  
                        while($row = mysql_fetch_array( $result )) 
                        {  

						$fds_deal_number         = $row['fds_deal_number'];	 	 	 	 	 	 	 	 
						$fds_deal_time	         = $row['fds_deal_time'];	 	 	 	 	 	 	 
						$fds_deal_date 	         = $row['fds_deal_date']; 	 	 	 	 	 
						$fds_value_date 	     = $row['fds_value_date']; 	 	 	 	 	 	 
						$fds_counter_party 	     = $row['fds_counter_party']; 	 	 	 	 	 	 
						$fds_curr_amount_bought  = $row['fds_curr_amount_bought']; 	 	 	 	 	 
						$fds_rate 	             = $row['fds_rate'];  	 	 	 	 
						$fds_curr_amount_sold	 = $row['fds_curr_amount_sold'];	 	 	 	 	 	 	 
						$fds_confirmed_with	     = $row['fds_confirmed_with']; 	 	 	 	 	 	 	 
						$fds_bankm_dealer	     = $row['fds_bankm_dealer']; 	 	 	 	 	 	 	 
						$fds_mobile              = $row['fds_mobile']; 	 	 	 	 
						$fds_confirmed_time      = $row['fds_confirmed_time']; 	 	 	 	 	 	 
						$fds_spl_instruction     = $row['fds_spl_instruction'];
						$fds_spl_email           = $row['fds_spl_email'];
						
                        } 
           
                        ?>
						
						
						
						
  <style type="text/css">
<!--
.style11 {font-family: tahoma; font-size: 11px; color: #0E3793; }
.style17 {color: #0E3793}
.style19 {	font-size: 18px;
	font-weight: bold;
}
.style20 {font-size: 14px}
.style6 {font-size: 11px}
.style22 {font-family: tahoma; font-size: 12px; color: #0E3793; }
.style23 {color: #7F9DB9}
-->
</style>

<div id="divToPrint">

<table width="1030"  border="0" align="center" cellpadding="0" cellspacing="0" >
  <tr>
    <td width="95%" height="300" valign="top" nowrap><form action="forexdealexe.php" method="post" name="forexdealslip" id="forexdealslip">
      <table width="98%" height="353"  border="0" align="center" cellpadding="0" cellspacing="0" class="style21"  >
        <tr class="style6">
          <td height="23" align="right" nowrap ><div align="center"><span class="style28">FOREX DEAL SLIP</span></div></td>
        </tr>
        <tr class="style6">
          <td width="28%" height="5" align="right" nowrap ><div align="center" class="style28" ></div></td>
        </tr>
        <tr class="style6">
          <td height="254" align="right" nowrap ><table width="100%" height="217"  border="0" align="center" cellpadding="0" cellspacing="0" class="style21" >
              <tr class="style22">
                <td width="10%" height="18" align="right" nowrap >&nbsp;</td>
                <td width="20%" align="left" nowrap ><div align="left" class="style23">DEAL NO: </div></td>
                <td width="70%" align="left" nowrap ><div align="left">
                    <table width="100%" height="10"  border="0" align="center" cellpadding="0" cellspacing="0" class="style21" >
                      <tr class="style22">
                        <td width="43%" height="10" align="left" nowrap ><div align="left" class="style23"><strong> <?php echo"$fds_deal_number";?> </strong></div></td>
                        <td width="20%" nowrap ><div align="left" class="style23">TIME: </div>
                            <div align="left"></div></td>
                        <td width="37%" align="left" nowrap ><div align="left" class="style23"> <?php echo"$fds_deal_time";?></div></td>
                      </tr>
                    </table>
                </div></td>
              </tr>
              <tr class="style22">
                <td height="18" align="right" nowrap >&nbsp;</td>
                <td align="left" nowrap ><div align="left" class="style23">DEAL DATE: </div></td>
                <td align="left" nowrap ><div align="left">
                    <table width="100%" height="10"  border="0" align="center" cellpadding="0" cellspacing="0" class="style21" >
                      <tr class="style22">
                        <td width="43%" height="10" align="left" nowrap ><div align="left" class="style23"> <?php echo"$fds_deal_date";?> </div></td>
                        <td width="20%" nowrap ><div align="left" class="style23">VALUE DATE:</div>
                            <div align="left"></div></td>
                        <td width="37%" align="left" nowrap ><div align="left" class="style23"> <?php echo"$fds_value_date";?></div></td>
                      </tr>
                    </table>
                </div></td>
              </tr>
              <tr class="style22">
                <td height="18" align="right" nowrap >&nbsp;</td>
                <td align="left" nowrap ><div align="left" class="style23">COUNTER PARTY: </div></td>
                <td align="left" nowrap ><div align="left" class="style23"> <?php echo"$fds_counter_party";?></div></td>
              </tr>
              <tr class="style22">
                <td height="18" align="right" nowrap >&nbsp;</td>
                <td align="left" nowrap ><div align="left" class="style23">CURR. &amp; AMOUNT SOLD:</div></td>
                <td align="left" nowrap ><div align="left" class="style23"><?php echo"$fds_curr_amount_sold";?> </div></td>
              </tr>
              <tr class="style22">
                <td height="18" align="right" nowrap >&nbsp;</td>
                <td align="left" nowrap ><div align="left" class="style23">RATE:</div></td>
                <td align="left" nowrap ><div align="left" class="style23"> <?php echo"$fds_rate";?></div></td>
              </tr>
              <tr class="style22">
                <td height="18" align="right" nowrap >&nbsp;</td>
                <td align="left" nowrap ><div align="left" class="style23">CURR. &amp; AMOUNT BOUGHT :</div></td>
                <td align="left" nowrap ><span class="style23"><?php echo"$fds_curr_amount_bought";?></span></td>
              </tr>
              <tr class="style22">
                <td height="18" align="right" nowrap >&nbsp;</td>
                <td align="left" nowrap ><div align="left" class="style23">DEAL CONFIRMED WITH: </div></td>
                <td align="left" nowrap ><table width="100%" height="10"  border="0" align="center" cellpadding="0" cellspacing="0" class="style21" >
                    <tr class="style22">
                      <td width="43%" height="10" align="left" nowrap ><div align="left" class="style23"> <?php echo"$fds_confirmed_with";?></div></td>
                      <td width="20%" nowrap ><div align="left" class="style23">BANK M DEALER:</div>
                          <div align="left"></div></td>
                      <td width="37%" align="left" nowrap ><div align="left" class="style23"> <?php echo"$fds_bankm_dealer";?></div></td>
                    </tr>
                </table></td>
              </tr>
              <tr class="style22">
                <td height="18" align="right" nowrap >&nbsp;</td>
                <td align="left" nowrap ><div align="left" class="style23">PHONE/ MOBILE NO.: </div></td>
                <td align="left" nowrap ><table width="100%" height="10"  border="0" align="center" cellpadding="0" cellspacing="0" class="style21" >
                    <tr class="style22">
                      <td width="43%" height="10" align="left" nowrap ><div align="left" class="style23"> <?php echo"$fds_mobile";?></div></td>
                      <td width="20%" nowrap ><div align="left" class="style23">TIME: </div>
                          <div align="left"></div></td>
                      <td width="37%" align="left" nowrap ><div align="left" class="style23"> <?php echo"$fds_confirmed_time";?></div></td>
                    </tr>
                </table></td>
              </tr>
              <tr class="style22">
                <td height="18" align="right" nowrap >&nbsp;</td>
                <td align="left" nowrap ><div align="left" class="style23">SPL. INSTRUCTION:</div></td>
                <td align="left" nowrap ><span class="style23"><?php echo "$fds_spl_instruction";?></span></td>
              </tr>
              <tr class="style22">
                <td height="18" align="right" nowrap >&nbsp;</td>
                <td align="left" nowrap ><span class="style23">CUSTOMER E-MAIL ID:</span></td>
                <td align="left" nowrap ><span class="style23"><?php echo "$fds_spl_email";?></span></td>
              </tr>
            </table>
              <table width="103%" height="25"  border="0" align="center" cellpadding="0" cellspacing="0" class="style21" >
                <tr class="style22">
                  <td width="71%" height="30" align="left" nowrap ><div align="center">
                      <p class="style27">As per the indemnity entered into by you with the Bank the above deal has been closed over phone. This will be subject to availability of funds in your accounts </p>
                  </div></td>
                </tr>
              </table>
              <table width="100%" height="64"  border="0" align="center" cellpadding="0" cellspacing="0" class="style21" >
                <tr class="style22">
                  <td width="10%" height="64" align="right" nowrap >&nbsp;</td>
                  <td width="50%" align="left" nowrap ><div align="left" class="style23">SIGNATURE :Bank M Dealer &nbsp;&nbsp;&nbsp;&nbsp;................................ </div></td>
                  <td width="40%" align="left" nowrap ><div align="left" class="style23">Head - Treasury Back Office  &nbsp;&nbsp;&nbsp;&nbsp;................................ </div></td>
                </tr>
            </table></td>
        </tr>
      </table>
    </form></td>
  </tr>
</table>
</div>
</div>
<div align="center">
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>
    <?php } ?>
    <?php
	if (isset($_POST['printonly'])) 
       {  
	 ?>
</p>
  <p>
    <?php
  
  
  
  
  
                        $number = $_POST['number1'];
						
					   if($number == "") 	
	                   {
					   echo'</br>';echo'</br>';
					   echo'<span class="style17"><span class="style36">Deal number details missing</span></span>';
                       echo'</br>';echo'</br>';
					   echo'<span class="style17"><span class="style36">No Deal Details to be displayed for Printing!</span></span>';
                       echo'</br>';echo'</br>';
					   echo "<INPUT TYPE=button class=style11 VALUE=Back onClick=history.go(-1);return true;>";
				       exit; 
					   } 
					   
                        mysql_connect("localhost", "root", "") or die(mysql_error());
                        mysql_select_db("bmpl_forexdealportal") or die(mysql_error());
                        $result = mysql_query("SELECT * FROM fd_dealslip WHERE fds_deal_number = UPPER('$number') ") or die(mysql_error());  
                        while($row = mysql_fetch_array( $result )) 
                        {  

						$fds_deal_number         = $row['fds_deal_number'];	 	 	 	 	 	 	 	 
						$fds_deal_time	         = $row['fds_deal_time'];	 	 	 	 	 	 	 
						$fds_deal_date 	         = $row['fds_deal_date']; 	 	 	 	 	 
						$fds_value_date 	     = $row['fds_value_date']; 	 	 	 	 	 	 
						$fds_counter_party 	     = $row['fds_counter_party']; 	 	 	 	 	 	 
						$fds_curr_amount_bought  = $row['fds_curr_amount_bought']; 	 	 	 	 	 
						$fds_rate 	             = $row['fds_rate'];  	 	 	 	 
						$fds_curr_amount_sold	 = $row['fds_curr_amount_sold'];	 	 	 	 	 	 	 
						$fds_confirmed_with	     = $row['fds_confirmed_with']; 	 	 	 	 	 	 	 
						$fds_bankm_dealer	     = $row['fds_bankm_dealer']; 	 	 	 	 	 	 	 
						$fds_mobile              = $row['fds_mobile']; 	 	 	 	 
						$fds_confirmed_time      = $row['fds_confirmed_time']; 	 	 	 	 	 	 
						$fds_spl_instruction     = $row['fds_spl_instruction'];
						$fds_spl_email           = $row['fds_spl_email'];
						
                        } 
           
                        ?>
</p>
  <div id="divToPrint">
    <table width="1030"  border="0" align="center" cellpadding="0" cellspacing="0" >
      <tr>
        <td width="95%" height="300" valign="top" nowrap><form action="forexdealexe.php" method="post" name="forexdealslip" id="forexdealslip">
            <table width="98%" height="353"  border="0" align="center" cellpadding="0" cellspacing="0" class="style21"  >
              <tr class="style6">
                <td height="23" align="right" nowrap ><div align="center"><span class="style28"><a href="index.php">FOREX DEAL SLIP</a></span></div></td>
              </tr>
              <tr class="style6">
                <td width="28%" height="5" align="right" nowrap ><div align="center" class="style28" ></div></td>
              </tr>
              <tr class="style6">
                <td height="254" align="right" nowrap ><table width="100%" height="217"  border="0" align="center" cellpadding="0" cellspacing="0" class="style21" >
                    <tr class="style22">
                      <td width="10%" height="18" align="right" nowrap >&nbsp;</td>
                      <td width="20%" align="left" nowrap ><div align="left" class="style23">DEAL NO: </div></td>
                      <td width="70%" align="left" nowrap ><div align="left">
                          <table width="100%" height="10"  border="0" align="center" cellpadding="0" cellspacing="0" class="style21" >
                            <tr class="style22">
                              <td width="43%" height="10" align="left" nowrap ><div align="left" class="style23"><strong> <?php echo"$fds_deal_number";?> </strong></div></td>
                              <td width="20%" nowrap ><div align="left" class="style23">TIME: </div>
                                  <div align="left"></div></td>
                              <td width="37%" align="left" nowrap ><div align="left" class="style23"> <?php echo"$fds_deal_time";?></div></td>
                            </tr>
                          </table>
                      </div></td>
                    </tr>
                    <tr class="style22">
                      <td height="18" align="right" nowrap >&nbsp;</td>
                      <td align="left" nowrap ><div align="left" class="style23">DEAL DATE: </div></td>
                      <td align="left" nowrap ><div align="left">
                          <table width="100%" height="10"  border="0" align="center" cellpadding="0" cellspacing="0" class="style21" >
                            <tr class="style22">
                              <td width="43%" height="10" align="left" nowrap ><div align="left" class="style23"> <?php echo"$fds_deal_date";?> </div></td>
                              <td width="20%" nowrap ><div align="left" class="style23">VALUE DATE:</div>
                                  <div align="left"></div></td>
                              <td width="37%" align="left" nowrap ><div align="left" class="style23"> <?php echo"$fds_value_date";?></div></td>
                            </tr>
                          </table>
                      </div></td>
                    </tr>
                    <tr class="style22">
                      <td height="18" align="right" nowrap >&nbsp;</td>
                      <td align="left" nowrap ><div align="left" class="style23">COUNTER PARTY: </div></td>
                      <td align="left" nowrap ><div align="left" class="style23"> <?php echo"$fds_counter_party";?></div></td>
                    </tr>
                    <tr class="style22">
                      <td height="18" align="right" nowrap >&nbsp;</td>
                      <td align="left" nowrap ><div align="left" class="style23">CURR. &amp; AMOUNT SOLD:</div></td>
                      <td align="left" nowrap ><div align="left" class="style23"><?php echo"$fds_curr_amount_sold";?> </div></td>
                    </tr>
                    <tr class="style22">
                      <td height="18" align="right" nowrap >&nbsp;</td>
                      <td align="left" nowrap ><div align="left" class="style23">RATE:</div></td>
                      <td align="left" nowrap ><div align="left" class="style23"> <?php echo"$fds_rate";?></div></td>
                    </tr>
                    <tr class="style22">
                      <td height="18" align="right" nowrap >&nbsp;</td>
                      <td align="left" nowrap ><div align="left" class="style23">CURR. &amp; AMOUNT BOUGHT :</div></td>
                      <td align="left" nowrap ><span class="style23"><?php echo"$fds_curr_amount_bought";?></span></td>
                    </tr>
                    <tr class="style22">
                      <td height="18" align="right" nowrap >&nbsp;</td>
                      <td align="left" nowrap ><div align="left" class="style23">DEAL CONFIRMED WITH: </div></td>
                      <td align="left" nowrap ><table width="100%" height="10"  border="0" align="center" cellpadding="0" cellspacing="0" class="style21" >
                          <tr class="style22">
                            <td width="43%" height="10" align="left" nowrap ><div align="left" class="style23"> <?php echo"$fds_confirmed_with";?></div></td>
                            <td width="20%" nowrap ><div align="left" class="style23">BANK M DEALER:</div>
                                <div align="left"></div></td>
                            <td width="37%" align="left" nowrap ><div align="left" class="style23"> <?php echo"$fds_bankm_dealer";?></div></td>
                          </tr>
                      </table></td>
                    </tr>
                    <tr class="style22">
                      <td height="18" align="right" nowrap >&nbsp;</td>
                      <td align="left" nowrap ><div align="left" class="style23">PHONE/ MOBILE NO.: </div></td>
                      <td align="left" nowrap ><table width="100%" height="10"  border="0" align="center" cellpadding="0" cellspacing="0" class="style21" >
                          <tr class="style22">
                            <td width="43%" height="10" align="left" nowrap ><div align="left" class="style23"> <?php echo"$fds_mobile";?></div></td>
                            <td width="20%" nowrap ><div align="left" class="style23">TIME: </div>
                                <div align="left"></div></td>
                            <td width="37%" align="left" nowrap ><div align="left" class="style23"> <?php echo"$fds_confirmed_time";?></div></td>
                          </tr>
                      </table></td>
                    </tr>
                    <tr class="style22">
                      <td height="18" align="right" nowrap >&nbsp;</td>
                      <td align="left" nowrap ><div align="left" class="style23">SPL. INSTRUCTION:</div></td>
                      <td align="left" nowrap ><span class="style23"><?php echo "$fds_spl_instruction";?></span></td>
                    </tr>
                    <tr class="style22">
                      <td height="18" align="right" nowrap >&nbsp;</td>
                      <td align="left" nowrap ><span class="style23">CUSTOMER E-MAIL ID:</span></td>
                      <td align="left" nowrap ><span class="style23"><?php echo "$fds_spl_email";?></span></td>
                    </tr>
                  </table>
                    <table width="103%" height="25"  border="0" align="center" cellpadding="0" cellspacing="0" class="style21" >
                      <tr class="style22">
                        <td width="71%" height="30" align="left" nowrap ><div align="center">
                            <p class="style27">As per the indemnity entered into by you with the Bank the above deal has been closed over phone. This will be subject to availability of funds in your accounts </p>
                        </div></td>
                      </tr>
                    </table>
                    <table width="100%" height="64"  border="0" align="center" cellpadding="0" cellspacing="0" class="style21" >
                      <tr class="style22">
                        <td width="10%" height="64" align="right" nowrap >&nbsp;</td>
                        <td width="50%" align="left" nowrap ><div align="left" class="style23">SIGNATURE :Bank M Dealer &nbsp;&nbsp;&nbsp;&nbsp;................................ </div></td>
                        <td width="40%" align="left" nowrap ><div align="left" class="style23">Head - Treasury Back Office &nbsp;&nbsp;&nbsp;&nbsp;................................ </div></td>
                      </tr>
                  </table></td>
              </tr>
            </table>
        </form></td>
      </tr>
    </table>
    <p>
      <?php } ?>
    </p>
  </div>
  <p>&nbsp;  </p>
</div>
