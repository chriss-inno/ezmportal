<?php
session_start();
//connectiong to the databas
include'connect.php';
$sql = "SELECT * FROM fd_customer order by customer asc"; $qry = mysql_query($sql) or die(mysql_error());
$v=mysql_num_rows($qry);
if (mysql_num_rows($qry) == 0) {
    echo "<font color='red'>\n\nThere are no new records\n\n</font>";
} else {
while ($row = mysql_fetch_object($qry))
    {
echo '<option value="'.$row->customer.'-'.$row->rm_code.'">'.$row->customer.'-'.$row->rm_code.'</option>';
 }
}
?>
