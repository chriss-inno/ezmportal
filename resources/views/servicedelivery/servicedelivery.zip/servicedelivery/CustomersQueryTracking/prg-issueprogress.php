<?php
session_start();
$loginUser_id = $_SESSION['SESS_USER_ID'];
require_once('../../../config/auth_content.php');

     $con = mysql_connect("localhost","root","");
     if (!$con) {die('Could not connect: ' . mysql_error());}
     mysql_select_db("bmpl_system") or die(mysql_error());
	 $query = mysql_query(" SELECT * FROM sys_user WHERE usr_id = '$loginUser_id' ");  
	 while($row = mysql_fetch_array($query))
     {
	 $usr_full_name = $row['usr_full_name'];
     }


?> 
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<script type="text/javascript"> 
 function show_alert() { 
 var msg = "Submited Successful, press OK and wait for the page to finish loading. Do not press LOG again!";
 alert(msg); 
 }
 </script>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Untitled Document</title>
<style type="text/css">
<!--
.style2 {
	color: #ffffff;
	font-weight: bold;
}
.style3 {font-size: 11px; font-family: tahoma;}
.style6 {font-size: 11px}
.style11 {font-family: tahoma; font-size: 11px; color: #ffffff; }
.style13 {font-family: tahoma; font-size: 11px; color: #0E3793; }
a:link {
	text-decoration: none;
}
a:visited {
	text-decoration: none;
}
a:hover {
	text-decoration: none;
}
a:active {
	text-decoration: none;
}
.style16 {font-family: tahoma; font-size: 11px; color: #0E3793; font-weight: bold; }
body {
	background-image: url(../../images/backgrounds/pagebg.png);
}
.style18 {font-size: 11px; font-family: tahoma; color: #FFFFFF; }
.style19 {font-size: 11px; font-family: tahoma; color: #FFFFFF; font-weight: bold; }
.style20 {	color: #0E3793;
	font-weight: bold;
}
-->
</style>
	
	<script type="text/javascript" src="../../support/js/jquery.min.js"></script>
	<script type="text/javascript" src="../../support/js/control.js"></script>
</head>
<script type="text/javascript">
// Popup window code
function newPopup(url) {
	popupWindow = window.open(
		url,'popUpWindow','height=300,width=500,left=10,top=10,resizable=yes,scrollbars=yes,toolbar=yes,menubar=no,location=no,directories=no,status=yes,dependent=yes,menubar=no,resizable=no,scrollbars=yes')
		                   
}
</script>
<body>
<table width="100%" border="0" cellpadding="5" cellspacing="0">
  <tr>
    <td></td>
  </tr>
</table>
<table width="100%"  border="0" align="center" cellpadding="0" cellspacing="0" style="border-left: 1px solid #7F9DB9; border-right: 1px solid #7F9DB9; border-top: 1px solid #7F9DB9; border-bottom: 1px solid #7F9DB9;">
  <tr>
    <td width="95%" height="20" nowrap ><table width="100%" height="20"  border="0" align="center" cellpadding="0" cellspacing="0" style="border-bottom: 1px solid #7F9DB9;">
        <tr >
          <td width="96%" height="19" nowrap bgcolor="#E1204F" b><span class="style2"><span class="style20">&nbsp;<span class="style18">CUSTOMER ISSUE TRACKING </span></span></span></td>
        </tr>
    </table></td>
  </tr>
  <tr>
    <td height="422" valign="top" nowrap>
	<form action="" method="post" name="ReturnDepartmentSelect" id="ReturnDepartmentSelect">
	  <div align="center">
	    <p class="style11"><strong>
	         
			 
		    <span class="style19">
			 <?php
     $con = mysql_connect("localhost","root","");
     if (!$con) {die('Could not connect: ' . mysql_error());}
     mysql_select_db("bmpl_system") or die(mysql_error());
			  
			  
	 $query = mysql_query(" SELECT * FROM sys_user WHERE usr_id = '$loginUser_id' ");  
	 while($row = mysql_fetch_array($query))
     {
	 $deprtmnt = $row['usr_department'];
     }
	 
	 $queryl = mysql_query(" SELECT * FROM sys_user_right WHERE usr_id = '$loginUser_id' and rgt_name = 'CUSTOMERQUERYTRACKINGINPUT' ");  
	 while($row = mysql_fetch_array($queryl))
     {
	 $rgtname = $row['rgt_name'];
     }
	 
	 if ($rgtname != "CUSTOMERQUERYTRACKINGINPUT")
	 
	 {
 include_once 'unuthorized.php';	
	  exit;
	 }?>
	      </span></strong></p>
	    </div>
	</form>
	<form action="prg-issueprogress.php" method="post" enctype="multipart/form-data" >
	
      <table width="80%" height="968"  border="0" align="center" cellpadding="0" cellspacing="0" class="style11" >
        <tr class="style6">
          <td height="13" align="right" nowrap >&nbsp;</td>
          <td nowrap ><div align="center"><span class="style16">              
  
          </span> <span class="style16">
		    
		  
		    <span class="style2"><span class="style3">
			<?php
		   $iss_reference_number = $_GET['iss_reference_number'];
			  
               mysql_connect("localhost", "root", "") or die(mysql_error());
               mysql_select_db("bmpl_servicedeliveryportal") or die(mysql_error());
               $result = mysql_query("SELECT * FROM sd_issue WHERE iss_reference_number = '$iss_reference_number' ") or die(mysql_error());  
               while($row = mysql_fetch_array( $result )) 
               {   
   $iss_reference_number   = $row['iss_reference_number'];
   $iss_reported_date      = $row['iss_reported_date'];
   $iss_reported_time      = $row['iss_reported_time'];
   $iss_inputed_by         = $row['iss_inputed_by'];
   $iss_customer_name      = $row['iss_customer_name'];
   $iss_customer_number    = $row['iss_customer_number'];
   $iss_customer_email     = $row['iss_customer_email'];
   $iss_product_type       = $row['iss_product_type'];
   $iss_received_by        = $row['iss_received_by'];
   $iss_received_mode      = $row['iss_received_mode'];
   $iss_priority           = $row['iss_priority'];
   $iss_status             = $row['iss_status'];
   $iss_issue_description  = $row['iss_issue_description'];
   $iss_root_caused        = $row['iss_root_caused'];
   $iss_responsible        = $row['iss_responsible'];
   $iss_note               = $row['iss_note'];
   $iss_viable_action      = $row['iss_viable_action'];
   $iss_resolution_date= $row['iss_resolution_date'];
   $iss_contact_person     = $row['iss_contact_person'];
   $iss_responsibleprs 	         = $row['iss_responsibleprs'];
   $iss_responsiblepid          = $row['iss_responsiblepid'];
			   
               } 
		  ?>
            <?php
			
			
			
			
		   if (isset($_POST['Update'])) 
{
mysql_connect("localhost", "root", "") or die(mysql_error());
mysql_select_db("bmpl_servicedeliveryportal") or die(mysql_error());
		   

$inumber       = $_POST['inumber'];
$ireportedby   = $_POST['ireportedby'];
$idate         = $_POST['idate'];
$itime         = $_POST['itime'];
$istatusn      = $_POST['istatusn'];
$istatus       = $_POST['istatus'];
$idescription      = $_POST['idescription'];
$icname            = $_POST['icname'];
$icmname           = $_POST['icmname'];
$iproductn         = $_POST['iproductn'];
$iproduct          = $_POST['iproduct'];
$iproductdetails   = $_POST['iproductdetails'];
$ireceivedbyn      = $_POST['ireceivedbyn'];
$ireceivedby       = $_POST['ireceivedby'];
$imoden            = $_POST['imoden'];
$imode             = $_POST['imode'];
$iresponsiblen     = $_POST['iresponsiblen'];
$iresponsible      = $_POST['iresponsible'];
$iroot             = $_POST['iroot'];
$inote             = $_POST['inote'];
$iresolutiondate   = $_POST['iresolutiondate'];


If ($iproduct <> "Select Product Type" )
{

If ($iproduct === "Account" && $iproductdetails  === "Select Product Details" )
{
echo "Product details for Product '$iproduct' not selected";
exit;}

If ($iproduct === "Cheque" && $iproductdetails  === "Select Product Details" )
{
echo "Product details for Product '$iproduct' not selected";
exit;}


If ($iproduct === "Account") 
{
$iproduct = "$iproduct/$iproductdetails";
}

If ($iproduct === "Cheque") 
{
$iproduct = "$iproduct/$iproductdetails";
}

}













If ($istatus === "Select Status") 
{
$istatus = $istatusn;
}

If ($istatus === "Resolved") 
{
$itat = $itime;
@mysql_query("UPDATE sd_issue SET iss_resolution_time = '$itat' WHERE iss_reference_number = '$inumber'");
}


If ($istatus === "Resolved" && $iresolutiondate <> "0000-00-00") 
{
$iresolutiondate = $iresolutiondate ;
}

If ($iproduct === "Select Product Type") 
{
$iproduct = $iproductn;
}

If ($ireceivedby === "Select Received by") 
{
$ireceivedby = $ireceivedbyn;
}

If ($imode === "Select Mode of Receipt") 
{
$imode = $imoden;
}

If ($iresponsible === "Select Department") 
{
$iresponsible  = $iresponsiblen;
}


@mysql_query("UPDATE sd_issue SET iss_customer_name = '$icname', iss_contact_person = '$icmname', iss_product_type = '$iproduct', iss_received_by = '$ireceivedby', iss_received_mode = '$imode', iss_status = '$istatus', iss_root_caused = '$iroot', iss_responsible = '$iresponsible', iss_note = '$inote', iss_resolution_date = '$iresolutiondate' WHERE iss_reference_number = '$inumber'");



If ($idescription <> "") 
{
@mysql_query("INSERT INTO sd_progress (iss_number, prg_description, prg_status, prg_date, prg_time, prg_inputed_by)
              VALUES('$inumber','$idescription','$istatus','$idate', '$itime','$ireportedby')");
}


@mysql_query("INSERT INTO sd_resolutionprogress (iss_number, rpg_responsible, rpg_caused, rpg_note, prg_date, prg_time, rpg_inputed_by)
            VALUES('$inumber','$iresponsible','$iroot','$inote','$idate', '$itime', '$ireportedby')");
		   
echo "<p>&nbsp;</p>";
echo "Issue $inumber successfull updated !";
echo "<p>&nbsp;</p>";
		    
            $result = mysql_query("SELECT * FROM sd_issue WHERE iss_reference_number = '$inumber' ") or die(mysql_error());  
            while($row = mysql_fetch_array( $result )) 
   {    
   $iss_reference_number   = $row['iss_reference_number'];
   $iss_reported_date      = $row['iss_reported_date'];
   $iss_reported_time      = $row['iss_reported_time'];
   $iss_inputed_by         = $row['iss_inputed_by'];
   $iss_customer_name      = $row['iss_customer_name'];
   $iss_customer_number    = $row['iss_customer_number'];
   $iss_customer_email     = $row['iss_customer_email'];
   $iss_product_type       = $row['iss_product_type'];
   $iss_received_by        = $row['iss_received_by'];
   $iss_received_mode      = $row['iss_received_mode'];
   $iss_priority           = $row['iss_priority'];
   $iss_status             = $row['iss_status'];
   $iss_issue_description  = $row['iss_issue_description'];
   $iss_root_caused        = $row['iss_root_caused'];
   $iss_responsible        = $row['iss_responsible'];
   $iss_note               = $row['iss_note'];
   $iss_viable_action      = $row['iss_viable_action'];
   $iss_resolution_date= $row['iss_resolution_date'];
   $iss_contact_person     = $row['iss_contact_person'];
   } 
   } 
			   
			  
               ?>
</span></span></span></div></td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="14" nowrap style="border-bottom: 1px solid #7F9DB9;">&nbsp;</td>
          <td nowrap style="border-bottom: 1px solid #7F9DB9;"><span class="style2"><span class="style3">BASIC DETAILS </span></span></td>
          <td nowrap style="border-bottom: 1px solid #7F9DB9;">&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="13" align="right" nowrap >&nbsp;</td>
          <td nowrap > 
          </td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td width="28%" height="23" align="right" nowrap >ISSUE REF # : </td>
          <td width="31%" nowrap ><table width="100%"  border="0" align="center" cellpadding="0" cellspacing="0" >
              <tr>
                <td width="29%" nowrap class="style11" >
                    <input name="inumbern" type="text"  class="style13" id="inumbern" value="<?php echo "$iss_reference_number"; ?>"></td>
                <td width="39%" nowrap class="style11" ><input name="inumber" type="hidden" class="style3" id="inumber" value="<?php echo "$iss_reference_number"; ?>"></td>
                <td width="32%" align="center" nowrap class="style11"  ><div align="right">REPORTED DATE  :</div></td>
              </tr>
          </table></td>
          <td width="41%" nowrap ><input name="idaten" type="text"  class="style13" id="idaten" value="<?php echo "$iss_reported_date"; ?>">
            </td>
        </tr>
        <tr class="style6">
          <td height="28" align="right" nowrap >INPUTER :</td>
          <td nowrap ><table width="100%"  border="0" align="center" cellpadding="0" cellspacing="0" >
            <tr>
              <td width="29%" nowrap class="style11" ><input name="ireportedbynm" type="text"  class="style13" id="ireportedbynm" value="<?php echo "$iss_inputed_by"; ?>"></td>
              <td width="39%" nowrap class="style11" >&nbsp;</td>
              <td width="32%" align="center" nowrap class="style11" ><div align="right">REPORTED TIME : </div></td>
            </tr>
          </table></td>
          <td nowrap ><input name="itimen" type="text"  class="style13" id="itimen" value="<?php echo "$iss_reported_time"; ?>">
            </td>
        </tr>
        <tr class="style6">
          <td height="13" align="right" nowrap >UPDATED  :</td>
          <td nowrap ><table width="100%"  border="0" align="center" cellpadding="0" cellspacing="0" >
            <tr>
              <td width="29%" nowrap class="style11" ><input name="ireportedbyn" type="text"  class="style13" id="ireportedbyn" value="<?php echo "$usr_full_name"; ?>"></td>
              <td width="39%" nowrap class="style11" ><input name="ireportedby" type="hidden" class="style11" id="ireportedby" value="<?php echo "$usr_full_name"; ?>"></td>
              <td width="32%" align="center" nowrap class="style11" ><div align="right">UPDATED DATE : </div></td>
            </tr>
          </table></td>
          <td nowrap ><input name="itimen" type="text"  class="style13" id="itimen" value="<?php echo date("Y-m-d", time()); ?>">
            <input name="idate" type="hidden"  class="style11" id="idate" value="<?php echo date("Y-m-d", time()); ?>"></td>
        </tr>
        <tr class="style6">
          <td height="30" align="right" nowrap >&nbsp;</td>
          <td nowrap ><table width="100%"  border="0" align="center" cellpadding="0" cellspacing="0" >
            <tr>
              <td width="29%" nowrap class="style11" >&nbsp;</td>
              <td width="39%" nowrap class="style11" >&nbsp;</td>
              <td width="32%" align="center" nowrap class="style11" ><div align="right">UPDATED TIME : </div></td>
            </tr>
          </table></td>
          <td nowrap ><input name="itimen" type="text"  class="style13" id="itimen" value="<?php echo date("H:i:s", time()); ?>">
            <input name="itime" type="hidden"  class="style11" id="itime" value="<?php echo date("H:i:s", time()); ?>"></td>
        </tr>
        <tr class="style6">
          <td height="13" align="right" nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="13" align="right" nowrap style="border-bottom: 1px solid #7F9DB9;">&nbsp;</td>
          <td nowrap style="border-bottom: 1px solid #7F9DB9;"><span class="style2"><span class="style3">PROGRESS DESCRIPTION </span></span></td>
          <td nowrap style="border-bottom: 1px solid #7F9DB9;">&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="13" align="right" nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="26" align="right" nowrap >CURRENT STATUS :</td>
          <td nowrap ><input name="istatusn" type="text" class="style13" id="istatusn" value="<?php echo "$iss_status"; ?>" size="30" ></td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="26" align="right" nowrap >STATUS :</td>
          <td nowrap ><select name="istatus" class="style13" id="istatus">
            <option value="Select Status">Select Status</option>
<option value="Pending awaiting resolution">Pending awaiting resolution</option>
<?PHP // <option value="Pending awaiting clients confirmation">Pending awaiting clients confirmation</option> ?>
<option value="Resolved">Resolved</option>
          </select>
            * 
          </td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="26" align="right" nowrap >RESOLUTION DATE : </td>
          <td nowrap ><input name="iresolutiondate" type="text" class="style13" id="iresolutiondate" value="<?php echo "$iss_resolution_date"; ?>" >
    * &nbsp;<strong>FORMAT</strong>: YYYY-MM-DD </td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="96" align="right" nowrap >DESCRIPTION :</td>
          <td nowrap ><textarea name="idescription" cols="70" rows="5" class="style13" id="idescription"></textarea></td>
          <td nowrap >*</td>
        </tr>
        <tr class="style6">
          <td height="13" align="right" nowrap style="border-bottom: 1px solid #7F9DB9;">&nbsp;</td>
          <td nowrap style="border-bottom: 1px solid #7F9DB9;">&nbsp;</td>
          <td nowrap style="border-bottom: 1px solid #7F9DB9;">&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="13" align="right" nowrap >&nbsp;</td>
          <td nowrap ><span class="style2"><span class="style3">CUSTOMER DETAILS </span></span></td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="13" align="right" nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="23" align="right" nowrap >COMPANY NAME :</td>
          <td nowrap ><table width="100%"  border="0" align="center" cellpadding="0" cellspacing="0" >
            <tr>
              <td width="29%" nowrap class="style11" ><input name="icname" type="text" class="style13" id="icname" value="<?php echo "$iss_customer_name"; ?>" size="50" ></td>
              <td width="39%" nowrap class="style11" >*</td>
              <td width="32%" align="center" nowrap class="style11" ><div align="right"></div></td>
            </tr>
          </table></td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="23" align="right" nowrap >CONTACT PERSON :</td>
          <td nowrap ><table width="100%"  border="0" align="center" cellpadding="0" cellspacing="0" >
            <tr>
              <td width="29%" nowrap class="style11" ><input name="icmname" type="text" class="style13" id="icmname" style="text-transform:uppercase;" value="<?php echo "$iss_contact_person"; ?>" size="50" ></td>
              <td width="39%" nowrap class="style11" >*</td>
              <td width="32%" align="center" nowrap class="style11" ><div align="right"></div></td>
            </tr>
          </table></td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="13" align="right" nowrap >&nbsp;</td>
          <td nowrap ><table width="100%"  border="0" align="center" cellpadding="0" cellspacing="0" >
              <tr>
                <td width="29%" nowrap class="style11" >&nbsp;</td>
                <td width="39%" nowrap class="style11" >&nbsp;</td>
                <td width="32%" align="center" nowrap class="style11" ><div align="right"></div></td>
              </tr>
          </table></td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="14" align="right" nowrap style="border-bottom: 1px solid #7F9DB9;" >&nbsp;</td>
          <td nowrap style="border-bottom: 1px solid #7F9DB9;"><span class="style2"><span class="style3">ISSUE DETAILS </span></span></td>
          <td nowrap style="border-bottom: 1px solid #7F9DB9;">&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="13" align="right" nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="27" align="right" nowrap >CURRENT PRODUCT TYPE :</td>
          <td nowrap ><table width="100%"  border="0" align="center" cellpadding="0" cellspacing="0" >
            <tr>
              <td width="32%" nowrap class="style11" >                <input name="iproductn" type="text" class="style13" id="iproductn" value="<?php echo "$iss_product_type "; ?>" ></td>
              <td width="18%" nowrap class="style11" >&nbsp;</td>
              <td width="50%" align="center" nowrap class="style11" ><div align="right">CURRENT ISSUE RECEIVED BY :</div></td>
            </tr>
          </table></td>
          <td nowrap ><input name="ireceivedbyn" type="text" class="style13" id="ireceivedbyn" value="<?php echo "$iss_received_by"; ?>"></td>
        </tr>
        <tr class="style6">
          <td height="27" align="right" nowrap >PRODUCT TYPE :</td>
          <td nowrap ><table width="100%"  border="0" align="center" cellpadding="0" cellspacing="0" >
            <tr>
              <td width="29%" nowrap class="style11" ><select name="iproduct" class="style13" id="iproduct">
                <option value="Select Product Type">Select Product Type</option>
                <option value="TT">TT</option>
                <option value="TISS">TISS</option>
                <option value="CCE">CCE</option>
                <option value="CDR">CDR</option>
                <option value="CIT">CIT</option>
                <option value="EFT">EFT</option>
				<option value="Cash">Cash</option>
				<option value="Forex">Forex</option>
				<option value="Cheque">Cheque</option>
				<option value="Account">Account</option>
				<option value="Statement">Statement</option>
				<option value="Account Balance">Account Balance</option>
				<option value="Inward TT">Inward TT</option>
				<option value="Inward TISS">Inward TISS</option>
				<option value="Complain">Complain</option>
				<option value="Money Wireless">Money Wireless</option>
				<option value="Money Mail">Money Mail</option>
				<option value="Credit">Credit</option>
				<option value="Trade Finance">Trade Finance</option>
				<option value="Money Msafiri">Money Msafiri</option>
				
				
				<option value="Taxbank">Taxbank</option>
				<option value="Inhouse Cheque">Inhouse Cheque</option>
				<option value="Outward Cheque">Outward Cheque</option>
				<option value="Fixed Deposit">Fixed Deposit</option>
				<option value="Bill">Bill</option>
				<option value="Bond">Bond</option>
				<option value="Withholding Tax Certificates">Withholding Tax Certificates</option>
              </select></td>
              <td width="39%" nowrap class="style11" >*</td>
              <td width="32%" align="center" nowrap class="style11" ><div align="right">PRODUCT DETAILS : </div></td>
            </tr>
          </table></td>
          <td nowrap ><select name="iproductdetails" class="style13" id="iproductdetails">
            <option value="Select Product Details">Select Product Details</option>
           <option value="Wrong Cr/Dr">Wrong Cr/Dr</option>
					
                    <option value="Wrong Charges">Wrong Charges</option>
                    <option value="Not Processed">Not Processed</option>
					<option value="Advice not sent">Advice not sent</option>
					<option value="Reversal of charges">Reversal of charges</option>
					<option value="Delay in processing">Delay in processing</option>
                    <option value="Others">Others</option>
          </select>
            For Account and Cheque Products</td>
        </tr>
        <tr class="style6">
          <td height="27" align="right" nowrap >CURRENT MODE OF RECEIPT :</td>
          <td nowrap >            <table width="100%"  border="0" align="center" cellpadding="0" cellspacing="0" >
              <tr>
                <td width="29%" nowrap class="style11" >                  <input name="imoden" type="text" class="style13" id="imoden" value="<?php echo "$iss_received_mode"; ?>" ></td>
                <td width="39%" nowrap class="style11" >&nbsp;</td>
                <td width="32%" align="center" nowrap class="style11" ><div align="right">RECEIVED BY : </div></td>
              </tr>
            </table></td>
          <td nowrap ><select name="ireceivedby" class="style13" id="ireceivedby">
            <option value="Select Received by">Select Received by</option>
           <option value="Sanya Abdul">Sanya Abdul</option>
<option value="Grace Nguma">Grace Nguma</option>
<option value="Godfrey Utouh">Godfrey Utouh</option>
<option value="HTB">HTB</option>
<option value="HCB">HCB</option>
<option value="Nadeem Mohamed">Nadeem Mohamed</option>
<option value="Schola Mrina">Schola Mrina</option>
<option value="Kaisy Mwakajegela">Kaisy Mwakajegela</option>
<option value="Service Delivery">Service Delivery</option>
<option value="Uhuru HCC">Uhuru HCC</option>
<option value="Kisutu HCC">Kisutu HCC</option>
<option value="IFB HCC">IFB HCC</option>
<option value="Arusha HCC">Arusha HCC</option>
<option value="Mwanza HCC">Mwanza HCC</option>
<option value="Branch Manager(IFB)">Branch Manager(IFB)</option>
<option value="Branch Manager(Kisutu)">Branch Manager(Kisutu)</option>
<option value="Branch Manager(Uhuru)">Branch Manager(Uhuru)</option>
<option value="Branch Manager(Arusha)">Branch Manager(Arusha)</option>
<option value="Branch Manager(Mwanza)">Branch Manager(Mwanza)</option>
<option value="Anne Nehemia">Anne Nehemia</option>
<option value="Waseem Arain">Waseem Arain</option>
<option value="Jacqueline Woiso">Jacqueline Woiso</option>
<option value="Deepali Ramaiya">Deepali Rumaiya</option>
<option value="Jibraan Kadri">Jibraan Kadri</option>
<option value="Sheena Sinare">Sheena Sinare</option>
<option value="Jignasa Rana">Jignasa Rana</option>
<option value="Aliakber Kermali">Aliakber Kermali</option>
<option value="Samia Karim">Samia Karim</option>
<option value="Mujtaba Karmali">Mujtaba Karmali</option>
<option value="Jignasaha Rana">Jignasaha Rana</option>
<option value="Kumailabbas Sachedina">Kumailabbas Sachedina</option>
<option value="Godbless Mushi">Godbless Mushi</option>
<option value="John Brighton">John Brighton</option>
<option value="Tracy Mwela">Tracy Mwela</option>


<option value="Sayed Kadri">Sayed Kadri</option>
<option value="Shiva Kumar">Shiva Kumar</option>
<option value="Mujtaba Karmali">Mujtaba Karmali</option>
<option value="Mohamed Zakaria">Mohamed Zakaria</option>
<option value="Tunu Swai">Tunu Swai</option>
          </select>
* </td>
        </tr>
        <tr class="style6">
          <td height="13" align="right" nowrap >MODE OF RECEIP :</td>
          <td nowrap ><select name="imode" class="style13" id="imode">
            <option value="Select Mode of Receipt">Select Mode of Receipt</option>
			<option value="In person">In person</option>
            <option value="Telephone">Telephone</option>
            <option value="Mail">Mail</option>
          </select>
            *</td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="13" align="right" nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="13" align="right" nowrap style="border-right: 1px solid #7F9DB9;">ISSUE PROGRESS : </td>
          <td nowrap >
		   <?php
               mysql_connect("localhost", "root", "") or die(mysql_error());
               mysql_select_db("bmpl_servicedeliveryportal") or die(mysql_error());
               $result = mysql_query("SELECT * FROM sd_progress WHERE iss_number = '$iss_reference_number' ") or die(mysql_error());                 
    while($row = mysql_fetch_array($result))
    { 
	
    echo '&nbsp;&nbsp;<span class=style13><textarea name=textarea cols=70 rows=5 class=style13>'.''.$row["prg_description"].'</textarea></span></br>';
	echo '&nbsp;&nbsp;<span class=style13><textarea name=textarea cols=30 rows=1 class=style13>'.''.$row["prg_status"].'</textarea></span></br>';
	echo '&nbsp;&nbsp;<span class=style13><textarea name=textarea cols=30 rows=1 class=style13>'.''.$row["prg_inputed_by"].'</textarea></span>';
	echo '&nbsp;&nbsp;<input name=textfield type=text class=style13 value='.''.$row['prg_date'].'>';
	echo '</br>';echo '</br>';
	$count++ ; 
	 }
     ?></td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="13" align="right" nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="13" align="right" nowrap style="border-bottom: 1px solid #7F9DB9;">&nbsp;</td>
          <td nowrap style="border-bottom: 1px solid #7F9DB9;"><span class="style2"><span class="style3">Resolution Information </span></span></td>
          <td nowrap style="border-bottom: 1px solid #7F9DB9;">&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="13" align="right" nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="29" align="right" nowrap >Current Department Responsible </td>
          <td nowrap >            <table width="100%"  border="0" align="center" cellpadding="0" cellspacing="0" >
              <tr>
                <td width="29%" nowrap class="style11" ><input name="iresponsiblen" type="text" class="style13" id="iresponsiblen" value="<?php echo "$iss_responsible"; ?>" size="20" ></td>
                <td width="7%" nowrap class="style11" >&nbsp;</td>
                <td width="64%" align="center" nowrap class="style11" ><div align="right"></div></td>
              </tr>
            </table></td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="29" align="right" nowrap >Department Responsible</td>
          <td nowrap > <table width="100%"  border="0" align="center" cellpadding="0" cellspacing="0" >
              <tr>
                <td width="46%" nowrap class="style11" ><select name="iresponsible" class="style13" id="iresponsible">
                  <option value="Select Department">Select Department</option>
                   <option value="Administration">Administration</option>
            <option value="Money Shoppe @ Arusha">Money Shoppe @ Arusha</option>
            <option value="Branch Management Unit">Branch Management Unit</option>
            <option value="Centralized Operations">Centralized Operations</option>
            <option value="Corporate Affairs">Corporate Affairs</option>
            <option value="Corporate Banking">Corporate Banking</option>
            <option value="Credit">Credit</option>
            <option value="Finance">Finance</option>
            <option value="Human Resources">Human Resources</option>
            <option value="ICT">ICT</option>
            <option value="Industial Finance Branch">Industial Finance Branch</option>
            <option value="Internal Audit">Internal Audit</option>
            <option value="Money Shoppe @ Kisutu">Money Shoppe @ Kisutu</option>
            <option value="Money Shoppe @ Mwanza">Money Shoppe @ Mwanza</option>
            <option value="Product Delivery">Product Delivery</option>
            <option value="Service Delivery">Service Delivery</option>
            <option value="Trade Finance">Trade Finance</option>
            <option value="Transactional Banking">Transactional Banking</option>
            <option value="Treasury">Treasury</option>
            <option value="Treasury Back Office">Treasury Back Office</option>
            <option value="Money Shoppe @ Uhuru">Money Shoppe @ Uhuru</option>
            <option value="Compliance">Compliance</option>
            <option value="Operation">Operation</option>
            <option value="Communications">Communications</option>
			<option value="Payments">Payments</option>
			<option value="Regional Relationships">Regional Relationships</option>
			<option value="Institutional Banking">Institutional Banking</option>
			
            
            <option value="Funds Transfer Unit">Funds Transfer Unit</option>
			
			
			<option value="Clearing">Clearing</option>
            <option value="Payments FT">Payments FT</option>
            <option value="Payments (Client Support Services)">Payments (Client Support Services)</option>
			 <option value="NA">NA</option>
                </select>
* </td>
                <td width="12%" nowrap class="style11" >&nbsp;</td>
                <td width="42%" align="center" nowrap class="style11" ><div align="right"></div></td>
              </tr>
            </table>
            </td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="87" align="right" nowrap >Root Cause </td>
          <td nowrap ><textarea name="iroot" cols="70" rows="5" class="style13" id="iroot"><?php echo "$iss_root_caused"; ?></textarea></td>
          <td nowrap >*</td>
        </tr>
        <tr class="style6">
          <td height="13" align="right" nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="88" align="right" nowrap >Remarks</td>
          <td nowrap ><textarea name="inote" cols="70" rows="5" class="style13" id="inote"><?php echo "$iss_note"; ?></textarea></td>
          <td nowrap >*</td>
        </tr>
        <tr class="style6">
          <td height="13" align="right" nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="13" align="right" nowrap style="border-bottom: 1px solid #7F9DB9;">&nbsp;</td>
          <td nowrap style="border-bottom: 1px solid #7F9DB9;"><strong class="style3">Action</strong></td>
          <td nowrap style="border-bottom: 1px solid #7F9DB9;">&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="13" align="right" nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="13" align="right" nowrap >&nbsp;</td>
          <td nowrap ><input name="Update" type="submit" class="style13" id="Update" OnClick="show_alert()" value="UPDATE"></td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="13" align="right" nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="13" align="right" nowrap >&nbsp;</td>
          <td nowrap >NOTE: FIELDS WITH * CAN BE UPDATED </td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="13" align="right" nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
        </tr>
      </table>
      </form>
    </td>
  </tr>
</table>
</body>
</html>
