<?php
session_start();
$loginUser_id = $_SESSION['SESS_USER_ID'];
require_once('../../../config/auth_content.php');
?> 
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<script type="text/javascript"> 
 function show_alert() { 
 var msg = "Submited Successful, press OK and wait for the page to finish loading. Do not press LOG again!";
 alert(msg); 
 }
 </script>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Untitled Document</title>
<style type="text/css">
<!--
.style2 {
	color: #ffffff;
	font-weight: bold;
}
.style3 {font-size: 11px; font-family: tahoma;}
.style6 {font-size: 11px}
.style11 {font-family: tahoma; font-size: 11px; color: #ffffff; }
.style13 {font-family: tahoma; font-size: 11px; color: #0E3793; }
.style12 {font-family: tahoma}
a:link {
	text-decoration: none;
}
a:visited {
	text-decoration: none;
}
a:hover {
	text-decoration: none;
}
a:active {
	text-decoration: none;
}
.style14 {color: #0E3793}
.style16 {font-family: tahoma; font-size: 11px; color: #0E3793; font-weight: bold; }
body {
	background-image: url(../../images/backgrounds/pagebg.png);
}
.style18 {font-size: 11px; font-family: tahoma; color: #FFFFFF; }
.style19 {font-size: 11px; font-family: tahoma; color: #FFFFFF; font-weight: bold; }
.style20 {	color: #0E3793;
	font-weight: bold;
}
-->
</style>
	
	<script type="text/javascript" src="../../support/js/jquery.min.js"></script>
	<script type="text/javascript" src="../../support/js/control.js"></script>
</head>
<script type="text/javascript">
// Popup window code
function newPopup(url) {
	popupWindow = window.open(
		url,'popUpWindow','height=300,width=500,left=10,top=10,resizable=yes,scrollbars=yes,toolbar=yes,menubar=no,location=no,directories=no,status=yes,dependent=yes,menubar=no,resizable=no,scrollbars=yes')
		                   
}
</script>
<body>
<table width="100%" border="0" cellpadding="5" cellspacing="0">
  <tr>
    <td></td>
  </tr>
</table>
<table width="100%"  border="0" align="center" cellpadding="0" cellspacing="0" style="border-left: 1px solid #7F9DB9; border-right: 1px solid #7F9DB9; border-top: 1px solid #7F9DB9; border-bottom: 1px solid #7F9DB9;">
  <tr>
    <td width="95%" height="20" nowrap ><table width="100%" height="20"  border="0" align="center" cellpadding="0" cellspacing="0" style="border-bottom: 1px solid #7F9DB9;">
        <tr >
          <td width="96%" height="19" nowrap bgcolor="#E1204F" b><span class="style2"><span class="style20">&nbsp;<span class="style18">CUSTOMER ISSUE TRACKING </span></span></span></td>
        </tr>
    </table></td>
  </tr>
  <tr>
    <td height="422" valign="top" nowrap>
	<form action="" method="post" name="ReturnDepartmentSelect" id="ReturnDepartmentSelect">
	  <div align="center">
	    <p class="style11"><strong>
	         
			 
		    <span class="style19">
			 <?php
     $con = mysql_connect("localhost","root","");
     if (!$con) {die('Could not connect: ' . mysql_error());}
     mysql_select_db("bmpl_system") or die(mysql_error());
			  
			  
	 $query = mysql_query(" SELECT * FROM sys_user WHERE usr_id = '$loginUser_id' ");  
	 while($row = mysql_fetch_array($query))
     {
	 $deprtmnt = $row['usr_department'];
     }
	 
	 $queryl = mysql_query(" SELECT * FROM sys_user_right WHERE usr_id = '$loginUser_id' and rgt_name = 'CUSTOMERQUERYTRACKINGINPUT' ");  
	 while($row = mysql_fetch_array($queryl))
     {
	 $rgtname = $row['rgt_name'];
     }
	 
	 if ($rgtname != "CUSTOMERQUERYTRACKINGINPUT")
	 
	 {
 include_once 'unuthorized.php';	
	  exit;
	 }?>
	      </span></strong></p>
	    </div>
	</form>
	<form action="rec-pageexe.php" method="post" enctype="multipart/form-data" >
	
      <table width="80%" height="489"  border="0" align="center" cellpadding="0" cellspacing="0" class="style11" >
        <tr class="style6">
          <td height="13" align="right" nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="13" align="right" nowrap >&nbsp;</td>
          <td nowrap ><div align="center"><span class="style16">              
  
        </span> <span class="style16">
        <?php    
  
        mysql_connect("localhost", "root", "") or die(mysql_error());
        mysql_select_db("bmpl_system") or die(mysql_error());
        $result = mysql_query("SELECT * FROM sys_user WHERE usr_id = '$loginUser_id' ") or die(mysql_error());  
        while($row = mysql_fetch_array( $result )) 
        {  
        $fullname       = $row['usr_full_name'];
        $userdepartment = $row['usr_department'];
        $userbranch     = $row['usr_branch'];
        } 
        ?>
        <span class="style2"><span class="style3">        </span></span> </span></div></td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="14" nowrap style="border-bottom: 1px solid #7F9DB9;">&nbsp;</td>
          <td nowrap style="border-bottom: 1px solid #7F9DB9;"><span class="style2"><span class="style3">Basic Details </span></span></td>
          <td nowrap style="border-bottom: 1px solid #7F9DB9;">&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="13" align="right" nowrap >&nbsp;</td>
          <td nowrap >&nbsp;		 </td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td width="28%" height="23" align="right" nowrap >Issue Ref.  # </td>
          <td width="31%" nowrap ><table width="100%"  border="0" align="center" cellpadding="0" cellspacing="0" >
              <tr>
                <td width="29%" nowrap class="style11" ><?php
               
               mysql_connect("localhost", "root", "") or die(mysql_error());
               mysql_select_db("bmpl_servicedeliveryportal") or die(mysql_error());
               $result = mysql_query("SELECT iss_code FROM sd_issue order by iss_code") or die(mysql_error());  
               while($row = mysql_fetch_array( $result )) 
               {  
               $name = $row['iss_code'];
               } 
               $number = ($name + 1);
              ?>
                    <input name="inumbern" type="text" disabled class="style13" id="inumbern" value="CIN<?php echo "$number"; ?>"></td>
                <td width="39%" nowrap class="style11" ><input name="inumber" type="hidden" class="style3" id="inumber" value="CIN<?php echo "$number"; ?>"></td>
                <td width="32%" align="center" nowrap class="style11"  ><div align="right">Reporting Date|Time</div></td>
              </tr>
          </table></td>
          <td width="41%" nowrap ><input name="idaten" type="text" disabled class="style13" id="idaten" value="<?php echo date("d-m-Y | H:i:s", time()); ?>">
            <input name="idate" type="hidden"  class="style11" id="idate" value="<?php echo date("d-m-Y | H:i:s", time()); ?>"></td>
        </tr>
        <tr class="style6">
          <td height="28" align="right" nowrap >Inputed by </td>
          <td nowrap ><table width="100%"  border="0" align="center" cellpadding="0" cellspacing="0" >
            <tr>
              <td width="29%" nowrap class="style11" ><input name="ireportedbyn" type="text" disabled class="style13" id="ireportedbyn" value="<?php echo "$fullname"; ?>"></td>
              <td width="39%" nowrap class="style11" ><input name="ireportedby" type="hidden" class="style11" id="ireportedby" value="<?php echo "$fullname"; ?>"></td>
              <td width="32%" align="center" nowrap class="style11" ><div align="right"></div></td>
            </tr>
          </table></td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="13" align="right" nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="13" align="right" nowrap style="border-bottom: 1px solid #7F9DB9;">&nbsp;</td>
          <td nowrap style="border-bottom: 1px solid #7F9DB9;"><span class="style2"><span class="style3">Cusomer Details </span></span></td>
          <td nowrap style="border-bottom: 1px solid #7F9DB9;">&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="13" align="right" nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="23" align="right" nowrap >*Name</td>
          <td nowrap >            <table width="100%"  border="0" align="center" cellpadding="0" cellspacing="0" >
              <tr>
                <td width="29%" nowrap class="style11" ><input name="icname" type="text" class="style13" id="icname" size="50" ></td>
                <td width="39%" nowrap class="style11" >&nbsp;</td>
                <td width="32%" align="center" nowrap class="style11" ><div align="right">Tel Number</div></td>
              </tr>
            </table></td>
          <td nowrap ><input name="ictell" type="text" class="style13" id="ictell" ></td>
        </tr>
        <tr class="style6">
          <td height="23" align="right" nowrap >Email </td>
          <td nowrap ><input name="icemail" type="text" class="style13" id="icemail" size="35" ></td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="13" align="right" nowrap >&nbsp;</td>
          <td nowrap ><table width="100%"  border="0" align="center" cellpadding="0" cellspacing="0" >
              <tr>
                <td width="29%" nowrap class="style11" >&nbsp;</td>
                <td width="39%" nowrap class="style11" >&nbsp;</td>
                <td width="32%" align="center" nowrap class="style11" ><div align="right"></div></td>
              </tr>
          </table></td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="14" align="right" nowrap style="border-bottom: 1px solid #7F9DB9;" >&nbsp;</td>
          <td nowrap style="border-bottom: 1px solid #7F9DB9;"><span class="style2"><span class="style3">Issue Details</span></span></td>
          <td nowrap style="border-bottom: 1px solid #7F9DB9;">&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="13" align="right" nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="27" align="right" nowrap >*Product Type </td>
          <td nowrap ><table width="100%"  border="0" align="center" cellpadding="0" cellspacing="0" >
            <tr>
              <td width="29%" nowrap class="style11" ><select name="iproduct" class="style13" id="iproduct">
                <option value="Select Product Type">Select Product Type</option>
                <option value="TT">TT</option>
                <option value="TISS">TISS</option>
                <option value="CCE">CCE</option>
                <option value="CDR">CDR</option>
                <option value="CIT">CIT</option>
                <option value="EFT">EFT</option>
				<option value="Cash">Cash</option>
				<option value="Forex">Forex</option>
				<option value="Cheque">Cheque</option>
				<option value="Account">Account</option>
				<option value="Statement">Statement</option>
				<option value="Account Balance">Account Balance</option>
				<option value="Inward TT">Inward TT</option>
				<option value="Inward TISS">Inward TISS</option>
				<option value="Complain">Complain</option>
				<option value="Money Wireless">Money Wireless</option>
				<option value="Money Mail">Money Mail</option>
				<option value="Credit">Credit</option>
				<option value="Trade Finance">Trade Finance</option>
                            </select></td>
              <td width="39%" nowrap class="style11" >&nbsp;</td>
              <td width="32%" align="center" nowrap class="style11" ><div align="right">*Received by </div></td>
            </tr>
          </table></td>
          <td nowrap ><input name="ireceivedby" type="text" class="style13" id="ireceivedby"></td>
        </tr>
        <tr class="style6">
          <td height="27" align="right" nowrap >*Mode of Receipt </td>
          <td nowrap >            <table width="100%"  border="0" align="center" cellpadding="0" cellspacing="0" >
              <tr>
                <td width="29%" nowrap class="style11" ><select name="imode" class="style13" id="imode">
                  <option value="Select Mode of Receipt">Select Mode of Receipt</option>
                  <option value="Telephone">Telephone</option>
                  <option value="Mail">Mail</option>
                </select></td>
                <td width="39%" nowrap class="style11" >&nbsp;</td>
                <td width="32%" align="center" nowrap class="style11" ><div align="right">*Priority</div></td>
              </tr>
            </table></td>
          <td nowrap ><select name="ipriority" class="style13" id="ipriority">
            <option value="Select Priority">Select Priority</option>
            <option value="Low">Low</option>
            <option value="Medium">Medium</option>
            <option value="High">High</option>
          </select></td>
        </tr>
        <tr class="style6">
          <td height="22" align="right" nowrap >*Status</td>
          <td nowrap ><table width="100%"  border="0" align="center" cellpadding="0" cellspacing="0" >
              <tr>
                <td width="29%" nowrap class="style11" ><select name="istatus" class="style13" id="istatus">
                  <option value="Select Status">Select Status</option>
                  <option value="Work in Progress">Work in Progress</option>
                  <option value="Pending">Pending</option>
                  <option value="Resolved">Resolved</option>
                </select></td>
                <td width="39%" nowrap class="style11" >&nbsp;</td>
                <td width="32%" align="center" nowrap class="style11" ><div align="right"></div></td>
              </tr>
          </table></td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="90" align="right" nowrap ><p>*Issue Description</p></td>
          <td nowrap ><textarea name="idescription" cols="70" rows="5" class="style13" id="idescription"></textarea></td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="13" align="right" nowrap >Department | Person Responsible</td>
          <td nowrap ><input name="iresponsible" type="text" class="style13" id="iresponsible" size="50" ></td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="13" align="right" nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="13" align="right" nowrap style="border-bottom: 1px solid #7F9DB9;">&nbsp;</td>
          <td nowrap style="border-bottom: 1px solid #7F9DB9;"><span class="style2"><span class="style3">Action </span></span></td>
          <td nowrap style="border-bottom: 1px solid #7F9DB9;">&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="13" align="right" nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="21" align="right" nowrap >&nbsp;</td>
          <td nowrap >
              <div align="left">
                <input name="Record" type="Submit" class="style13" id="Record" value="Record" OnClick="show_alert()">
                <input name="Reset Form" type="reset" class="style13" id="Submit" value="Reset Form">
                <a href="index.php"><input name="Exit" type="button" class="style13" id="Submit" value="Exit"></a>
              </div></td><td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="21" align="right" nowrap >&nbsp;</td>
          <td nowrap >*  Mandatory fields
            <div align="center">
          </div></td>
          <td nowrap >&nbsp;</td>
        </tr>
      </table>
      </form>
    </td>
  </tr>
</table>
</body>
</html>
