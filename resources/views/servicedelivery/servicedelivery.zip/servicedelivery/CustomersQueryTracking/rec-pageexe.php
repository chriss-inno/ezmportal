<?php
session_start();
$loginUser_id = $_SESSION['SESS_USER_ID'];
require_once('../../../config/auth_content.php');
?> 
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<script type="text/javascript"> 
 function show_alert() { 
 var msg = "Submited Successful, press OK and wait for the page to finish loading. Do not press LOG again!";
 alert(msg); 
 }
 </script>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Untitled Document</title>
<style type="text/css">
<!--
.style2 {
	color: #ffffff;
	font-weight: bold;
}
.style3 {font-size: 11px; font-family: tahoma;}
.style6 {font-size: 11px}
.style11 {font-family: tahoma; font-size: 11px; color: #ffffff; }
.style13 {font-family: tahoma; font-size: 11px; color: #0E3793; }
.style12 {font-family: tahoma}
a:link {
	text-decoration: none;
}
a:visited {
	text-decoration: none;
}
a:hover {
	text-decoration: none;
}
a:active {
	text-decoration: none;
}
.style14 {color: #0E3793}
.style16 {font-family: tahoma; font-size: 11px; color: #0E3793; font-weight: bold; }
body {
	background-image: url(../../images/backgrounds/pagebg.png);
}
.style18 {font-size: 11px; font-family: tahoma; color: #FFFFFF; }
.style19 {font-size: 11px; font-family: tahoma; color: #FFFFFF; font-weight: bold; }
.style20 {	color: #0E3793;
	font-weight: bold;
}
-->
</style>
	
	<script type="text/javascript" src="../../support/js/jquery.min.js"></script>
	<script type="text/javascript" src="../../support/js/control.js"></script>
</head>
<script type="text/javascript">
// Popup window code
function newPopup(url) {
	popupWindow = window.open(
		url,'popUpWindow','height=300,width=500,left=10,top=10,resizable=yes,scrollbars=yes,toolbar=yes,menubar=no,location=no,directories=no,status=yes,dependent=yes,menubar=no,resizable=no,scrollbars=yes')
		                   
}
</script>
<body>
<table width="100%" border="0" cellpadding="5" cellspacing="0">
  <tr>
    <td></td>
  </tr>
</table>
<table width="100%"  border="0" align="center" cellpadding="0" cellspacing="0" style="border-left: 1px solid #7F9DB9; border-right: 1px solid #7F9DB9; border-top: 1px solid #7F9DB9; border-bottom: 1px solid #7F9DB9;">
  <tr>
    <td width="95%" height="20" nowrap ><table width="100%" height="20"  border="0" align="center" cellpadding="0" cellspacing="0" style="border-bottom: 1px solid #7F9DB9;">
        <tr >
          <td width="96%" height="19" nowrap bgcolor="#E1204F" b><span class="style2"><span class="style20">&nbsp;<span class="style18">CUSTOMER ISSUE TRACKING </span></span></span></td>
        </tr>
    </table></td>
  </tr>
  <tr>
    <td height="86" valign="top" nowrap>
	<form action="" method="post" enctype="multipart/form-data" >
	
      <table width="80%" height="81"  border="0" align="center" cellpadding="0" cellspacing="0" class="style11" >
        <tr class="style6">
          <td width="41%" height="13" nowrap >&nbsp;</td>
          </tr>
        <tr class="style6">
          <td height="13" nowrap ><div align="center"><span class="style16">              
  
        </span> <span class="style16">        <span class="style2"><span class="style3">
        <?php
if (isset($_POST['Record'])) 
{				
 
$inumber           = $_POST['inumber'];
$ireportedby       = $_POST['ireportedby'];
$idate             = $_POST['idate'];
$itime             = $_POST['itime'];
$icname            = $_POST['icname'];
$icmname           = $_POST['icmname'];
$iproduct          = $_POST['iproduct'];
$iproductdetails   = $_POST['iproductdetails'];
$ireceivedby       = $_POST['ireceivedby'];
$imode             = $_POST['imode'];
$istatus           = $_POST['istatus'];
$idescription      = $_POST['idescription'];
$iresponsible      = $_POST['iresponsible'];



If ($iproduct === "Account" && $iproductdetails  === "Select Product Details" )
{
echo "Product details for Product '$iproduct' not selected";
exit;}

If ($iproduct === "Cheque" && $iproductdetails  === "Select Product Details" )
{
echo "Product details for Product '$iproduct' not selected";
exit;}


If ($iresponsible === "Select Department") {
echo "Issue responsible department not selected";
exit;}

If ($icname === "") {
echo "No customer name inputed on issue";
exit;}

If ($ireceivedby === "Select Received by") {
echo "No received by name selected on issue received by";
exit;}

If ($iproduct === "Select Product Type") {
echo "Issue product type not selected";
exit;}



If ($imode === "Select Mode of Receipt") {
echo "Issue mode of receipts not selected";
exit;}

If ($istatus === "Select Status") {
echo "Issue status not selected";
exit;}

If ($idescription === "") {
echo "No description inputed on issue description";
exit;}

If ($iproduct === "Account") 
{
$iproduct = "$iproduct/$iproductdetails";
}

If ($iproduct === "Cheque") 
{
$iproduct = "$iproduct/$iproductdetails";
}

mysql_connect("localhost","root",""); 
mysql_select_db("bmpl_servicedeliveryportal") or die("Unable to select database");

@mysql_query("INSERT INTO sd_issue (iss_reference_number, iss_reported_date, iss_reported_time, iss_inputed_by, iss_customer_name, iss_contact_person, iss_product_type, iss_received_by, iss_received_mode, iss_status, iss_issue_description, iss_root_caused, iss_responsible, iss_note, iss_resolution_date)
VALUES('$inumber','$idate','$itime','$ireportedby', UPPER('$icname'), UPPER('$icmname'), '$iproduct','$ireceivedby','$imode','$istatus','$idescription','NA','$iresponsible','NA','0000-00-00')");

@mysql_query("INSERT INTO sd_progress (iss_number, prg_description, prg_status, prg_date, prg_time, prg_inputed_by)
VALUES('$inumber','$idescription','$istatus','$idate', '$itime','$ireportedby')");


@mysql_query("INSERT INTO sd_resolutionprogress (iss_number, rpg_responsible, rpg_caused, rpg_note, rpg_date, rpg_time, rpg_inputed_b)
VALUES('$inumber','$iresponsible','NA','NA','$idate','$itime','$ireportedby')");


If ($istatus === "Resolved") 
{
$itat = $itime;
@mysql_query("UPDATE sd_issue SET iss_resolution_time = '$itat' WHERE iss_reference_number = '$inumber'");
}

echo "<p>&nbsp;</p>";

echo "<p>&nbsp;</p>";
echo "Issue $inumber Successfull Recorded !";
echo "<p>&nbsp;</p>";

} 
			?>
        </span></span>        <span class="style2"><span class="style3">        </span></span> </span></div></td>
          </tr>
        <tr class="style6">
          <td height="13" nowrap >&nbsp;</td>
          </tr>
        <tr class="style6">
          <td height="21" nowrap >
                <div align="center">
                  <a href="rec-page.php"></a> &nbsp;&nbsp;&nbsp; <a href="rec-page.php">
<input name="Exit" type="button" class="style13" id="Submit" value="Exit">
              </a></div>
              </div></td>
        </tr>
        <tr class="style6">
          <td height="21" nowrap ><div align="center">
            <span class="style2"><span class="style3">            </span></span>
          </div></td>
          </tr>
      </table>
      </form>
    </td>
  </tr>
</table>
</body>
</html>
