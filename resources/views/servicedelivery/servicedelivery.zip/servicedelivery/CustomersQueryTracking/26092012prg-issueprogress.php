<?php
session_start();
$loginUser_id = $_SESSION['SESS_USER_ID'];
require_once('../../../config/auth_content.php');
?> 
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<script type="text/javascript"> 
 function show_alert() { 
 var msg = "Submited Successful, press OK and wait for the page to finish loading. Do not press LOG again!";
 alert(msg); 
 }
 </script>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Untitled Document</title>
<style type="text/css">
<!--
.style2 {
	color: #ffffff;
	font-weight: bold;
}
.style3 {font-size: 11px; font-family: tahoma;}
.style6 {font-size: 11px}
.style11 {font-family: tahoma; font-size: 11px; color: #ffffff; }
.style13 {font-family: tahoma; font-size: 11px; color: #0E3793; }
a:link {
	text-decoration: none;
}
a:visited {
	text-decoration: none;
}
a:hover {
	text-decoration: none;
}
a:active {
	text-decoration: none;
}
.style16 {font-family: tahoma; font-size: 11px; color: #0E3793; font-weight: bold; }
body {
	background-image: url(../../images/backgrounds/pagebg.png);
}
.style18 {font-size: 11px; font-family: tahoma; color: #FFFFFF; }
.style19 {font-size: 11px; font-family: tahoma; color: #FFFFFF; font-weight: bold; }
.style20 {	color: #0E3793;
	font-weight: bold;
}
-->
</style>
	
	<script type="text/javascript" src="../../support/js/jquery.min.js"></script>
	<script type="text/javascript" src="../../support/js/control.js"></script>
</head>
<script type="text/javascript">
// Popup window code
function newPopup(url) {
	popupWindow = window.open(
		url,'popUpWindow','height=300,width=500,left=10,top=10,resizable=yes,scrollbars=yes,toolbar=yes,menubar=no,location=no,directories=no,status=yes,dependent=yes,menubar=no,resizable=no,scrollbars=yes')
		                   
}
</script>
<body>
<table width="100%" border="0" cellpadding="5" cellspacing="0">
  <tr>
    <td></td>
  </tr>
</table>
<table width="100%"  border="0" align="center" cellpadding="0" cellspacing="0" style="border-left: 1px solid #7F9DB9; border-right: 1px solid #7F9DB9; border-top: 1px solid #7F9DB9; border-bottom: 1px solid #7F9DB9;">
  <tr>
    <td width="95%" height="20" nowrap ><table width="100%" height="20"  border="0" align="center" cellpadding="0" cellspacing="0" style="border-bottom: 1px solid #7F9DB9;">
        <tr >
          <td width="96%" height="19" nowrap bgcolor="#E1204F" b><span class="style2"><span class="style20">&nbsp;<span class="style18">CUSTOMER ISSUE TRACKING </span></span></span></td>
        </tr>
    </table></td>
  </tr>
  <tr>
    <td height="422" valign="top" nowrap>
	<form action="" method="post" name="ReturnDepartmentSelect" id="ReturnDepartmentSelect">
	  <div align="center">
	    <p class="style11"><strong>
	         
			 
		    <span class="style19">
			 <?php
     $con = mysql_connect("localhost","root","");
     if (!$con) {die('Could not connect: ' . mysql_error());}
     mysql_select_db("bmpl_system") or die(mysql_error());
			  
			  
	 $query = mysql_query(" SELECT * FROM sys_user WHERE usr_id = '$loginUser_id' ");  
	 while($row = mysql_fetch_array($query))
     {
	 $deprtmnt = $row['usr_department'];
     }
	 
	 $queryl = mysql_query(" SELECT * FROM sys_user_right WHERE usr_id = '$loginUser_id' and rgt_name = 'CUSTOMERQUERYTRACKINGINPUT' ");  
	 while($row = mysql_fetch_array($queryl))
     {
	 $rgtname = $row['rgt_name'];
     }
	 
	 if ($rgtname != "CUSTOMERQUERYTRACKINGINPUT")
	 
	 {
 include_once 'unuthorized.php';	
	  exit;
	 }?>
	      </span></strong></p>
	    </div>
	</form>
	<form action="prg-issueprogress.php" method="post" enctype="multipart/form-data" >
	
      <table width="80%" height="968"  border="0" align="center" cellpadding="0" cellspacing="0" class="style11" >
        <tr class="style6">
          <td height="13" align="right" nowrap >&nbsp;</td>
          <td nowrap ><div align="center"><span class="style16">              
  
          </span> <span class="style16">
		    
		  
		    <span class="style2"><span class="style3"><?php
		   $iss_reference_number = $_GET['iss_reference_number'];
			  
               mysql_connect("localhost", "root", "") or die(mysql_error());
               mysql_select_db("bmpl_servicedeliveryportal") or die(mysql_error());
               $result = mysql_query("SELECT * FROM sd_issue WHERE iss_reference_number = '$iss_reference_number' ") or die(mysql_error());  
               while($row = mysql_fetch_array( $result )) 
               {   
			   
   $iss_reference_number   = $row['iss_reference_number'];
   $iss_reported_datetime  = $row['iss_reported_datetime'];
   $iss_inputed_by         = $row['iss_inputed_by'];
   $iss_customer_name      = $row['iss_customer_name'];
   $iss_customer_number    = $row['iss_customer_number'];
   $iss_customer_email     = $row['iss_customer_email'];
   $iss_product_type       = $row['iss_product_type'];
   $iss_received_by        = $row['iss_received_by'];
   $iss_received_mode      = $row['iss_received_mode'];
   $iss_priority           = $row['iss_priority'];
   $iss_status             = $row['iss_status'];
   $iss_issue_description  = $row['iss_issue_description'];
   $iss_root_caused        = $row['iss_root_caused'];
   $iss_responsible        = $row['iss_responsible'];
   $iss_note               = $row['iss_note'];
   $iss_viable_action      = $row['iss_viable_action'];
   $iss_resolution_datetime= $row['iss_resolution_datetime'];
   $iss_contact_person     = $row['iss_contact_person'];
			   
               } 
		  ?>
            <?php
			
			
			
			
		   if (isset($_POST['UpdateAll'])) 
           {
		   mysql_connect("localhost", "root", "") or die(mysql_error());
           mysql_select_db("bmpl_servicedeliveryportal") or die(mysql_error());
		   
		   $inumber        = $_POST['inumber'];
           $istatus        = $_POST['istatus'];
		   $iresolution    = $_POST['iresolution'];
		   $idescription   = $_POST['idescription'];
		   $iresponsible   = $_POST['iresponsible'];
		   $ireportedby    = $_POST['ireportedby'];
		   $idate          = $_POST['idate'];
		   $iroot          = $_POST['iroot'];
		   $inote          = $_POST['inote'];
		   $iproduct       = $_POST['iproduct'];
		   
If ($istatus === "Select Status") {
echo "Error 001: Could not update issue $inumber status due to issue status not selected";
exit;}

If ($idescription === "") {
echo "Error 002: Could not update issue $inumber description due to no issue description inputed";
exit;}

If ($iroot === "") {
echo "Error 003: Could not update issue $inumber root caused due to issue root caused not inputed";
exit;}

If ($istatus === "") {
echo "Error 004: Could not update issue $inumber remarks caused due to issue remarks not inputed";
exit;}

If ($iss_responsible === "Select Department") {
echo "Error 005: Could not update issue $inumber department responsible due to issue department responsible not selected";
exit;}

If ($istatus === "Select Product Type") 
{
echo "Error 007: Could not update issue $inumber product type due to issue product type not selected";
exit;}




                 
            $iss_stat = "UPDATE sd_issue SET iss_status = '$istatus', iss_product_type = '$iproduct', iss_resolution_datetime = '$iresolution', iss_note = '$inote', iss_responsible = '$iresponsible', iss_root_caused = '$iroot' WHERE iss_reference_number = '$inumber'";
            $result = @mysql_query($iss_stat);
			
			@mysql_query("INSERT INTO sd_progress (iss_number, prg_description, prg_status, prg_datetime, prg_inputed_by)
            VALUES('$inumber','$idescription','$istatus','$idate','$ireportedby')");
			
			
			@mysql_query("INSERT INTO sd_resolutionprogress (iss_number, rpg_responsible, rpg_caused, rpg_note, rpg_datetime, rpg_inputed_by)
            VALUES('$inumber','$iresponsible','$iroot','$inote','$idate','$ireportedby')");
		   
echo "<p>&nbsp;</p>";
echo "Issue $inumber successfull updated !";
echo "<p>&nbsp;</p>";
		    
            $result = mysql_query("SELECT * FROM sd_issue WHERE iss_reference_number = '$inumber' ") or die(mysql_error());  
            while($row = mysql_fetch_array( $result )) 
   {    
   $iss_reference_number   = $row['iss_reference_number'];
   $iss_reported_datetime  = $row['iss_reported_datetime'];
   $iss_inputed_by         = $row['iss_inputed_by'];
   $iss_customer_name      = $row['iss_customer_name'];
   $iss_customer_number    = $row['iss_customer_number'];
   $iss_customer_email     = $row['iss_customer_email'];
   $iss_product_type       = $row['iss_product_type'];
   $iss_received_by        = $row['iss_received_by'];
   $iss_received_mode      = $row['iss_received_mode'];
   $iss_priority           = $row['iss_priority'];
   $iss_status             = $row['iss_status'];
   $iss_issue_description  = $row['iss_issue_description'];
   $iss_root_caused        = $row['iss_root_caused'];
   $iss_responsible        = $row['iss_responsible'];
   $iss_note               = $row['iss_note'];
   $iss_viable_action      = $row['iss_viable_action'];
   $iss_resolution_datetime= $row['iss_resolution_datetime'];
   $iss_contact_person     = $row['iss_contact_person'];
   } 
   } 
			
			
			 if (isset($_POST['SubmitProduct'])) 
           {
           mysql_connect("localhost", "root", "") or die(mysql_error());
           mysql_select_db("bmpl_servicedeliveryportal") or die(mysql_error());
		   
		   $inumber        = $_POST['inumber'];
                   $idate          = $_POST['idate'];
                   $idate          = $_POST['idate'];
                   $ireportedby    = $_POST['ireportedby'];
                   $iproduct       = $_POST['iproduct'];

                 
		   
		   
		   
		   
		   
		   
If ($istatus === "Select Product Type") 
{
echo "Error 001: Could not update issue $inumber product type due to issue product type not selected";
exit;}


            $iss_stat = "UPDATE sd_issue SET iss_product_type = '$iproduct' WHERE iss_reference_number = '$inumber'";
            $result = @mysql_query($iss_stat);
			
			
echo "<p>&nbsp;</p>";
echo "Product Type on issue $inumber successfull updated !";
echo "<p>&nbsp;</p>";
		    
            $result = mysql_query("SELECT * FROM sd_issue WHERE iss_reference_number = '$inumber' ") or die(mysql_error());  
            while($row = mysql_fetch_array( $result )) 
   {    
   $iss_reference_number   = $row['iss_reference_number'];
   $iss_reported_datetime  = $row['iss_reported_datetime'];
   $iss_inputed_by         = $row['iss_inputed_by'];
   $iss_customer_name      = $row['iss_customer_name'];
   $iss_customer_number    = $row['iss_customer_number'];
   $iss_customer_email     = $row['iss_customer_email'];
   $iss_product_type       = $row['iss_product_type'];
   $iss_received_by        = $row['iss_received_by'];
   $iss_received_mode      = $row['iss_received_mode'];
   $iss_priority           = $row['iss_priority'];
   $iss_status             = $row['iss_status'];
   $iss_issue_description  = $row['iss_issue_description'];
   $iss_root_caused        = $row['iss_root_caused'];
   $iss_responsible        = $row['iss_responsible'];
   $iss_note               = $row['iss_note'];
   $iss_viable_action      = $row['iss_viable_action'];
   $iss_resolution_datetime= $row['iss_resolution_datetime'];
   $iss_contact_person     = $row['iss_contact_person'];
   } 
   }  
			
		   if (isset($_POST['SubmitProgress'])) 
           {
		   mysql_connect("localhost", "root", "") or die(mysql_error());
           mysql_select_db("bmpl_servicedeliveryportal") or die(mysql_error());
		   
		   $inumber        = $_POST['inumber'];
           $istatus        = $_POST['istatus'];
		   $idescription   = $_POST['idescription'];
		   $idate          = $_POST['idate'];
		   $ireportedby    = $_POST['ireportedby'];
		   $idate          = $_POST['idate'];
		   
		   
If ($istatus === "Select Status") {
echo "Error 001: Could not update issue $inumber status due to issue status not selected";
exit;}

If ($idescription === "") {
echo "Error 002: Could not update issue $inumber description due to no issue description inputed";
exit;}

            $iss_stat = "UPDATE sd_issue SET iss_status = '$istatus' WHERE iss_reference_number = '$inumber'";
            $result = @mysql_query($iss_stat);
			
			@mysql_query("INSERT INTO sd_progress (iss_number, prg_description, prg_status, prg_datetime, prg_inputed_by)
            VALUES('$inumber','$idescription','$istatus','$idate','$ireportedby')");
			
echo "<p>&nbsp;</p>";
echo "Progress and status on issue $inumber successfull updated !";
echo "<p>&nbsp;</p>";
		    
            $result = mysql_query("SELECT * FROM sd_issue WHERE iss_reference_number = '$inumber' ") or die(mysql_error());  
            while($row = mysql_fetch_array( $result )) 
   {    
   $iss_reference_number   = $row['iss_reference_number'];
   $iss_reported_datetime  = $row['iss_reported_datetime'];
   $iss_inputed_by         = $row['iss_inputed_by'];
   $iss_customer_name      = $row['iss_customer_name'];
   $iss_customer_number    = $row['iss_customer_number'];
   $iss_customer_email     = $row['iss_customer_email'];
   $iss_product_type       = $row['iss_product_type'];
   $iss_received_by        = $row['iss_received_by'];
   $iss_received_mode      = $row['iss_received_mode'];
   $iss_priority           = $row['iss_priority'];
   $iss_status             = $row['iss_status'];
   $iss_issue_description  = $row['iss_issue_description'];
   $iss_root_caused        = $row['iss_root_caused'];
   $iss_responsible        = $row['iss_responsible'];
   $iss_note               = $row['iss_note'];
   $iss_viable_action      = $row['iss_viable_action'];
   $iss_resolution_datetime= $row['iss_resolution_datetime'];
   $iss_contact_person     = $row['iss_contact_person'];
   } 
   }  
		   
		   
		   
		   
		   
		   
		   
		   
		   if (isset($_POST['UpdateResponsible'])) 
           {
		   mysql_connect("localhost", "root", "") or die(mysql_error());
           mysql_select_db("bmpl_servicedeliveryportal") or die(mysql_error());
           
		   $inumber        = $_POST['inumber'];
		   $iresponsible   = $_POST['iresponsible'];
		   $ireportedby    = $_POST['ireportedby'];
		   $idate          = $_POST['idate'];
			
          If ($iresponsible === "Select Department") {
          echo "Issue responsible department not selected";
          exit;}

           $iss_status = "UPDATE sd_issue SET iss_responsible = '$iresponsible' WHERE iss_reference_number = '$inumber'";
           $result = @mysql_query($iss_status);
		   
		  @mysql_query("INSERT INTO sd_resolutionprogress (iss_number, rpg_responsible, rpg_caused, rpg_note, rpg_datetime, rpg_inputed_by)
           VALUES('$inumber','$iresponsible','NA','NA','$idate','$ireportedby')");
		   
		   echo "<p>&nbsp;</p>";
echo "Department | Person on issue $inumber successfull updated !";
echo "<p>&nbsp;</p>";
		   
		    $result = mysql_query("SELECT * FROM sd_issue WHERE iss_reference_number = '$inumber' ") or die(mysql_error());  
            while($row = mysql_fetch_array( $result )) 
   {    
   $iss_reference_number   = $row['iss_reference_number'];
   $iss_reported_datetime  = $row['iss_reported_datetime'];
   $iss_inputed_by         = $row['iss_inputed_by'];
   $iss_customer_name      = $row['iss_customer_name'];
   $iss_customer_number    = $row['iss_customer_number'];
   $iss_customer_email     = $row['iss_customer_email'];
   $iss_product_type       = $row['iss_product_type'];
   $iss_received_by        = $row['iss_received_by'];
   $iss_received_mode      = $row['iss_received_mode'];
   $iss_priority           = $row['iss_priority'];
   $iss_status             = $row['iss_status'];
   $iss_issue_description  = $row['iss_issue_description'];
   $iss_root_caused        = $row['iss_root_caused'];
   $iss_responsible        = $row['iss_responsible'];
   $iss_note               = $row['iss_note'];
   $iss_viable_action      = $row['iss_viable_action'];
   $iss_resolution_datetime= $row['iss_resolution_datetime'];
   $iss_contact_person     = $row['iss_contact_person'];
   } 
           }
		   
		   
		   
		   
		   
		   
		   
		   if (isset($_POST['UpdateCaused'])) 
           {
		   mysql_connect("localhost", "root", "") or die(mysql_error());
           mysql_select_db("bmpl_servicedeliveryportal") or die(mysql_error());
		   
		   
           $inumber = $_POST['inumber'];
		   $iroot   = $_POST['iroot'];
		   $ireportedby    = $_POST['ireportedby'];

            $iss_status = "UPDATE sd_issue SET iss_root_caused = '$iroot' WHERE iss_reference_number = '$inumber'";
            $result = @mysql_query($iss_status);
			
		  @mysql_query("INSERT INTO sd_resolutionprogress (iss_number, rpg_responsible, rpg_caused, rpg_note, rpg_datetime, rpg_inputed_by)
           VALUES('$inumber','NA','$iroot','NA','$idate','$ireportedby')");
		   
		   
		   echo "<p>&nbsp;</p>";
echo "Root cause on issue $inumber successfull updated !";
echo "<p>&nbsp;</p>";

		    $result = mysql_query("SELECT * FROM sd_issue WHERE iss_reference_number = '$inumber' ") or die(mysql_error());  
            while($row = mysql_fetch_array( $result )) 
   {    
   $iss_reference_number   = $row['iss_reference_number'];
   $iss_reported_datetime  = $row['iss_reported_datetime'];
   $iss_inputed_by         = $row['iss_inputed_by'];
   $iss_customer_name      = $row['iss_customer_name'];
   $iss_customer_number    = $row['iss_customer_number'];
   $iss_customer_email     = $row['iss_customer_email'];
   $iss_product_type       = $row['iss_product_type'];
   $iss_received_by        = $row['iss_received_by'];
   $iss_received_mode      = $row['iss_received_mode'];
   $iss_priority           = $row['iss_priority'];
   $iss_status             = $row['iss_status'];
   $iss_issue_description  = $row['iss_issue_description'];
   $iss_root_caused        = $row['iss_root_caused'];
   $iss_responsible        = $row['iss_responsible'];
   $iss_note               = $row['iss_note'];
   $iss_viable_action      = $row['iss_viable_action'];
   $iss_resolution_datetime= $row['iss_resolution_datetime'];
   $iss_contact_person     = $row['iss_contact_person'];
   } 			
           }
		   
		   if (isset($_POST['UpdateRemarks'])) 
           {
		   mysql_connect("localhost", "root", "") or die(mysql_error());
           mysql_select_db("bmpl_servicedeliveryportal") or die(mysql_error());
		   
		   
		   
           $inumber = $_POST['inumber'];
		   $inote   = $_POST['inote'];
		   $ireportedby    = $_POST['ireportedby'];

            $iss_status = "UPDATE sd_issue SET iss_note = '$inote' WHERE iss_reference_number = '$inumber'";
            $result = @mysql_query($iss_status);
			
			 @mysql_query("INSERT INTO sd_resolutionprogress (iss_number, rpg_responsible, rpg_caused, rpg_note, rpg_datetime, rpg_inputed_by)
             VALUES('$inumber','NA','NA','$inote','$idate','$ireportedby')");
			
			echo "<p>&nbsp;</p>";
echo "Remarks on issue $inumber successfull updated !";
echo "<p>&nbsp;</p>";
			
			$result = mysql_query("SELECT * FROM sd_issue WHERE iss_reference_number = '$inumber' ") or die(mysql_error());  
            while($row = mysql_fetch_array( $result )) 
   {    
   $iss_reference_number   = $row['iss_reference_number'];
   $iss_reported_datetime  = $row['iss_reported_datetime'];
   $iss_inputed_by         = $row['iss_inputed_by'];
   $iss_customer_name      = $row['iss_customer_name'];
   $iss_customer_number    = $row['iss_customer_number'];
   $iss_customer_email     = $row['iss_customer_email'];
   $iss_product_type       = $row['iss_product_type'];
   $iss_received_by        = $row['iss_received_by'];
   $iss_received_mode      = $row['iss_received_mode'];
   $iss_priority           = $row['iss_priority'];
   $iss_status             = $row['iss_status'];
   $iss_issue_description  = $row['iss_issue_description'];
   $iss_root_caused        = $row['iss_root_caused'];
   $iss_responsible        = $row['iss_responsible'];
   $iss_note               = $row['iss_note'];
   $iss_viable_action      = $row['iss_viable_action'];
   $iss_resolution_datetime= $row['iss_resolution_datetime'];
   $iss_contact_person     = $row['iss_contact_person'];
   } 			
           }
			  
			  
			  
			  
               ?>
</span></span></span></div></td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="14" nowrap style="border-bottom: 1px solid #7F9DB9;">&nbsp;</td>
          <td nowrap style="border-bottom: 1px solid #7F9DB9;"><span class="style2"><span class="style3">Basic Details </span></span></td>
          <td nowrap style="border-bottom: 1px solid #7F9DB9;">&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="13" align="right" nowrap >&nbsp;</td>
          <td nowrap >
		  
		  
		  
	
				 
				 
				 
          </td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td width="28%" height="23" align="right" nowrap >Issue Ref.  # </td>
          <td width="31%" nowrap ><table width="100%"  border="0" align="center" cellpadding="0" cellspacing="0" >
              <tr>
                <td width="29%" nowrap class="style11" >
                    <input name="inumbern" type="text"  class="style13" id="inumbern" value="<?php echo "$iss_reference_number"; ?>"></td>
                <td width="39%" nowrap class="style11" ><input name="inumber" type="hidden" class="style3" id="inumber" value="<?php echo "$iss_reference_number"; ?>"></td>
                <td width="32%" align="center" nowrap class="style11"  ><div align="right">Reporting Date</div></td>
              </tr>
          </table></td>
          <td width="41%" nowrap ><input name="idaten" type="text"  class="style13" id="idaten" value="<?php echo "$iss_reported_datetime"; ?>">
            <input name="idate" type="hidden"  class="style11" id="idate" value="<?php echo date("d-m-Y | H:i:s", time()); ?>"></td>
        </tr>
        <tr class="style6">
          <td height="28" align="right" nowrap >Inputed by </td>
          <td nowrap ><table width="100%"  border="0" align="center" cellpadding="0" cellspacing="0" >
            <tr>
              <td width="29%" nowrap class="style11" ><input name="ireportedbyn" type="text"  class="style13" id="ireportedbyn" value="<?php echo "$iss_inputed_by"; ?>"></td>
              <td width="39%" nowrap class="style11" ><input name="ireportedby" type="hidden" class="style11" id="ireportedby" value="<?php echo "$iss_inputed_by"; ?>"></td>
              <td width="32%" align="center" nowrap class="style11" ><div align="right">Reporting Time</div></td>
            </tr>
          </table></td>
          <td nowrap ><input name="itimen" type="text"  class="style13" id="itimen" value="<?php echo "$iss_reported_datetime"; ?>">
            <input name="itime" type="hidden"  class="style11" id="itime" value="<?php echo date("d-m-Y | H:i:s", time()); ?>"></td>
        </tr>
        <tr class="style6">
          <td height="13" align="right" nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="13" align="right" nowrap style="border-bottom: 1px solid #7F9DB9;">&nbsp;</td>
          <td nowrap style="border-bottom: 1px solid #7F9DB9;"><span class="style2"><span class="style3">Issue Progress Description</span></span></td>
          <td nowrap style="border-bottom: 1px solid #7F9DB9;">&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="13" align="right" nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="26" align="right" nowrap >Current Status </td>
          <td nowrap ><input name="ictell" type="text" class="style13" id="ictell" value="<?php echo "$iss_status"; ?>" size="50" ></td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="26" align="right" nowrap >Status</td>
          <td nowrap ><select name="istatus" class="style13" id="istatus">
            <option value="Select Status">Select Status</option>
<option value="Pending awaiting resolution">Pending awaiting resolution</option>
<option value="Pending awaiting clients confirmation">Pending awaiting clients confirmation</option>
<option value="Resolved">Resolved</option>
          </select> 
          *</td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="26" align="right" nowrap >Resolution Date</td>
          <td nowrap ><input name="iresolution" type="text" class="style13" id="iresolution" value="<?php echo "$iss_resolution_datetime"; ?>" >            
          &nbsp;&nbsp;
            Format: yyyy-mm-dd **</td>
          <td nowrap >Required to be inputted when Status Selected is<strong> Resolved</strong> </td>
        </tr>
        <tr class="style6">
          <td height="96" align="right" nowrap >Description</td>
          <td nowrap ><textarea name="idescription" cols="70" rows="5" class="style13" id="idescription"></textarea></td>
          <td nowrap >*</td>
        </tr>
        <tr class="style6">
          <td height="13" align="right" nowrap >&nbsp;</td>
          <td nowrap ><input name="SubmitProgress" type="submit" class="style13" id="SubmitProgress" OnClick="show_alert()" value="Submit Progress"></td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="13" align="right" nowrap style="border-bottom: 1px solid #7F9DB9;">&nbsp;</td>
          <td nowrap style="border-bottom: 1px solid #7F9DB9;">&nbsp;</td>
          <td nowrap style="border-bottom: 1px solid #7F9DB9;">&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="13" align="right" nowrap >&nbsp;</td>
          <td nowrap ><span class="style2"><span class="style3">Cusomer Details </span></span></td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="13" align="right" nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="23" align="right" nowrap >Company Name</td>
          <td nowrap ><table width="100%"  border="0" align="center" cellpadding="0" cellspacing="0" >
            <tr>
              <td width="29%" nowrap class="style11" ><input name="icname" type="text" class="style13" id="icname" value="<?php echo "$iss_customer_name"; ?>" size="50" ></td>
              <td width="39%" nowrap class="style11" >&nbsp;</td>
              <td width="32%" align="center" nowrap class="style11" ><div align="right"></div></td>
            </tr>
          </table></td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="23" align="right" nowrap >Contact Person </td>
          <td nowrap ><table width="100%"  border="0" align="center" cellpadding="0" cellspacing="0" >
            <tr>
              <td width="29%" nowrap class="style11" ><input name="icmname" type="text" class="style13" id="icmname" style="text-transform:uppercase;" value="<?php echo "$iss_contact_person"; ?>" size="50" ></td>
              <td width="39%" nowrap class="style11" >&nbsp;</td>
              <td width="32%" align="center" nowrap class="style11" ><div align="right"></div></td>
            </tr>
          </table></td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="13" align="right" nowrap >&nbsp;</td>
          <td nowrap ><table width="100%"  border="0" align="center" cellpadding="0" cellspacing="0" >
              <tr>
                <td width="29%" nowrap class="style11" >&nbsp;</td>
                <td width="39%" nowrap class="style11" >&nbsp;</td>
                <td width="32%" align="center" nowrap class="style11" ><div align="right"></div></td>
              </tr>
          </table></td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="14" align="right" nowrap style="border-bottom: 1px solid #7F9DB9;" >&nbsp;</td>
          <td nowrap style="border-bottom: 1px solid #7F9DB9;"><span class="style2"><span class="style3">Issue Details</span></span></td>
          <td nowrap style="border-bottom: 1px solid #7F9DB9;">&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="13" align="right" nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="27" align="right" nowrap >Current Product Type </td>
          <td nowrap ><table width="100%"  border="0" align="center" cellpadding="0" cellspacing="0" >
            <tr>
              <td width="29%" nowrap class="style11" >                <input name="cur_iproduct" type="text" class="style13" id="cur_iproduct" value="<?php echo "$iss_product_type "; ?>" ></td>
              <td width="39%" nowrap class="style11" >&nbsp;</td>
              <td width="32%" align="center" nowrap class="style11" ><div align="right"></div></td>
            </tr>
          </table></td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="27" align="right" nowrap >Product Type </td>
          <td nowrap ><table width="100%"  border="0" align="center" cellpadding="0" cellspacing="0" >
            <tr>
              <td width="29%" nowrap class="style11" ><select name="iproduct" class="style13" id="iproduct">
                <option value="Select Product Type">Select Product Type</option>
                <option value="TT">TT</option>
                <option value="TISS">TISS</option>
                <option value="CCE">CCE</option>
                <option value="CDR">CDR</option>
                <option value="CIT">CIT</option>
                <option value="EFT">EFT</option>
                <option value="Cash">Cash</option>
                <option value="Forex">Forex</option>
                <option value="Cheque">Cheque</option>
                <option value="Account">Account</option>
                <option value="Statement">Statement</option>
                <option value="Account Balance">Account Balance</option>
                <option value="Inward TT">Inward TT</option>
                <option value="Inward TISS">Inward TISS</option>
                <option value="Complain">Complain</option>
                <option value="Money Wireless">Money Wireless</option>
                <option value="Money Mail">Money Mail</option>
                <option value="Credit">Credit</option>
                <option value="Trade Finance">Trade Finance</option>
                <option value="Money Msafiri">Money Msafiri</option>
              </select></td>
              <td width="39%" nowrap class="style11" >*</td>
              <td width="32%" align="center" nowrap class="style11" ><div align="right">Received by </div></td>
            </tr>
          </table></td>
          <td nowrap ><input name="ireceivedby" type="text" class="style13" id="ireceivedby" value="<?php echo "$iss_received_by"; ?>"></td>
        </tr>
        <tr class="style6">
          <td height="27" align="right" nowrap >&nbsp;</td>
          <td nowrap ><input name="SubmitProduct" type="submit" class="style13" id="SubmitProduct" OnClick="show_alert()" value="Update Product Type"></td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="27" align="right" nowrap >Mode of Receipt </td>
          <td nowrap >            <table width="100%"  border="0" align="center" cellpadding="0" cellspacing="0" >
              <tr>
                <td width="29%" nowrap class="style11" >                  <input name="imode" type="text" class="style13" id="imode" value="<?php echo "$iss_received_mode"; ?>" ></td>
                <td width="39%" nowrap class="style11" >&nbsp;</td>
                <td width="32%" align="center" nowrap class="style11" ><div align="right"></div></td>
              </tr>
            </table></td>
          <td nowrap >&nbsp;            </td>
        </tr>
        <tr class="style6">
          <td height="13" align="right" nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="13" align="right" nowrap style="border-right: 1px solid #7F9DB9;">Issue Progress &nbsp;&nbsp;&nbsp;</td>
          <td nowrap >
		   <?php
               mysql_connect("localhost", "root", "") or die(mysql_error());
               mysql_select_db("bmpl_servicedeliveryportal") or die(mysql_error());
               $result = mysql_query("SELECT * FROM sd_progress WHERE iss_number = '$iss_reference_number' ") or die(mysql_error());                 
    while($row = mysql_fetch_array($result))
    { 
	
    echo '&nbsp;&nbsp;<span class=style13><textarea name=textarea cols=70 rows=5 class=style13>'.''.$row["prg_description"].'</textarea></span></br>';
	echo '&nbsp;&nbsp;<span class=style13><textarea name=textarea cols=30 rows=1 class=style13>'.''.$row["prg_status"].'</textarea></span></br>';
	echo '&nbsp;&nbsp;<span class=style13><textarea name=textarea cols=30 rows=1 class=style13>'.''.$row["prg_inputed_by"].'</textarea></span>';
	echo '&nbsp;&nbsp;<input name=textfield type=text class=style13 value='.''.$row['prg_datetime'].'>';
	echo '</br>';echo '</br>';
	$count++ ; 
	 }
     ?></td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="13" align="right" nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="13" align="right" nowrap style="border-bottom: 1px solid #7F9DB9;">&nbsp;</td>
          <td nowrap style="border-bottom: 1px solid #7F9DB9;"><span class="style2"><span class="style3">Resolution Information </span></span></td>
          <td nowrap style="border-bottom: 1px solid #7F9DB9;">&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="13" align="right" nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="29" align="right" nowrap >Current Department Responsible </td>
          <td nowrap ><input name="iresponsiblev" type="text" class="style13" id="iresponsiblev" value="<?php echo "$iss_responsible"; ?>" size="50" ></td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="29" align="right" nowrap >Department Responsible</td>
          <td nowrap > <select name="iresponsible" class="style13" id="iresponsible">
            <option value="Select Department">Select Department</option>
            <option value="Administration">Administration</option>
            <option value="Money Shoppe @ Arusha">Money Shoppe @ Arusha</option>
            <option value="Branch Management Unit">Branch Management Unit</option>
            <option value="Centralized Operations">Centralized Operations</option>
            <option value="Corporate Affairs">Corporate Affairs</option>
            <option value="Corporate Banking">Corporate Banking</option>
            <option value="Credit">Credit</option>
            <option value="Finance">Finance</option>
            <option value="Human Resources">Human Resources</option>
            <option value="ICT">ICT</option>
            <option value="Industial Finance Branch">Industial Finance Branch</option>
            <option value="Internal Audit">Internal Audit</option>
            <option value="Money Shoppe @ Kisutu">Money Shoppe @ Kisutu</option>
            <option value="Money Shoppe @ Mwanza">Money Shoppe @ Mwanza</option>
            <option value="Product Delivery">Product Delivery</option>
            <option value="Service Delivery">Service Delivery</option>
            <option value="Trade Finance">Trade Finance</option>
            <option value="Transactional Banking">Transactional Banking</option>
            <option value="Treasury">Treasury</option>
            <option value="Treasury Back Office">Treasury Back Office</option>
            <option value="Money Shoppe @ Uhuru">Money Shoppe @ Uhuru</option>
            <option value="Compliance">Compliance</option>
            <option value="Operation">Operation</option>
            <option value="Communications">Communications</option>
			<option value="Payments">Payments</option>
            <option value="NA">NA</option>
          </select> 
            * 
            <input name="UpdateResponsible" type="submit" class="style13" id="UpdateResponsible" OnClick="show_alert()" value="Update"></td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="87" align="right" nowrap >Root Cause </td>
          <td nowrap ><textarea name="iroot" cols="70" rows="5" class="style13" id="iroot"><?php echo "$iss_root_caused"; ?></textarea></td>
          <td nowrap >*</td>
        </tr>
        <tr class="style6">
          <td height="30" align="right" nowrap >&nbsp;</td>
          <td nowrap ><input name="UpdateCaused" type="submit" class="style13" id="UpdateCaused" OnClick="show_alert()" value="Update Root Cause"></td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="88" align="right" nowrap >Remarks</td>
          <td nowrap ><textarea name="inote" cols="70" rows="5" class="style13" id="inote"><?php echo "$iss_note"; ?></textarea></td>
          <td nowrap >*</td>
        </tr>
        <tr class="style6">
          <td height="25" align="right" nowrap >&nbsp;</td>
          <td nowrap ><input name="UpdateRemarks" type="submit" class="style13" id="UpdateRemarks" OnClick="show_alert()" value="Update Remarks"></td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="13" align="right" nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="13" align="right" nowrap style="border-bottom: 1px solid #7F9DB9;">&nbsp;</td>
          <td nowrap style="border-bottom: 1px solid #7F9DB9;"><span class="style2">Update All </span></td>
          <td nowrap style="border-bottom: 1px solid #7F9DB9;">&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="13" align="right" nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="13" align="right" nowrap >&nbsp;</td>
          <td nowrap ><input name="UpdateAll" type="submit" class="style13" id="UpdateAll" OnClick="show_alert()" value="Update All"></td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="13" align="right" nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
        </tr>
      </table>
      </form>
    </td>
  </tr>
</table>
</body>
</html>
