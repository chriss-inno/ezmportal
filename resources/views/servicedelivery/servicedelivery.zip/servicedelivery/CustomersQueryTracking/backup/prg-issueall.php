<?php
session_start();
$loginUser_id = $_SESSION['SESS_USER_ID'];
require_once('../../../config/auth_content.php');
?> 
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Untitled Document</title>
<style type="text/css">
<!--
.style2 {
	color: #FFFFFF;
	font-weight: bold;
}
.style43 {font-size: 11px; font-family: tahoma; color: #0E3793;}
.style3 {font-size: 11px; font-family: tahoma;}
a:link {
	color: #FFFFFF;
	text-decoration: none;
}
a:visited {
	color: #FFFFFF;
	text-decoration: none;
}
a:hover {
	color: #FF0000;
	text-decoration: none;
}
a:active {
	color: #FFFFFF;
	text-decoration: none;
}
.style4 {font-size: 11px; font-family: tahoma; color: #FFFFFF; }
body {
	background-image: url(../../images/backgrounds/pagebg.png);
}
.style5 {
	font-size: 11px;
	font-weight: bold;
}
.style11 {font-family: tahoma; font-size: 11px; color: #ffffff; }
.style19 {font-size: 11px; font-family: tahoma; color: #FFFFFF; font-weight: bold; }
-->
</style>
</head>

<body>
<table width="100%" border="0" cellpadding="5" cellspacing="0">
  <tr>
    <td></td>
  </tr>
</table>
<table width="100%"  border="0" align="center" cellpadding="0" cellspacing="0" style="border-bottom: 1px solid #7F9DB9; border-left: 1px solid #7F9DB9; border-right: 1px solid #7F9DB9; border-top: 1px solid #7F9DB9; ">
  <tr>
    <td width="95%" height="20" nowrap ><table width="100%" height="20"  border="0" align="center" cellpadding="0" cellspacing="0" style="border-bottom: 1px solid #7F9DB9;">
      <tr >
        <td width="96%" height="19" nowrap bgcolor="#E1204F" ><span class="style2">&nbsp;<span class="style3"> CUSTOMER ISSUE PROGRESS </span></span></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="80" align="center" valign="top" nowrap class="style4">
	
	
	
	  <table width="100%" align="center" cellpadding="0" cellspacing="0" >
        <tr class="style3" >
          <td width="78" nowrap ><div align="center"><span class="style11"><strong><span class="style19">
            <?php
     $con = mysql_connect("localhost","root","");
     if (!$con) {die('Could not connect: ' . mysql_error());}
     mysql_select_db("bmpl_system") or die(mysql_error());
			  
			  
	 $query = mysql_query(" SELECT * FROM sys_user WHERE usr_id = '$loginUser_id' ");  
	 while($row = mysql_fetch_array($query))
     {
	 $deprtmnt = $row['usr_department'];
     }
	 
	 $queryl = mysql_query(" SELECT * FROM sys_user_right WHERE usr_id = '$loginUser_id' and rgt_name = 'CUSTOMERQUERYTRACKINGINPUT' ");  
	 while($row = mysql_fetch_array($queryl))
     {
	 $rgtname = $row['rgt_name'];
     }
	 
	 if ($rgtname != "CUSTOMERQUERYTRACKINGINPUT")
	 
	 {
 include_once 'unuthorized.php';	
	  exit;
	 }?>
          </span></strong></span></div></td>
        </tr>
        <tr class="style3" >
          <td nowrap ><div align="center"></div></td>
        </tr>
        <tr class="style3" >
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style3" >
          <td nowrap ><div align="center">
            <?php
			  mysql_connect("localhost", "root", "") or die(mysql_error());
              mysql_select_db("bmpl_servicedeliveryportal") or die(mysql_error());  
              $query = mysql_query(" SELECT * FROM sd_issue WHERE iss_status <> 'Resolved' ORDER BY iss_code");  
			  //$query = mysql_query(" SELECT * FROM sd_issue ORDER BY iss_code");                                    
              $count = 1;
			  $result = $query;
		      if($result) 
		             {
			if(mysql_num_rows($result) != 0) 
			{
     echo "<table width=95%   border=0 align=center cellpadding=0 cellspacing=0 >
     <tr align=center bgcolor=#E1204F>
     <td width=20  height=25 nowrap style='border-top: 1px solid #7F9DB9; border-right: 1px solid #7F9DB9; border-bottom: 1px solid #7F9DB9; border-left: 1px solid #7F9DB9;'><span class=style2><span class=style3>S. #</td>
     <td width=60  height=25 nowrap style='border-top: 1px solid #7F9DB9; border-right: 1px solid #7F9DB9; border-bottom: 1px solid #7F9DB9;'><span class=style2><span class=style3>ISSUE #</span></td>
     <td width=60  height=25 nowrap style='border-top: 1px solid #7F9DB9; border-right: 1px solid #7F9DB9; border-bottom: 1px solid #7F9DB9;'><span class=style2><span class=style3>CUSTOMER NAME</span></td>
	      <td width=60  height=25 nowrap style='border-top: 1px solid #7F9DB9; border-right: 1px solid #7F9DB9; border-bottom: 1px solid #7F9DB9;'><span class=style2><span class=style3>RECEIVED DATE</span></td>
	 <td width=60  height=25 nowrap style='border-top: 1px solid #7F9DB9; border-right: 1px solid #7F9DB9; border-bottom: 1px solid #7F9DB9;'><span class=style2><span class=style3>PRODUCT TYPE</span></span></td>
     <td width=60  height=25 nowrap style='border-top: 1px solid #7F9DB9; border-right: 1px solid #7F9DB9; border-bottom: 1px solid #7F9DB9;'><span class=style2><span class=style3>RECEIVED BY</span></span></td>
	 <td width=60  height=25 nowrap style='border-top: 1px solid #7F9DB9; border-right: 1px solid #7F9DB9; border-bottom: 1px solid #7F9DB9;'><span class=style2><span class=style3>MODE OF RECEIPTS</span></span></td>
	 	 <td width=60  height=25 nowrap style='border-top: 1px solid #7F9DB9; border-right: 1px solid #7F9DB9; border-bottom: 1px solid #7F9DB9;'><span class=style2><span class=style3>DEPARTMENT RESPONSIBLE</span></span></td>
	 <td width=60  height=25 nowrap style='border-top: 1px solid #7F9DB9; border-right: 1px solid #7F9DB9; border-bottom: 1px solid #7F9DB9;'><span class=style2><span class=style3>STATUS </span></span></td>

     </tr>";


   while($row = mysql_fetch_array($query))
    { 
    echo "<tr align=left class=style4>";
	echo "<td  height=25 nowrap class=style1 style='border-bottom: 1px solid #7F9DB9; border-right: 1px solid #7F9DB9; border-left: 1px solid #7F9DB9;'><span class=style4> &nbsp;&nbsp; $count </span></td>";
	$a=$row['iss_reference_number'];
	echo "<td  height=25 nowrap class=style1 style='border-bottom: 1px solid #7F9DB9; border-right: 1px solid #7F9DB9'><span class=style4><a href='prg-issueprogress.php?iss_reference_number=".$a."'>&nbsp;&nbsp;&nbsp;".$a."</a></span></td>"; 
    echo '<td  height=25 nowrap class=style1 style="border-bottom: 1px solid #7F9DB9; border-right: 1px solid #7F9DB9"><span class=style4>&nbsp;&nbsp;&nbsp;'. $row["iss_customer_name"].'</span></td>';
	    echo '<td  height=25 nowrap class=style1 style="border-bottom: 1px solid #7F9DB9; border-right: 1px solid #7F9DB9"><span class=style4>&nbsp;&nbsp;&nbsp;'. $row["iss_reported_date"].'</span></td>';
	echo '<td  height=25 nowrap class=style1 style="border-bottom: 1px solid #7F9DB9; border-right: 1px solid #7F9DB9"><span class=style4>&nbsp;&nbsp;&nbsp;'. $row["iss_product_type"].'</span></td>';
	echo '<td  height=25 nowrap class=style1 style="border-bottom: 1px solid #7F9DB9; border-right: 1px solid #7F9DB9"><span class=style4>&nbsp;&nbsp;&nbsp;'. $row["iss_received_by"].'</span></td>';
	echo '<td  height=25 nowrap class=style1 style="border-bottom: 1px solid #7F9DB9; border-right: 1px solid #7F9DB9"><span class=style4>&nbsp;&nbsp;&nbsp;'. $row["iss_received_mode"].'</span></td>';	
	
		echo '<td  height=25 nowrap class=style1 style="border-bottom: 1px solid #7F9DB9; border-right: 1px solid #7F9DB9"><span class=style4>&nbsp;&nbsp;&nbsp;'. $row["iss_responsible"].'</span></td>';
	echo '<td  height=25 nowrap class=style1 style="border-bottom: 1px solid #7F9DB9; border-right: 1px solid #7F9DB9"><span class=style4>&nbsp;&nbsp;&nbsp;'. $row["iss_status"].'</span></td>';    

	echo "</tr>"; 


	$count ++; 
	 }
	 echo "</table>";

	 }else
	 {
	 echo "<span class=style2><span class=style3>No customer issue  to display</span></span>";
	 }}
     ?>
          </div></td>
        </tr>
        <tr class="style3" >
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style3" >
          <td nowrap ><div align="center">
            <a href="index.php">
            <input type=button onClick="location.href='../index-content.php'" class='style43' value='Exit'>
          </a></div></td>
        </tr>
        <tr class="style3" >
          <td nowrap >&nbsp;</td>
        </tr>
      </table>
  </tr>
</table>
<p>&nbsp;</p>
<p>&nbsp;</p>
</body>
</html>
