<?php
session_start();
$loginUser_id = $_SESSION['SESS_USER_ID'];
require_once('../../../config/auth_content.php');
?> 
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<script type="text/javascript"> 
 function show_alert() { 
 var msg = "Submited Successful, press OK and wait for the page to finish loading. Do not press LOG again!";
 alert(msg); 
 }
 </script>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Untitled Document</title>
<style type="text/css">
<!--
.style2 {
	color: #ffffff;
	font-weight: bold;
}
.style3 {font-size: 11px; font-family: tahoma;}
.style6 {font-size: 11px}
.style11 {font-family: tahoma; font-size: 11px; color: #ffffff; }
.style13 {font-family: tahoma; font-size: 11px; color: #0E3793; }
.style12 {font-family: tahoma}
a:link {
	text-decoration: none;
}
a:visited {
	text-decoration: none;
}
a:hover {
	text-decoration: none;
}
a:active {
	text-decoration: none;
}
.style14 {color: #0E3793}
.style16 {font-family: tahoma; font-size: 11px; color: #0E3793; font-weight: bold; }
body {
	background-image: url(../../images/backgrounds/pagebg.png);
}
.style18 {font-size: 11px; font-family: tahoma; color: #FFFFFF; }
.style19 {font-size: 11px; font-family: tahoma; color: #FFFFFF; font-weight: bold; }
.style20 {	color: #0E3793;
	font-weight: bold;
}
-->
</style>
	
	<script type="text/javascript" src="../../support/js/jquery.min.js"></script>
	<script type="text/javascript" src="../../support/js/control.js"></script>
</head>
<script type="text/javascript">
// Popup window code
function newPopup(url) {
	popupWindow = window.open(
		url,'popUpWindow','height=300,width=500,left=10,top=10,resizable=yes,scrollbars=yes,toolbar=yes,menubar=no,location=no,directories=no,status=yes,dependent=yes,menubar=no,resizable=no,scrollbars=yes')
		                   
}
</script>
<body>
<table width="100%" border="0" cellpadding="5" cellspacing="0">
  <tr>
    <td></td>
  </tr>
</table>
<table width="100%"  border="0" align="center" cellpadding="0" cellspacing="0" style="border-left: 1px solid #7F9DB9; border-right: 1px solid #7F9DB9; border-top: 1px solid #7F9DB9; border-bottom: 1px solid #7F9DB9;">
  <tr>
    <td width="95%" height="20" nowrap ><table width="100%" height="20"  border="0" align="center" cellpadding="0" cellspacing="0" style="border-bottom: 1px solid #7F9DB9;">
        <tr >
          <td width="96%" height="19" nowrap bgcolor="#E1204F" b><span class="style2"><span class="style20">&nbsp;<span class="style18">CUSTOMER ISSUE TRACKING </span></span></span></td>
        </tr>
    </table></td>
  </tr>
  <tr>
    <td height="422" valign="top" nowrap>
	<form action="" method="post" name="ReturnDepartmentSelect" id="ReturnDepartmentSelect">
	  <div align="center">
	    <p class="style11"><strong>
	         
			 
		    <span class="style19">
		    <strong><strong>
			 <?php
     $con = mysql_connect("localhost","root","");
     if (!$con) {die('Could not connect: ' . mysql_error());}
     mysql_select_db("bmpl_system") or die(mysql_error());
			  
			  
	 $query = mysql_query(" SELECT * FROM sys_user WHERE usr_id = '$loginUser_id' ");  
	 while($row = mysql_fetch_array($query))
     {
	 $deprtmnt = $row['usr_department'];
     }
	 
	 $queryl = mysql_query(" SELECT * FROM sys_user_right WHERE usr_id = '$loginUser_id' and rgt_name = 'CUSTOMERQUERYTRACKINGVIEW' ");  
	 while($row = mysql_fetch_array($queryl))
     {
	 $rgtname = $row['rgt_name'];
     }
	 
	 if ($rgtname != "CUSTOMERQUERYTRACKINGVIEW")
	 
	 {
 include_once 'unuthorized.php';	
	  exit;
	 }?>
	      </strong></strong>	      </span></strong></p>
	    </div>
	</form>
	<form action="rec-pageexe.php" method="post" enctype="multipart/form-data" >
	
      <table width="80%" height="608"  border="0" align="center" cellpadding="0" cellspacing="0" class="style11" >
        <tr class="style6">
          <td height="13" align="right" nowrap >&nbsp;</td>
          <td nowrap ><div align="left"><span class="style16">              

          </span> <span class="style16"> </span></div></td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="14" nowrap style="border-bottom: 1px solid #7F9DB9;">&nbsp;</td>
          <td nowrap style="border-bottom: 1px solid #7F9DB9;"><span class="style2"><span class="style3">Basic Details </span></span></td>
          <td nowrap style="border-bottom: 1px solid #7F9DB9;">&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="13" align="right" nowrap >&nbsp;</td>
          <td nowrap >
		  
		  
		  
		<?php
		   $iss_reference_number = $_GET['iss_reference_number'];
			  
               mysql_connect("localhost", "root", "") or die(mysql_error());
               mysql_select_db("bmpl_servicedeliveryportal") or die(mysql_error());
               $result = mysql_query("SELECT * FROM sd_issue WHERE iss_reference_number = '$iss_reference_number' ") or die(mysql_error());  
               while($row = mysql_fetch_array( $result )) 
               {   
			   
   $iss_reference_number   = $row['iss_reference_number'];
   $iss_reported_date      = $row['iss_reported_date'];
   $iss_reported_time      = $row['iss_reported_time'];
   $iss_inputed_by         = $row['iss_inputed_by'];
   $iss_customer_name      = $row['iss_customer_name'];
   $iss_contact_person     = $row['iss_contact_person'];
   $iss_customer_number    = $row['iss_customer_number'];
   $iss_customer_email     = $row['iss_customer_email'];
   $iss_product_type       = $row['iss_product_type'];
   $iss_received_by        = $row['iss_received_by'];
   $iss_received_mode      = $row['iss_received_mode'];
   $iss_priority           = $row['iss_priority'];
   $iss_status             = $row['iss_status'];
   $iss_issue_description  = $row['iss_issue_description'];
   $iss_root_caused        = $row['iss_root_caused'];
   $iss_responsible        = $row['iss_responsible'];
   $iss_note               = $row['iss_note'];
   $iss_viable_action      = $row['iss_viable_action'];
   
   $iss_resolution_date      = $row['iss_resolution_date'];
   $iss_resolution_time      = $row['iss_resolution_time'];
			
			
			   
               } 
		  ?>
				 
				
				 
          </td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td width="28%" height="23" align="right" nowrap >Issue Ref.  # </td>
          <td width="31%" nowrap ><table width="100%"  border="0" align="center" cellpadding="0" cellspacing="0" >
              <tr>
                <td width="29%" nowrap class="style11" >                    <input name="inumbern" type="text" class="style13" id="inumbern" value="<?php echo "$iss_reference_number"; ?>"></td>
                <td width="39%" nowrap class="style11" >&nbsp;</td>
                <td width="32%" align="center" nowrap class="style11"  ><div align="right">Reported Date</div></td>
              </tr>
          </table></td>
          <td width="41%" nowrap ><input name="idaten" type="text" class="style13" id="idaten" value="<?php echo "$iss_reported_date"; ?>">
            </td>
        </tr>
        <tr class="style6">
          <td height="28" align="right" nowrap >Inputed by </td>
          <td nowrap ><table width="100%"  border="0" align="center" cellpadding="0" cellspacing="0" >
            <tr>
              <td width="29%" nowrap class="style11" ><input name="ireportedbyn" type="text" class="style13" id="ireportedbyn" value="<?php echo "$iss_inputed_by"; ?>"></td>
              <td width="39%" nowrap class="style11" >&nbsp;</td>
              <td width="32%" align="center" nowrap class="style11" ><div align="right">Reported Time </div></td>
            </tr>
          </table></td>
          <td nowrap ><input name="itime" type="text" class="style13" id="itime" value="<?php echo "$iss_reported_time"; ?>"></td>
        </tr>
        <tr class="style6">
          <td height="13" align="right" nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="13" align="right" nowrap style="border-bottom: 1px solid #7F9DB9;">&nbsp;</td>
          <td nowrap style="border-bottom: 1px solid #7F9DB9;"><span class="style2"><span class="style3">Cusomer Details </span></span></td>
          <td nowrap style="border-bottom: 1px solid #7F9DB9;">&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="13" align="right" nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="23" align="right" nowrap >Customer name</td>
          <td nowrap ><input name="icname" type="text" class="style13" id="icname" value="<?php echo "$iss_customer_name"; ?>" size="50" ></td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="23" align="right" nowrap >Contact person </td>
          <td nowrap >            <table width="100%"  border="0" align="center" cellpadding="0" cellspacing="0" >
              <tr>
                <td width="29%" nowrap class="style11" ><input name="icname" type="text" class="style13" id="icname" value="<?php echo "$iss_contact_person"; ?>" size="50" ></td>
                <td width="39%" nowrap class="style11" >&nbsp;</td>
                <td width="32%" align="center" nowrap class="style11" ><div align="right"></div></td>
              </tr>
            </table></td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="13" align="right" nowrap >&nbsp;</td>
          <td nowrap ><table width="100%"  border="0" align="center" cellpadding="0" cellspacing="0" >
              <tr>
                <td width="29%" nowrap class="style11" >&nbsp;</td>
                <td width="39%" nowrap class="style11" >&nbsp;</td>
                <td width="32%" align="center" nowrap class="style11" ><div align="right"></div></td>
              </tr>
          </table></td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="14" align="right" nowrap style="border-bottom: 1px solid #7F9DB9;" >&nbsp;</td>
          <td nowrap style="border-bottom: 1px solid #7F9DB9;"><span class="style2"><span class="style3">Issue Details</span></span></td>
          <td nowrap style="border-bottom: 1px solid #7F9DB9;">&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="13" align="right" nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="27" align="right" nowrap >Product Type </td>
          <td nowrap ><table width="100%"  border="0" align="center" cellpadding="0" cellspacing="0" >
            <tr>
              <td width="29%" nowrap class="style11" ><input name="iproduct" type="text" class="style13" id="iproduct" value="<?php echo "$iss_product_type "; ?>" ></td>
              <td width="39%" nowrap class="style11" >&nbsp;</td>
              <td width="32%" align="center" nowrap class="style11" ><div align="right">Received by </div></td>
            </tr>
          </table></td>
          <td nowrap ><input name="ireceivedby" type="text" class="style13" id="ireceivedby" value="<?php echo "$iss_received_by"; ?>"></td>
        </tr>
        <tr class="style6">
          <td height="27" align="right" nowrap >Mode of Receipt </td>
          <td nowrap >            <table width="100%"  border="0" align="center" cellpadding="0" cellspacing="0" >
              <tr>
                <td width="29%" nowrap class="style11" ><input name="imode" type="text" class="style13" id="imode" value="<?php echo "$iss_received_mode"; ?>" ></td>
                <td width="39%" nowrap class="style11" >&nbsp;</td>
                <td width="32%" align="center" nowrap class="style11" ><div align="right"></div></td>
              </tr>
            </table></td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="28" align="right" nowrap >Status</td>
          <td nowrap ><table width="100%"  border="0" align="center" cellpadding="0" cellspacing="0" >
              <tr>
                <td width="29%" nowrap class="style11" ><input name="ictell" type="text" class="style13" id="ictell" value="<?php echo "$iss_status"; ?>" ></td>
                <td width="39%" nowrap class="style11" >&nbsp;</td>
                <td width="32%" align="center" nowrap class="style11" ><div align="right"></div></td>
              </tr>
          </table></td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="100" align="right" nowrap style="border-right: 1px solid #7F9DB9;"><p>Issue Progress </p></td>
          <td nowrap ><?php
               mysql_connect("localhost", "root", "") or die(mysql_error());
               mysql_select_db("bmpl_servicedeliveryportal") or die(mysql_error());
               $result = mysql_query("SELECT * FROM sd_progress WHERE iss_number = '$iss_reference_number' ") or die(mysql_error());                 
    while($row = mysql_fetch_array($result))
    { 
	
    echo '&nbsp;&nbsp;<span class=style13><textarea name=textarea cols=70 rows=5 class=style13>'.''.$row["prg_description"].'</textarea></span></br>';
	echo '&nbsp;&nbsp;<span class=style13><textarea name=textarea cols=30 rows=1 class=style13>'.''.$row["prg_status"].'</textarea></span></br>';
	echo '&nbsp;&nbsp;<span class=style13><textarea name=textarea cols=30 rows=1 class=style13>'.''.$row["prg_inputed_by"].'</textarea></span>';
	echo '&nbsp;&nbsp;<input name=textfield type=text class=style13 value='.''.$row['prg_date'].'>';
	echo '</br>';echo '</br>';
	$count++ ; 
	 }
     ?></td>
          <td nowrap ><span class="style12"></span></td>
        </tr>
        <tr class="style6">
          <td height="13" align="right" nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="13" align="right" nowrap >Issue Resoved time &nbsp;</td>
          <td nowrap >            <table width="100%"  border="0" align="center" cellpadding="0" cellspacing="0" >
              <tr>
                <td width="29%" nowrap class="style11" ><input name="idaten" type="text" class="style13" id="idaten" value="<?php echo "$iss_resolution_time"; ?>"></td>
                <td width="39%" nowrap class="style11" >&nbsp;</td>
                <td width="32%" align="center" nowrap class="style11" ><div align="right">Issue Resoved date &nbsp;</div></td>
              </tr>
            </table></td>
          <td nowrap ><input name="itime" type="text" class="style13" id="itime" value="<?php echo "$iss_resolution_date"; ?>"></td>
        </tr>
        <tr class="style6">
          <td height="13" align="right" nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="13" align="right" nowrap style="border-bottom: 1px solid #7F9DB9;">&nbsp;</td>
          <td nowrap style="border-bottom: 1px solid #7F9DB9;"><span class="style2"><span class="style3">Resolution Information </span></span></td>
          <td nowrap style="border-bottom: 1px solid #7F9DB9;">&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="13" align="right" nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="29" align="right" nowrap >Department Responsible</td>
          <td nowrap ><input name="iresponsible" type="text" class="style13" id="iresponsible" value="<?php echo "$iss_responsible"; ?>" size="50" ></td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="67" align="right" nowrap >Root Cause </td>
          <td nowrap ><textarea name="iroot" cols="70" rows="3" class="style13" id="iroot"><?php echo "$iss_root_caused"; ?></textarea></td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="23" align="right" nowrap >Add Note </td>
          <td nowrap ><textarea name="inote" cols="70" rows="3" class="style13" id="inote"><?php echo "$iss_note"; ?></textarea></td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="13" align="right" nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="13" align="right" nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
        </tr>
      </table>
      </form>
    </td>
  </tr>
</table>
</body>
</html>
