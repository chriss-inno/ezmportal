<?php
session_start();
$loginUser_id = $_SESSION['SESS_USER_ID'];
require_once('../../../config/auth_content.php');
?> 
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<script type="text/javascript"> 
 function show_alert() { 
 var msg = "Submited Successful, press OK and wait for the page to finish loading. Do not press LOG again!";
 alert(msg); 
 }
 </script>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Untitled Document</title>
<style type="text/css">
<!--
.style2 {
	color: #ffffff;
	font-weight: bold;
}
.style3 {font-size: 11px; font-family: tahoma;}
.style6 {font-size: 11px}
.style11 {font-family: tahoma; font-size: 11px; color: #ffffff; }
.style13 {font-family: tahoma; font-size: 11px; color: #0E3793; }
.style12 {font-family: tahoma}
a:link {
	text-decoration: none;
}
a:visited {
	text-decoration: none;
}
a:hover {
	text-decoration: none;
}
a:active {
	text-decoration: none;
}
.style14 {color: #0E3793}
.style16 {font-family: tahoma; font-size: 11px; color: #0E3793; font-weight: bold; }
body {
	background-image: url(../../images/backgrounds/pagebg.png);
}
.style18 {font-size: 11px; font-family: tahoma; color: #FFFFFF; }
.style19 {font-size: 11px; font-family: tahoma; color: #FFFFFF; font-weight: bold; }
.style20 {	color: #0E3793;
	font-weight: bold;
}
-->
</style>
	
	<script type="text/javascript" src="../../support/js/jquery.min.js"></script>
	<script type="text/javascript" src="../../support/js/control.js"></script>
</head>
<script type="text/javascript">
// Popup window code
function newPopup(url) {
	popupWindow = window.open(
		url,'popUpWindow','height=300,width=500,left=10,top=10,resizable=yes,scrollbars=yes,toolbar=yes,menubar=no,location=no,directories=no,status=yes,dependent=yes,menubar=no,resizable=no,scrollbars=yes')
		                   
}
</script>
<body>
<table width="100%" border="0" cellpadding="5" cellspacing="0">
  <tr>
    <td></td>
  </tr>
</table>
<table width="100%"  border="0" align="center" cellpadding="0" cellspacing="0" style="border-left: 1px solid #7F9DB9; border-right: 1px solid #7F9DB9; border-top: 1px solid #7F9DB9; border-bottom: 1px solid #7F9DB9;">
  <tr>
    <td width="95%" height="20" nowrap ><table width="100%" height="20"  border="0" align="center" cellpadding="0" cellspacing="0" style="border-bottom: 1px solid #7F9DB9;">
        <tr >
          <td width="96%" height="19" nowrap bgcolor="#E1204F" b><span class="style2"><span class="style20">&nbsp;<span class="style18">CUSTOMER ISSUE TRACKING </span></span></span></td>
        </tr>
    </table></td>
  </tr>
  <tr>
    <td height="422" valign="top" nowrap>
	<form action="" method="post" name="ReturnDepartmentSelect" id="ReturnDepartmentSelect">
	  <div align="center">
	    <p class="style11"><strong>
	         
			 
		    <span class="style19">
			 <?php
     $con = mysql_connect("localhost","root","");
     if (!$con) {die('Could not connect: ' . mysql_error());}
     mysql_select_db("bmpl_system") or die(mysql_error());
			  
			  
	 $query = mysql_query(" SELECT * FROM sys_user WHERE usr_id = '$loginUser_id' ");  
	 while($row = mysql_fetch_array($query))
     {
	 $deprtmnt = $row['usr_department'];
     }
	 
	 $queryl = mysql_query(" SELECT * FROM sys_user_right WHERE usr_id = '$loginUser_id' and rgt_name = 'CUSTOMERQUERYTRACKINGINPUT' ");  
	 while($row = mysql_fetch_array($queryl))
     {
	 $rgtname = $row['rgt_name'];
     }
	 
	 if ($rgtname != "CUSTOMERQUERYTRACKINGINPUT")
	 
	 {
 include_once 'unuthorized.php';	
	  exit;
	 }?>
	      </span></strong></p>
	    </div>
	</form>
	<form action="rec-pageexe.php" method="post" enctype="multipart/form-data" >
	
      <table width="80%" height="494"  border="0" align="center" cellpadding="0" cellspacing="0" class="style11" >
        <tr class="style6">
          <td height="13" align="right" nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="13" align="right" nowrap >&nbsp;</td>
          <td nowrap ><div align="center"><span class="style16">              
  
        </span> <span class="style16">
        <?php    
  
        mysql_connect("localhost", "root", "") or die(mysql_error());
        mysql_select_db("bmpl_system") or die(mysql_error());
        $result = mysql_query("SELECT * FROM sys_user WHERE usr_id = '$loginUser_id' ") or die(mysql_error());  
        while($row = mysql_fetch_array( $result )) 
        {  
        $fullname       = $row['usr_full_name'];
        $userdepartment = $row['usr_department'];
        $userbranch     = $row['usr_branch'];
        } 
        ?>
        <span class="style2"><span class="style3">        </span></span> </span></div></td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="14" nowrap style="border-bottom: 1px solid #7F9DB9;">&nbsp;</td>
          <td nowrap style="border-bottom: 1px solid #7F9DB9;"><span class="style2"><span class="style3">Basic Details </span></span></td>
          <td nowrap style="border-bottom: 1px solid #7F9DB9;">&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="13" align="right" nowrap >&nbsp;</td>
          <td nowrap >&nbsp;		 </td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td width="28%" height="23" align="right" nowrap >Issue Ref.  # </td>
          <td width="31%" nowrap ><table width="100%"  border="0" align="center" cellpadding="0" cellspacing="0" >
              <tr>
                <td width="29%" nowrap class="style11" ><?php
               
               mysql_connect("localhost", "root", "") or die(mysql_error());
               mysql_select_db("bmpl_servicedeliveryportal") or die(mysql_error());
               $result = mysql_query("SELECT iss_code FROM sd_issue order by iss_code") or die(mysql_error());  
               while($row = mysql_fetch_array( $result )) 
               {  
               $name = $row['iss_code'];
               } 
               $number = ($name + 1);
              ?>
                    <input name="inumbern" type="text" class="style13" id="inumbern" value="CIN<?php echo "$number"; ?>"></td>
                <td width="39%" nowrap class="style11" ><input name="inumber" type="hidden" class="style3" id="inumber" value="CIN<?php echo "$number"; ?>"></td>
                <td width="32%" align="center" nowrap class="style11"  ><div align="right">Reporting Date</div></td>
              </tr>
          </table></td>
          <td width="41%" nowrap ><input name="idaten" type="text" class="style13" id="idaten" value="<?php echo date("Y-m-d", time()); ?>">
            <input name="idate" type="hidden"  class="style11" id="idate" value="<?php echo date("Y-m-d", time()); ?>"></td>
        </tr>
        <tr class="style6">
          <td height="28" align="right" nowrap >Inputed by </td>
          <td nowrap ><table width="100%"  border="0" align="center" cellpadding="0" cellspacing="0" >
            <tr>
              <td width="29%" nowrap class="style11" ><input name="ireportedbyn" type="text" class="style13" id="ireportedbyn" value="<?php echo "$fullname"; ?>"></td>
              <td width="39%" nowrap class="style11" ><input name="ireportedby" type="hidden" class="style11" id="ireportedby" value="<?php echo "$fullname"; ?>"></td>
              <td width="32%" align="center" nowrap class="style11" ><div align="right">Reporting Time</div></td>
            </tr>
          </table></td>
          <td nowrap ><input name="itimen" type="text" class="style13" id="itimen" value="<?php echo date("H:i:s", time()); ?>">
            <input name="itime" type="hidden"  class="style11" id="itime" value="<?php echo date("H:i:s", time()); ?>"></td>
        </tr>
        <tr class="style6">
          <td height="13" align="right" nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="13" align="right" nowrap style="border-bottom: 1px solid #7F9DB9;">&nbsp;</td>
          <td nowrap style="border-bottom: 1px solid #7F9DB9;"><span class="style2"><span class="style3">Customer Details </span></span></td>
          <td nowrap style="border-bottom: 1px solid #7F9DB9;">&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="13" align="right" nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="23" align="right" nowrap >Company Name </td>
          <td nowrap ><input name="icname" type="text" class="style13" id="icname" style="text-transform:uppercase;" size="50" ></td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="23" align="right" nowrap >Contact Person </td>
          <td nowrap >            <table width="100%"  border="0" align="center" cellpadding="0" cellspacing="0" >
              <tr>
                <td width="29%" nowrap class="style11" >                  <input name="icmname" type="text" class="style13" id="icmname" style="text-transform:uppercase;" value="NA" size="50" ></td>
                <td width="39%" nowrap class="style11" >&nbsp;</td>
                <td width="32%" align="center" nowrap class="style11" ><div align="right"></div></td>
              </tr>
            </table></td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="13" align="right" nowrap >&nbsp;</td>
          <td nowrap ><table width="100%"  border="0" align="center" cellpadding="0" cellspacing="0" >
              <tr>
                <td width="29%" nowrap class="style11" >&nbsp;</td>
                <td width="39%" nowrap class="style11" >&nbsp;</td>
                <td width="32%" align="center" nowrap class="style11" ><div align="right"></div></td>
              </tr>
          </table></td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="14" align="right" nowrap style="border-bottom: 1px solid #7F9DB9;" >&nbsp;</td>
          <td nowrap style="border-bottom: 1px solid #7F9DB9;"><span class="style2"><span class="style3">Issue Details</span></span></td>
          <td nowrap style="border-bottom: 1px solid #7F9DB9;">&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="13" align="right" nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="27" align="right" nowrap >Product Type </td>
          <td nowrap ><table width="100%"  border="0" align="center" cellpadding="0" cellspacing="0" >
            <tr>
              <td width="29%" nowrap class="style11" ><select name="iproduct" class="style13" id="iproduct">
                <option value="Select Product Type">Select Product Type</option>
                <option value="TT">TT</option>
                <option value="TISS">TISS</option>
                <option value="CCE">CCE</option>
                <option value="CDR">CDR</option>
                <option value="CIT">CIT</option>
                <option value="EFT">EFT</option>
				<option value="Cash">Cash</option>
				<option value="Forex">Forex</option>
				<option value="Cheque">Cheque</option>
				<option value="Account">Account</option>
				<option value="Statement">Statement</option>
				<option value="Account Balance">Account Balance</option>
				<option value="Inward TT">Inward TT</option>
				<option value="Inward TISS">Inward TISS</option>
				<option value="Complain">Complain</option>
				<option value="Money Wireless">Money Wireless</option>
				<option value="Money Mail">Money Mail</option>
				<option value="Credit">Credit</option>
				<option value="Trade Finance">Trade Finance</option>
				<option value="Money Msafiri">Money Msafiri</option>
                            </select></td>
              <td width="39%" nowrap class="style11" >&nbsp;</td>
              <td width="32%" align="center" nowrap class="style11" ><div align="right">Received by </div></td>
            </tr>
          </table></td>
          <td nowrap >            <select name="ireceivedby" class="style13" id="ireceivedby">
              <option value="Select Received by">Select Received by</option>
              <option value="Sanya Abdul">Sanya Abdul</option>
<option value="Grace Nguma">Grace Nguma</option>
<option value="Nelshah Haji">Nelshah Haji</option>
<option value="Hussein Manji">Hussein Manji</option>
<option value="Paul Beda">Paul Beda</option>
<option value="Godfrey Utouh">Godfrey Utouh</option>
<option value="HTB">HTB</option>
<option value="HCB">HCB</option>
<option value="Abel Lasway">Abel Lasway</option>
<option value="Majid Mohamed">Majid Mohamed</option>
<option value="Nadeem Mohamed">Nadeem Mohamed</option>
<option value="Pooja Pandya">Pooja Pandya</option>
<option value="Agnes Mlolole">Agnes Mlolole</option>
<option value="Schola Mrina">Schola Mrina</option>
<option value="Zahra Kermali">Zahra Kermali</option>
<option value="Kaisy Mwakajegela">Kaisy Mwakajegela</option>
<option value="Service Delivery">Service Delivery</option>
<option value="Uhuru HCC">Uhuru HCC</option>
<option value="Kisutu HCC">Kisutu HCC</option>
<option value="IFB HCC">IFB HCC</option>
<option value="Arusha HCC">Arusha HCC</option>
<option value="Mwanza HCC">Mwanza HCC</option>
<option value="Abel Lasway">Abel Lasway</option>
<option value="Branch Manager(IFB)">Branch Manager(IFB)</option>
<option value="Branch Manager(Kisutu)">Branch Manager(Kisutu)</option>
<option value="Branch Manager(Uhuru)">Branch Manager(Uhuru)</option>
<option value="Branch Manager(Arusha)">Branch Manager(Arusha)</option>
<option value="Branch Manager(Mwanza)">Branch Manager(Mwanza)</option>
<option value="Alkarim Somji">Alkarim Somji</option>
<option value="Betty Kwoko">Betty Kwoko</option>
<option value="Anne Nehemia">Anne Nehemia</option>
<option value="Waseem Arain">Waseem Arain</option>
<option value="Jacqueline Woiso">Jacqueline Woiso</option>
<option value="Asif Ismail">Asif Ismail</option> 
<option value="Christina Daudi">Christina Daudi</option>

   </select></td>
        </tr>
        <tr class="style6">
          <td height="27" align="right" nowrap >Product Details </td>
          <td nowrap ><table width="100%"  border="0" align="center" cellpadding="0" cellspacing="0" >
            <tr>
              <td width="29%" nowrap class="style11" ><select name="iproductdetails" class="style13" id="iproductdetails">
                  <option value="Select Product Details">Select Product Details</option>
                  <option value="Wrong Cr/Dr">Wrong Cr/Dr</option>
                  <option value="Wrong Charges">Wrong Charges</option>
                  <option value="Not Processed">Not Processed</option>
                  <option value="Others">Others</option>
              </select></td>
              <td width="39%" nowrap class="style11" >&nbsp;</td>
              <td width="32%" align="center" nowrap class="style11" ><div align="right"></div></td>
            </tr>
          </table></td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="27" align="right" nowrap >Mode of Receipt </td>
          <td nowrap >            <table width="100%"  border="0" align="center" cellpadding="0" cellspacing="0" >
              <tr>
                <td width="29%" nowrap class="style11" ><select name="imode" class="style13" id="imode">
                  <option value="Select Mode of Receipt">Select Mode of Receipt</option>
                  <option value="Telephone">Telephone</option>
                  <option value="Mail">Mail</option>
                </select></td>
                <td width="39%" nowrap class="style11" >&nbsp;</td>
                <td width="32%" align="center" nowrap class="style11" ><div align="right">Status</div></td>
              </tr>
            </table></td>
          <td nowrap ><select name="istatus" class="style13" id="istatus">
            <option value="Select Status">Select Status</option>
            <option value="Pending awaiting resolution">Pending awaiting resolution</option>
           <?PHP // <option value="Pending awaiting clients confirmation">Pending awaiting clients confirmation</option> ?>
            <option value="Resolved">Resolved</option>
          </select></td>
        </tr>
        <tr class="style6">
          <td height="90" align="right" nowrap ><p>Issue Description</p></td>
          <td nowrap ><textarea name="idescription" cols="70" rows="5" class="style13" id="idescription"></textarea></td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="13" align="right" nowrap >Department Responsible</td>
          <td nowrap ><select name="iresponsible" class="style13" id="iresponsible">
            <option value="Select Department">Select Department</option>
            <option value="Administration">Administration</option>
            <option value="Money Shoppe @ Arusha">Money Shoppe @ Arusha</option>
            <option value="Branch Management Unit">Branch Management Unit</option>
            <option value="Centralized Operations">Centralized Operations</option>
            <option value="Corporate Affairs">Corporate Affairs</option>
            <option value="Corporate Banking">Corporate Banking</option>
            <option value="Credit">Credit</option>
            <option value="Finance">Finance</option>
            <option value="Human Resources">Human Resources</option>
            <option value="ICT">ICT</option>
            <option value="Industial Finance Branch">Industial Finance Branch</option>
            <option value="Internal Audit">Internal Audit</option>
            <option value="Money Shoppe @ Kisutu">Money Shoppe @ Kisutu</option>
            <option value="Money Shoppe @ Mwanza">Money Shoppe @ Mwanza</option>
            <option value="Product Delivery">Product Delivery</option>
            <option value="Service Delivery">Service Delivery</option>
            <option value="Trade Finance">Trade Finance</option>
            <option value="Transactional Banking">Transactional Banking</option>
            <option value="Treasury">Treasury</option>
            <option value="Treasury Back Office">Treasury Back Office</option>
            <option value="Money Shoppe @ Uhuru">Money Shoppe @ Uhuru</option>
            <option value="Compliance">Compliance</option>
            <option value="Operation">Operation</option>
            <option value="Communications">Communications</option>
			<option value="Payments">Payments</option>
			 <option value="NA">NA</option>
          </select></td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="13" align="right" nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="13" align="right" nowrap style="border-bottom: 1px solid #7F9DB9;">&nbsp;</td>
          <td nowrap style="border-bottom: 1px solid #7F9DB9;"><span class="style2"><span class="style3">Action </span></span></td>
          <td nowrap style="border-bottom: 1px solid #7F9DB9;">&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="13" align="right" nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="21" align="right" nowrap >&nbsp;</td>
          <td nowrap >
              <div align="left">
                <input name="Record" type="Submit" class="style13" id="Record" value="Record" OnClick="show_alert()">
                <input name="Reset Form" type="reset" class="style13" id="Submit" value="Reset Form">
                <a href="index.php"><input name="Exit" type="button" class="style13" id="Submit" value="Exit"></a>
              </div></td><td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="21" align="right" nowrap >&nbsp;</td>
          <td nowrap ><div align="center">
          </div></td>
          <td nowrap >&nbsp;</td>
        </tr>
      </table>
      </form>
    </td>
  </tr>
</table>
</body>
</html>
