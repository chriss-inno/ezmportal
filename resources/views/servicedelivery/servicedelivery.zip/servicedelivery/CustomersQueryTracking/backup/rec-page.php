<?php
session_start();
$loginUser_id = $_SESSION['SESS_USER_ID'];
require_once('../../../config/auth_content.php');
?> 
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<script type="text/javascript"> 
 function show_alert() { 
 var msg = "Submited Successful, press OK and wait for the page to finish loading. Do not press LOG again!";
 alert(msg); 
 }
 </script>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Untitled Document</title>
<style type="text/css">
<!--
.style2 {
	color: #ffffff;
	font-weight: bold;
}
.style3 {font-size: 11px; font-family: tahoma;}
.style6 {font-size: 11px}
.style11 {font-family: tahoma; font-size: 11px; color: #ffffff; }
.style13 {font-family: tahoma; font-size: 11px; color: #0E3793; }
.style12 {font-family: tahoma}
a:link {
	text-decoration: none;
}
a:visited {
	text-decoration: none;
}
a:hover {
	text-decoration: none;
}
a:active {
	text-decoration: none;
}
.style14 {color: #0E3793}
.style16 {font-family: tahoma; font-size: 11px; color: #0E3793; font-weight: bold; }
body {
	background-image: url(../../images/backgrounds/pagebg.png);
}
.style18 {font-size: 11px; font-family: tahoma; color: #FFFFFF; }
.style19 {font-size: 11px; font-family: tahoma; color: #FFFFFF; font-weight: bold; }
.style20 {	color: #0E3793;
	font-weight: bold;
}
-->
</style>
	
	<script type="text/javascript" src="../../support/js/jquery.min.js"></script>
	<script type="text/javascript" src="../../support/js/control.js"></script>
</head>
<script type="text/javascript">
// Popup window code
function newPopup(url) {
	popupWindow = window.open(
		url,'popUpWindow','height=300,width=500,left=10,top=10,resizable=yes,scrollbars=yes,toolbar=yes,menubar=no,location=no,directories=no,status=yes,dependent=yes,menubar=no,resizable=no,scrollbars=yes')
		                   
}
</script>
<body>
<table width="100%" border="0" cellpadding="5" cellspacing="0">
  <tr>
    <td></td>
  </tr>
</table>
<table width="100%"  border="0" align="center" cellpadding="0" cellspacing="0" style="border-left: 1px solid #7F9DB9; border-right: 1px solid #7F9DB9; border-top: 1px solid #7F9DB9; border-bottom: 1px solid #7F9DB9;">
  <tr>
    <td width="95%" height="20" nowrap ><table width="100%" height="20"  border="0" align="center" cellpadding="0" cellspacing="0" style="border-bottom: 1px solid #7F9DB9;">
        <tr >
          <td width="96%" height="19" nowrap bgcolor="#E1204F" b><span class="style2"><span class="style20">&nbsp;<span class="style18">CUSTOMER ISSUE TRACKING </span></span></span></td>
        </tr>
    </table></td>
  </tr>
  <tr>
    <td height="422" valign="top" nowrap>
	<form action="" method="post" name="ReturnDepartmentSelect" id="ReturnDepartmentSelect">
	  <div align="center">
	    <p class="style11"><strong>
	         
			 
		    <span class="style19">
			 <?php
     $con = mysql_connect("localhost","root","");
     if (!$con) {die('Could not connect: ' . mysql_error());}
     mysql_select_db("bmpl_system") or die(mysql_error());
			  
			  
	 $query = mysql_query(" SELECT * FROM sys_user WHERE usr_id = '$loginUser_id' ");  
	 while($row = mysql_fetch_array($query))
     {
	 $deprtmnt = $row['usr_department'];
     }
	 
	 $queryl = mysql_query(" SELECT * FROM sys_user_right WHERE usr_id = '$loginUser_id' and rgt_name = 'CUSTOMERQUERYTRACKINGINPUT' ");  
	 while($row = mysql_fetch_array($queryl))
     {
	 $rgtname = $row['rgt_name'];
     }
	 
	 if ($rgtname != "CUSTOMERQUERYTRACKINGINPUT")
	 
	 {
 include_once 'unuthorized.php';	
	  exit;
	 }?>
	      </span></strong></p>
	    </div>
	</form>
	<form action="rec-pageexe.php" method="post" enctype="multipart/form-data" >
	
      <table width="80%" height="520"  border="0" align="center" cellpadding="0" cellspacing="0" class="style11" >
        <tr class="style6">
          <td height="13" align="right" nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="13" align="right" nowrap >&nbsp;</td>
          <td nowrap ><div align="center"><span class="style16">              
  
        </span> <span class="style16">
        <?php    
  
        mysql_connect("localhost", "root", "") or die(mysql_error());
        mysql_select_db("bmpl_system") or die(mysql_error());
        $result = mysql_query("SELECT * FROM sys_user WHERE usr_id = '$loginUser_id' ") or die(mysql_error());  
        while($row = mysql_fetch_array( $result )) 
        {  
        $fullname       = $row['usr_full_name'];
        $userdepartment = $row['usr_department'];
        $userbranch     = $row['usr_branch'];
        } 
        ?>
        <span class="style2"><span class="style3">        </span></span> </span></div></td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="14" nowrap style="border-bottom: 1px solid #7F9DB9;">&nbsp;</td>
          <td nowrap style="border-bottom: 1px solid #7F9DB9;"><span class="style2"><span class="style3">BASIC DETAILS </span></span></td>
          <td nowrap style="border-bottom: 1px solid #7F9DB9;">&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="13" align="right" nowrap >&nbsp;</td>
          <td nowrap >&nbsp;		 </td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td width="28%" height="23" align="right" nowrap > ISSUE REF # : </td>
          <td width="31%" nowrap ><table width="100%"  border="0" align="center" cellpadding="0" cellspacing="0" >
              <tr>
                <td width="29%" nowrap class="style11" ><?php
               
               mysql_connect("localhost", "root", "") or die(mysql_error());
               mysql_select_db("bmpl_servicedeliveryportal") or die(mysql_error());
               $result = mysql_query("SELECT iss_code FROM sd_issue order by iss_code") or die(mysql_error());  
               while($row = mysql_fetch_array( $result )) 
               {  
               $name = $row['iss_code'];
               } 
               $number = ($name + 1);
              ?>
                    <input name="inumbern" type="text" class="style13" id="inumbern" value="CIN<?php echo "$number"; ?>" style="text-transform:uppercase;"></td>
                <td width="39%" nowrap class="style11" ><input name="inumber" type="hidden" class="style3" id="inumber" value="CIN<?php echo "$number"; ?>"></td>
                <td width="32%" align="center" nowrap class="style11"  ><div align="right">DATE :</div></td>
              </tr>
          </table></td>
          <td width="41%" nowrap ><input name="idaten" type="text" class="style13" id="idaten" value="<?php echo date("Y-m-d", time()); ?>">
            <input name="idate" type="hidden"  class="style11" id="idate" value="<?php echo date("Y-m-d", time()); ?>"></td>
        </tr>
        <tr class="style6">
          <td height="28" align="right" nowrap >INPUTER :</td>
          <td nowrap ><table width="100%"  border="0" align="center" cellpadding="0" cellspacing="0" >
            <tr>
              <td width="29%" nowrap class="style11" ><input name="ireportedbyn" type="text" class="style13" id="ireportedbyn" value="<?php echo "$fullname"; ?>" style="text-transform:uppercase;"></td>
              <td width="39%" nowrap class="style11" ><input name="ireportedby" type="hidden" class="style11" id="ireportedby" value="<?php echo "$fullname"; ?>"></td>
              <td width="32%" align="center" nowrap class="style11" ><div align="right">TIME :</div></td>
            </tr>
          </table></td>
          <td nowrap ><input name="itimen" type="text" class="style13" id="itimen" value="<?php echo date("H:i:s", time()); ?>">
            <input name="itime" type="hidden"  class="style11" id="itime" value="<?php echo date("H:i:s", time()); ?>"></td>
        </tr>
        <tr class="style6">
          <td height="13" align="right" nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="13" align="right" nowrap style="border-bottom: 1px solid #7F9DB9;">&nbsp;</td>
          <td nowrap style="border-bottom: 1px solid #7F9DB9;"><span class="style2"><span class="style3">CUSTOMER DETAILS </span></span></td>
          <td nowrap style="border-bottom: 1px solid #7F9DB9;">&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="13" align="right" nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="23" align="right" nowrap >COMPANY NAME :</td>
          <td nowrap ><input name="icname" type="text" class="style13" id="icname" style="text-transform:uppercase;" size="50" ></td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="23" align="right" nowrap >CONTACT PERSON :</td>
          <td nowrap >            <table width="100%"  border="0" align="center" cellpadding="0" cellspacing="0" >
              <tr>
                <td width="29%" nowrap class="style11" >                  <input name="icmname" type="text" class="style13" id="icmname" style="text-transform:uppercase;" value="NA" size="50" ></td>
                <td width="39%" nowrap class="style11" >&nbsp;</td>
                <td width="32%" align="center" nowrap class="style11" ><div align="right"></div></td>
              </tr>
            </table></td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="13" align="right" nowrap >&nbsp;</td>
          <td nowrap ><table width="100%"  border="0" align="center" cellpadding="0" cellspacing="0" >
              <tr>
                <td width="29%" nowrap class="style11" >&nbsp;</td>
                <td width="39%" nowrap class="style11" >&nbsp;</td>
                <td width="32%" align="center" nowrap class="style11" ><div align="right"></div></td>
              </tr>
          </table></td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="14" align="right" nowrap style="border-bottom: 1px solid #7F9DB9;" >&nbsp;</td>
          <td nowrap style="border-bottom: 1px solid #7F9DB9;"><span class="style2"><span class="style3">ISSUE DETAILS </span></span></td>
          <td nowrap style="border-bottom: 1px solid #7F9DB9;">&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="13" align="right" nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="27" align="right" nowrap >PRODUCT TYPE :</td>
          <td nowrap ><table width="100%"  border="0" align="center" cellpadding="0" cellspacing="0" >
            <tr>
              <td width="29%" nowrap class="style11" ><select name="iproduct" class="style13" id="iproduct">
                <OPTION VALUE="SELECT PRODUCT TYPE">SELECT PRODUCT TYPE</OPTION>
                <OPTION VALUE="TT">TT</OPTION>
                <OPTION VALUE="TISS">TISS</OPTION>
                <OPTION VALUE="CCE">CCE</OPTION>
                <OPTION VALUE="CDR">CDR</OPTION>
                <OPTION VALUE="CIT">CIT</OPTION>
                <OPTION VALUE="EFT">EFT</OPTION>
				<OPTION VALUE="CASH">CASH</OPTION>
				<OPTION VALUE="FOREX">FOREX</OPTION>
				<OPTION VALUE="CHEQUE">CHEQUE</OPTION>
				<OPTION VALUE="ACCOUNT">ACCOUNT</OPTION>
				<OPTION VALUE="STATEMENT">STATEMENT</OPTION>
				<OPTION VALUE="ACCOUNT BALANCE">ACCOUNT BALANCE</OPTION>
				<OPTION VALUE="INWARD TT">INWARD TT</OPTION>
				<OPTION VALUE="INWARD TISS">INWARD TISS</OPTION>
				<OPTION VALUE="COMPLAIN">COMPLAIN</OPTION>
				<OPTION VALUE="MONEY WIRELESS">MONEY WIRELESS</OPTION>
				<OPTION VALUE="MONEY MAIL">MONEY MAIL</OPTION>
				<OPTION VALUE="CREDIT">CREDIT</OPTION>
				<OPTION VALUE="TRADE FINANCE">TRADE FINANCE</OPTION>
				<OPTION VALUE="MONEY MSAFIRI">MONEY MSAFIRI</OPTION>

                            </select></td>
              <td width="39%" nowrap class="style11" >&nbsp;</td>
              <td width="32%" align="center" nowrap class="style11" ><div align="right">RECEIVED BY :</div></td>
            </tr>
          </table></td>
          <td nowrap >            <select name="ireceivedby" class="style13" id="ireceivedby">

<OPTION VALUE="SELECT RECEIVED BY">SELECT RECEIVED BY</OPTION>
<OPTION VALUE="SANYA ABDUL">SANYA ABDUL</OPTION>
<OPTION VALUE="GRACE NGUMA">GRACE NGUMA</OPTION>
<OPTION VALUE="NELSHAH HAJI">NELSHAH HAJI</OPTION>
<OPTION VALUE="HUSSEIN MANJI">HUSSEIN MANJI</OPTION>
<OPTION VALUE="GODFREY UTOUH">GODFREY UTOUH</OPTION>
<OPTION VALUE="HTB">HTB</OPTION>
<OPTION VALUE="HCB">HCB</OPTION>
<OPTION VALUE="ABEL LASWAY">ABEL LASWAY</OPTION>
<OPTION VALUE="NADEEM MOHAMED">NADEEM MOHAMED</OPTION>
<OPTION VALUE="SCHOLA MRINA">SCHOLA MRINA</OPTION>
<OPTION VALUE="KAISY MWAKAJEGELA">KAISY MWAKAJEGELA</OPTION>
<OPTION VALUE="SERVICE DELIVERY">SERVICE DELIVERY</OPTION>
<OPTION VALUE="UHURU HCC">UHURU HCC</OPTION>
<OPTION VALUE="KISUTU HCC">KISUTU HCC</OPTION>
<OPTION VALUE="IFB HCC">IFB HCC</OPTION>
<OPTION VALUE="ARUSHA HCC">ARUSHA HCC</OPTION>
<OPTION VALUE="MWANZA HCC">MWANZA HCC</OPTION>
<OPTION VALUE="BRANCH MANAGER(IFB)">BRANCH MANAGER(IFB)</OPTION>
<OPTION VALUE="BRANCH MANAGER(KISUTU)">BRANCH MANAGER(KISUTU)</OPTION>
<OPTION VALUE="BRANCH MANAGER(UHURU)">BRANCH MANAGER(UHURU)</OPTION>
<OPTION VALUE="BRANCH MANAGER(ARUSHA)">BRANCH MANAGER(ARUSHA)</OPTION>
<OPTION VALUE="BRANCH MANAGER(MWANZA)">BRANCH MANAGER(MWANZA)</OPTION>
<OPTION VALUE="ALKARIM SOMJI">ALKARIM SOMJI</OPTION>
<OPTION VALUE="ANNE NEHEMIA">ANNE NEHEMIA</OPTION>
<OPTION VALUE="WASEEM ARAIN">WASEEM ARAIN</OPTION>
<OPTION VALUE="JACQUELINE WOISO">JACQUELINE WOISO</OPTION>
<OPTION VALUE="DEEPALI RAMAIYA">DEEPALI RUMAIYA</OPTION>
<OPTION VALUE="JIBRAAN KADRI">JIBRAAN KADRI</OPTION>
<OPTION VALUE="SHEENA SINARE">SHEENA SINARE</OPTION>


<OPTION VALUE="JIGNASA RANA">JIGNASA RANA</OPTION>
<OPTION VALUE="ALIAKBER KERMALI">ALIAKBER KERMALI</OPTION>
<OPTION VALUE="SMITESH">SMITESH</OPTION>
<OPTION VALUE="JOANMARY KAHWA">JOANMARY KAHWA</OPTION>



   </select></td>
        </tr>
        <tr class="style6">
          <td height="27" align="right" nowrap >PRODUCT DETAILS :</td>
          <td nowrap ><table width="100%"  border="0" align="center" cellpadding="0" cellspacing="0" >
              <tr>
                <td width="97%" nowrap class="style11" ><select name="iproductdetails" class="style13" id="iproductdetails">
                   <OPTION VALUE="SELECT PRODUCT DETAILS">SELECT PRODUCT DETAILS</OPTION>
                    <OPTION VALUE="WRONG CR/DR">WRONG CR/DR</OPTION>
                    <OPTION VALUE="WRONG CHARGES">WRONG CHARGES</OPTION>
                    <OPTION VALUE="NOT PROCESSED">NOT PROCESSED</OPTION>
                    <OPTION VALUE="OTHERS">OTHERS</OPTION>

                </select>                  
                   FOR AC AND CHEQUE PRODUCTS </td>
                <td width="3%" nowrap class="style11" >&nbsp;</td>
                </tr>
          </table></td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="27" align="right" nowrap >MODE OF RECEIPT :</td>
          <td nowrap >            <table width="100%"  border="0" align="center" cellpadding="0" cellspacing="0" >
              <tr>
                <td width="29%" nowrap class="style11" ><select name="imode" class="style13" id="imode">
                  <OPTION VALUE="SELECT MODE OF RECEIPT">SELECT MODE OF RECEIPT</OPTION>
                  <OPTION VALUE="TELEPHONE">TELEPHONE</OPTION>
                  <OPTION VALUE="MAIL">MAIL</OPTION>

                </select></td>
                <td width="39%" nowrap class="style11" >&nbsp;</td>
                <td width="32%" align="center" nowrap class="style11" ><div align="right">STATUS :</div></td>
              </tr>
            </table></td>
          <td nowrap ><select name="istatus" class="style13" id="istatus">
            <OPTION VALUE="SELECT STATUS">SELECT STATUS</OPTION>
            <OPTION VALUE="PENDING AWAITING RESOLUTION">PENDING AWAITING RESOLUTION</OPTION>
           <?PHP // <OPTION VALUE="PENDING AWAITING CLIENTS CONFIRMATION">PENDING AWAITING CLIENTS CONFIRMATION</OPTION> ?>
            <OPTION VALUE="RESOLVED">RESOLVED</OPTION>

          </select></td>
        </tr>
        <tr class="style6">
          <td height="90" align="right" nowrap ><p>ISSUE DESCRIPTION :</p></td>
          <td nowrap ><textarea name="idescription" cols="70" rows="5" class="style13" id="idescription"></textarea></td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="13" align="right" nowrap >DEPARTMENT RESPONSIBLE :</td>
          <td nowrap ><select name="iresponsible" class="style13" id="iresponsible">
            <OPTION VALUE="SELECT DEPARTMENT">SELECT DEPARTMENT</OPTION>
            <OPTION VALUE="ADMINISTRATION">ADMINISTRATION</OPTION>
            <OPTION VALUE="MONEY SHOPPE @ ARUSHA">MONEY SHOPPE @ ARUSHA</OPTION>
            <OPTION VALUE="BRANCH MANAGEMENT UNIT">BRANCH MANAGEMENT UNIT</OPTION>
            <OPTION VALUE="CENTRALIZED OPERATIONS">CENTRALIZED OPERATIONS</OPTION>
            <OPTION VALUE="CORPORATE AFFAIRS">CORPORATE AFFAIRS</OPTION>
            <OPTION VALUE="CORPORATE BANKING">CORPORATE BANKING</OPTION>
            <OPTION VALUE="CREDIT">CREDIT</OPTION>
            <OPTION VALUE="FINANCE">FINANCE</OPTION>
            <OPTION VALUE="HUMAN RESOURCES">HUMAN RESOURCES</OPTION>
            <OPTION VALUE="ICT">ICT</OPTION>
            <OPTION VALUE="INDUSTIAL FINANCE BRANCH">INDUSTIAL FINANCE BRANCH</OPTION>
            <OPTION VALUE="INTERNAL AUDIT">INTERNAL AUDIT</OPTION>
            <OPTION VALUE="MONEY SHOPPE @ KISUTU">MONEY SHOPPE @ KISUTU</OPTION>
            <OPTION VALUE="MONEY SHOPPE @ MWANZA">MONEY SHOPPE @ MWANZA</OPTION>
            <OPTION VALUE="PRODUCT DELIVERY">PRODUCT DELIVERY</OPTION>
            <OPTION VALUE="SERVICE DELIVERY">SERVICE DELIVERY</OPTION>
            <OPTION VALUE="TRADE FINANCE">TRADE FINANCE</OPTION>
            <OPTION VALUE="TRANSACTIONAL BANKING">TRANSACTIONAL BANKING</OPTION>
            <OPTION VALUE="TREASURY">TREASURY</OPTION>
            <OPTION VALUE="TREASURY BACK OFFICE">TREASURY BACK OFFICE</OPTION>
            <OPTION VALUE="MONEY SHOPPE @ UHURU">MONEY SHOPPE @ UHURU</OPTION>
            <OPTION VALUE="COMPLIANCE">COMPLIANCE</OPTION>
            <OPTION VALUE="OPERATION">OPERATION</OPTION>
            <OPTION VALUE="COMMUNICATIONS">COMMUNICATIONS</OPTION>
			<OPTION VALUE="PAYMENTS">PAYMENTS</OPTION>
			<OPTION VALUE="REGIONAL RELATIONSHIPS">REGIONAL RELATIONSHIPS</OPTION>
			<OPTION VALUE="INSTITUTIONAL BANKING">INSTITUTIONAL BANKING</OPTION>
			<OPTION VALUE="SOVEREIGN UNIT">SOVEREIGN UNIT</OPTION>
            <OPTION VALUE="PROCESSING UNIT">PROCESSING UNIT</OPTION>
            <OPTION VALUE="FUNDS TRANSFER UNIT">FUNDS TRANSFER UNIT</OPTION>
			 <OPTION VALUE="NA">NA</OPTION>

          </select></td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="13" align="right" nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="13" align="right" nowrap >DEPARTMENT PERSON : </td>
          <td nowrap ><?PHP
			mysql_connect("localhost", "root", ""); 
			mysql_select_db("bmpl_system"); 
			$res=mysql_query("SELECT * FROM sys_user where  usr_status = 'ACTIVE' order by usr_first_name") or die(mysql_error()); 
			echo "<select name=user1M class=style13 style=text-transform:uppercase	>"; 
			while($row=mysql_fetch_assoc($res)) 
			{ echo " <option value=$row[usr_id]>$row[usr_full_name]</a></option> ";}
			echo "</select>";
					?></td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="13" align="right" nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="13" align="right" nowrap style="border-bottom: 1px solid #7F9DB9;">&nbsp;</td>
          <td nowrap style="border-bottom: 1px solid #7F9DB9;"><span class="style2"><span class="style3">ACTION</span></span></td>
          <td nowrap style="border-bottom: 1px solid #7F9DB9;">&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="13" align="right" nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
          <td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="21" align="right" nowrap >&nbsp;</td>
          <td nowrap >
              <div align="left">
                <input name="Record" type="Submit" class="style13" id="Record" value="SUBIT" OnClick="show_alert()">
                <input name="Reset Form" type="reset" class="style13" id="Submit" value="RESET">
                <a href="index.php"><input name="Exit" type="button" class="style13" id="Submit" value="EXIT"></a>
              </div></td><td nowrap >&nbsp;</td>
        </tr>
        <tr class="style6">
          <td height="21" align="right" nowrap >&nbsp;</td>
          <td nowrap ><div align="center">
          </div></td>
          <td nowrap >&nbsp;</td>
        </tr>
      </table>
      </form>
    </td>
  </tr>
</table>
</body>
</html>
