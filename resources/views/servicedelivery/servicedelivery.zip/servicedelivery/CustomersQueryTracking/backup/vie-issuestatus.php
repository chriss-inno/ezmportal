<?php
session_start();
$loginUser_id = $_SESSION['SESS_USER_ID'];
require_once('../../../config/auth_content.php');
?> 
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Untitled Document</title>
<style type="text/css">
<!--
.style2 {
	color: #0E3793;
	font-weight: bold;
}
.style3 {
	font-size: 11px;
	font-family: tahoma;
	color: #FFFFFF;
}
.style43 {
	font-size: 11px;
	font-family: tahoma;
	color: #FFFFFF;
	}
.style4 {
	color: #FFFFFF;
	font-family: tahoma;
	font-size: 11px;
}
a:link {
	color: #FFFFFF;
	text-decoration: none;
}
a:visited {
	color: #FFFFFF;
	text-decoration: none;
}
a:hover {
	color: #FF0000;
	text-decoration: none;
}
a:active {
	color: #FFFFFF;
	text-decoration: none;
}
.style6 {font-size: 11px}
.style7 {
	color: #FFFFFF;
	font-weight: bold;
}
.style8 {color: #FFFFFF; font-family: tahoma; font-size: 11px; }
body {
	background-image: url(../../images/backgrounds/pagebg.png);
}
.style44 {color: #0E3793}
.style46 {
	color: #0E3793;
	font-family: tahoma;
	font-size: 11px;
}
.style11 {font-family: tahoma; font-size: 11px; color: #ffffff; }
.style1 {font-family: tahoma;
	font-size: 12px;
	color: #FFFFFF;
}
.style19 {font-size: 11px; font-family: tahoma; color: #FFFFFF; font-weight: bold; }
-->
</style>
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_jumpMenu(targ,selObj,restore){ //v3.0
  eval(targ+".location='"+selObj.options[selObj.selectedIndex].value+"'");
  if (restore) selObj.selectedIndex=0;
}
//-->
</script>
</head>

<body>
<table width="100%" border="0" cellpadding="5" cellspacing="0">
  <tr>
    <td></td>
  </tr>
</table>
<table width="100%"  border="0" align="center" cellpadding="0" cellspacing="0" style="border-bottom: 1px solid #7F9DB9; border-left: 1px solid #7F9DB9; border-right: 1px solid #7F9DB9; border-top: 1px solid #7F9DB9; ">
  <tr>
    <td width="95%" height="20" nowrap><table width="100%" height="20"  border="0" align="center" cellpadding="0" cellspacing="0" style="border-bottom: 1px solid #7F9DB9;">
      <tr >
        <td width="96%" height="19" nowrap bgcolor="#E1204F" class="style2">&nbsp;<span class="style8">CUSTOMER ISSUE VIEW DETAILS</span></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="125" align="center" valign="top" nowrap><form action="vie-issuestatus.php" method="post" name="SubmitDepartment" id="SubmitDepartment">
      <table width="95%" height="21"  border="0" align="center" cellpadding="0" cellspacing="0" class="style4">
        <tr class="style6">
          <td width="29%" height="21" align="center" nowrap ><table width="100%" height="54"  border="0" align="center" cellpadding="0" cellspacing="0" class="style4" >
              <tr class="style6">
                <td width="29%" height="54" align="center" nowrap ><table width="100%" height="177"  border="0" align="center" cellpadding="0" cellspacing="0" class="style4" >
                    <tr class="style6">
                      <td height="13" align="center" nowrap ><span class="style11"><strong><span class="style19">
                        <strong>
                        <?php
     $con = mysql_connect("localhost","root","");
     if (!$con) {die('Could not connect: ' . mysql_error());}
     mysql_select_db("bmpl_system") or die(mysql_error());
			  
			  
	 $query = mysql_query(" SELECT * FROM sys_user WHERE usr_id = '$loginUser_id' ");  
	 while($row = mysql_fetch_array($query))
     {
	 $deprtmnt = $row['usr_department'];
     }
	 
	 $queryl = mysql_query(" SELECT * FROM sys_user_right WHERE usr_id = '$loginUser_id' and rgt_name = 'CUSTOMERQUERYTRACKINGVIEW' ");  
	 while($row = mysql_fetch_array($queryl))
     {
	 $rgtname = $row['rgt_name'];
     }
	 
	 if ($rgtname != "CUSTOMERQUERYTRACKINGVIEW")
	 
	 {
 include_once 'unuthorized.php';	
	  exit;
	 }?>
                        </strong>                      </span></strong></span></td>
                    </tr>
                    <tr class="style6">
                      <td height="13" align="center" nowrap class="style7" >Please select searching criteria to search for a customer issue</td>
                    </tr>
                    <tr class="style6">
                      <td width="29%" height="21" align="center" nowrap ><p>
                          <select name="menu1" class="style46"  onChange="MM_jumpMenu('self',this,0)">
                             <option value="vie-issuestatus.php" selected>STATUS</option>
                            <option value="vie-issueproducttype.php">PRODUCT TYPE</option>
                            <option value="vie-issuereceivedmode.php">MODE OF RECEIPT</option>
                        
                            <option value="vie-issueall.php">ALL</option>
							<option value="vie-datereported.php">REPORTED DATE</option>
							<option value="vie-issuenumber.php">ISSUE NUMBER</option>
                          </select>
                      </p></td>
                    </tr>
                    <tr class="style6">
                      <td height="13" align="center" nowrap ><strong>Please Select Issue Status </strong></td>
                    </tr>
                    <tr class="style6">
                      <td height="13" align="center" nowrap >&nbsp;</td>
                    </tr>
                    <tr class="style6">
                      <td height="13" align="center" nowrap ><span class="style11">
                        <select name="istatus" class="style46" id="istatus">
                          <option value="Select Status">Select Status</option>
                          <option value="Pending awaiting resolution">Pending awaiting resolution</option>
                      <?PHP //    <option value="Pending awaiting clients confirmation">Pending awaiting clients confirmation</option> ?>
                          <option value="Resolved">Resolved</option>
                        </select>
                      </span></td>
                    </tr>
                    <tr class="style6">
                      <td height="13" align="center" nowrap >&nbsp;</td>
                    </tr>
                    <tr class="style6">
                      <td height="13" align="center" nowrap ><input name="Submit" type="submit" class="style46" value="Submit"></td>
                    </tr>
                    <tr class="style6">
                      <td height="13" align="center" nowrap >&nbsp;</td>
                    </tr>
                    <tr class="style6">
                      <td height="13" align="center" nowrap ><span class="style8">
                     <?php
    if (isset($_POST['Submit'])) 
{


              $istatus = $_POST['istatus'];
			  
			  
			  mysql_connect("localhost", "root", "") or die(mysql_error());
              mysql_select_db("bmpl_servicedeliveryportal") or die(mysql_error());  
              $query = mysql_query(" SELECT * FROM sd_issue WHERE iss_status = '$istatus' ORDER BY iss_code");                   
              $count = 1;
			  $result = $query;
		      if($result) 
		             {
			if(mysql_num_rows($result) != 0) 
			{
     echo "<table width=95%   border=0 align=center cellpadding=0 cellspacing=0 >
     <tr align=center bgcolor=#E1204F>
     <td width=20  height=25 nowrap style='border-top: 1px solid #7F9DB9; border-right: 1px solid #7F9DB9; border-bottom: 1px solid #7F9DB9; border-left: 1px solid #7F9DB9;'><span class=style2><span class=style3>S. #</td>
     <td width=60  height=25 nowrap style='border-top: 1px solid #7F9DB9; border-right: 1px solid #7F9DB9; border-bottom: 1px solid #7F9DB9;'><span class=style2><span class=style3>ISSUE #</span></td>
     <td width=60  height=25 nowrap style='border-top: 1px solid #7F9DB9; border-right: 1px solid #7F9DB9; border-bottom: 1px solid #7F9DB9;'><span class=style2><span class=style3>CUSTOMER NAME</span></td>
	 <td width=60  height=25 nowrap style='border-top: 1px solid #7F9DB9; border-right: 1px solid #7F9DB9; border-bottom: 1px solid #7F9DB9;'><span class=style2><span class=style3>PRODUCT TYPE</span></span></td>
     <td width=60  height=25 nowrap style='border-top: 1px solid #7F9DB9; border-right: 1px solid #7F9DB9; border-bottom: 1px solid #7F9DB9;'><span class=style2><span class=style3>RECEIVED BY</span></span></td>
	 <td width=60  height=25 nowrap style='border-top: 1px solid #7F9DB9; border-right: 1px solid #7F9DB9; border-bottom: 1px solid #7F9DB9;'><span class=style2><span class=style3>MODE OF RECEIPTS</span></span></td>

	 	 <td width=60  height=25 nowrap style='border-top: 1px solid #7F9DB9; border-right: 1px solid #7F9DB9; border-bottom: 1px solid #7F9DB9;'><span class=style2><span class=style3>STATUS </span></span></td>
		 <td width=60  height=25 nowrap style='border-top: 1px solid #7F9DB9; border-right: 1px solid #7F9DB9; border-bottom: 1px solid #7F9DB9;'><span class=style2><span class=style3>DATE INPUTED</span></span></td>
	 <td width=60  height=25 nowrap style='border-top: 1px solid #7F9DB9; border-right: 1px solid #7F9DB9; border-bottom: 1px solid #7F9DB9;'><span class=style2><span class=style3>DEPARTMENT RESPONSIBLE</span></span></td>

     </tr>";


   while($row = mysql_fetch_array($query))
    { 
    echo "<tr align=left class=style4>";
	echo "<td  height=25 nowrap class=style1 style='border-bottom: 1px solid #7F9DB9; border-right: 1px solid #7F9DB9; border-left: 1px solid #7F9DB9;'><span class=style4>&nbsp;&nbsp; $count </span></td>";
	$a=$row['iss_reference_number'];
	echo "<td  height=25 nowrap class=style1 style='border-bottom: 1px solid #7F9DB9; border-right: 1px solid #7F9DB9'><span class=style4><a href='prg-viewall.php?iss_reference_number=".$a."'>&nbsp;&nbsp;&nbsp;&nbsp;".$a."</a></span></td>"; 
    echo '<td  height=25 nowrap class=style1 style="border-bottom: 1px solid #7F9DB9; border-right: 1px solid #7F9DB9"><span class=style4>&nbsp;&nbsp;&nbsp;&nbsp;'. $row["iss_customer_name"].'</span></td>';
	echo '<td  height=25 nowrap class=style1 style="border-bottom: 1px solid #7F9DB9; border-right: 1px solid #7F9DB9"><span class=style4>&nbsp;&nbsp;&nbsp;&nbsp;'. $row["iss_product_type"].'</span></td>';
	echo '<td  height=25 nowrap class=style1 style="border-bottom: 1px solid #7F9DB9; border-right: 1px solid #7F9DB9"><span class=style4>&nbsp;&nbsp;&nbsp;&nbsp;'. $row["iss_received_by"].'</span></td>';
	echo '<td  height=25 nowrap class=style1 style="border-bottom: 1px solid #7F9DB9; border-right: 1px solid #7F9DB9"><span class=style4>&nbsp;&nbsp;&nbsp;&nbsp;'. $row["iss_received_mode"].'</span></td>';	

		echo '<td  height=25 nowrap class=style1 style="border-bottom: 1px solid #7F9DB9; border-right: 1px solid #7F9DB9"><span class=style4>&nbsp;&nbsp;&nbsp;&nbsp;'. $row["iss_status"].'</span></td>';		
			echo '<td  height=25 nowrap class=style1 style="border-bottom: 1px solid #7F9DB9; border-right: 1px solid #7F9DB9"><span class=style4>&nbsp;&nbsp;&nbsp;&nbsp;'. $row["iss_reported_date"].'</span></td>';	
	echo '<td  height=25 nowrap class=style1 style="border-bottom: 1px solid #7F9DB9; border-right: 1px solid #7F9DB9"><span class=style4>&nbsp;&nbsp;&nbsp;&nbsp;'. $row["iss_responsible"].'</span></td>';    

	echo "</tr>"; 


	$count ++; 
	 }
	 echo "</table>";

	 }else
	 {
	 echo "<span class=style2><span class=style3>No customer issue  to display</span></span>";
	 }}}
     ?>
                      </span></td>
                    </tr>
                    <tr class="style6">
                      <td height="13" align="center" nowrap >&nbsp;</td>
                    </tr>
                    <tr class="style6">
                      <td height="13" align="center" nowrap ><span class="style44 ">
                        <input type=button onClick="location.href='index.php'" class='style46' value='Exit'>
                      </span></td>
                    </tr>
                    <tr class="style6">
                      <td height="13" align="center" nowrap ><div align="left"><span class="style1"></span></div></td>
                    </tr>
                </table></td>
              </tr>
          </table></td>
        </tr>
      </table>
      <span class="style8"></span>
      </form>    
    </td>
  </tr>
</table>
<p/>
</body>
</html>
