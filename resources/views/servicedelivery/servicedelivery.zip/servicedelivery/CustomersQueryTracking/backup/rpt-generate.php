<?php
session_start();
$loginUser_id = $_SESSION['SESS_USER_ID'];
require_once('../../../config/auth_content.php');
?> 
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Untitled Document</title>
<style type="text/css">
<!--
.style2 {
	color: #0E3793;
	font-weight: bold;
}
.style4 {
	color: #FFFFFF;
	font-family: tahoma;
	font-size: 11px;
}
a:link {
	color: #FFFFFF;
	text-decoration: none;
}
a:visited {
	color: #FFFFFF;
	text-decoration: none;
}
a:hover {
	color: #FF0000;
	text-decoration: none;
}
a:active {
	color: #FFFFFF;
	text-decoration: none;
}
.style6 {font-size: 11px}
.style8 {color: #FFFFFF; font-family: tahoma; font-size: 11px; }
body {
	background-image: url(../../images/backgrounds/pagebg.png);
}
.style44 {color: #0E3793}
.style46 {
	color: #0E3793;
	font-family: tahoma;
	font-size: 11px;
}
.style11 {font-family: tahoma; font-size: 11px; color: #ffffff; }
.style19 {font-size: 11px; font-family: tahoma; color: #FFFFFF; font-weight: bold; }
-->
</style>
</head>

<body>
<table width="100%" border="0" cellpadding="5" cellspacing="0">
  <tr>
    <td></td>
  </tr>
</table>
<table width="100%"  border="0" align="center" cellpadding="0" cellspacing="0" style="border-bottom: 1px solid #7F9DB9; border-left: 1px solid #7F9DB9; border-right: 1px solid #7F9DB9; border-top: 1px solid #7F9DB9; ">
  <tr>
    <td width="95%" height="20" nowrap><table width="100%" height="20"  border="0" align="center" cellpadding="0" cellspacing="0" style="border-bottom: 1px solid #7F9DB9;">
      <tr >
        <td width="96%" height="19" nowrap bgcolor="#E1204F" class="style2">&nbsp;<span class="style8">REPORT GENERATE </span></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="125" align="center" valign="top" nowrap><form action="save_as_excel/excel.php" method="post" name="SubmitDepartment" id="SubmitDepartment">
      <table width="95%" height="21"  border="0" align="center" cellpadding="0" cellspacing="0" class="style4">
        <tr class="style6">
          <td width="29%" height="21" align="center" nowrap ><table width="100%" height="54"  border="0" align="center" cellpadding="0" cellspacing="0" class="style4" >
              <tr class="style6">
                <td width="29%" height="54" align="center" nowrap ><table width="100%" height="104"  border="0" align="center" cellpadding="0" cellspacing="0" class="style4" >
                    <tr class="style6">
                      <td width="29%" height="13" align="center" nowrap ><span class="style11"><strong><span class="style19">
                        <strong>
                        <?php
     $con = mysql_connect("localhost","root","");
     if (!$con) {die('Could not connect: ' . mysql_error());}
     mysql_select_db("bmpl_system") or die(mysql_error());
			  
			  
	 $query = mysql_query(" SELECT * FROM sys_user WHERE usr_id = '$loginUser_id' ");  
	 while($row = mysql_fetch_array($query))
     {
	 $deprtmnt = $row['usr_department'];
     }
	 
	 $queryl = mysql_query(" SELECT * FROM sys_user_right WHERE usr_id = '$loginUser_id' and rgt_name = 'CUSTOMERQUERYTRACKINGVIEW' ");  
	 while($row = mysql_fetch_array($queryl))
     {
	 $rgtname = $row['rgt_name'];
     }
	 
	 if ($rgtname != "CUSTOMERQUERYTRACKINGVIEW")
	 
	 {
 include_once 'unuthorized.php';	
	  exit;
	 }?>
                        </strong>                      </span></strong></span></td>
                    </tr>
                    <tr class="style6">
                      <td height="13" align="center" nowrap ><strong>STATUS OR OPENINED DATE</strong></td>
                    </tr>
                    <tr class="style6">
                      <td height="13" align="center" nowrap >&nbsp;</td>
                    </tr>
                    <tr class="style6">
                      <td height="13" align="center" nowrap ><table width="100%" height="28"  border="0" align="center" cellpadding="0" cellspacing="0" class="style8" >
                        <tr class="style6">
                          <td width="46%" height="28" align="center" nowrap ><div align="right"><span class="style11"><strong>STATUS</strong></span></div></td>
                          <td width="1%" align="center" nowrap ><span class="style11"><strong>:</strong></span></td>
                          <td width="53%" align="center" nowrap ><div align="left"><span class="style11">                              <select name="istatus" class="style46" id="istatus">
                                <option value="All">All</option>
                                <option value="Pending awaiting resolution">Pending awaiting resolution</option>
               
                                <option value="Resolved">Resolved</option>
                              </select>
</span></div></td>
                          </tr>
                      </table></td>
                    </tr>
                    <tr class="style6">
                      <td height="13" align="center" nowrap ><table width="100%" height="58"  border="0" align="center" cellpadding="0" cellspacing="0" class="style8" >
                        <tr class="style6">
                          <td height="29" align="center" nowrap >&nbsp;</td>
                          <td align="center" nowrap >&nbsp;</td>
                          <td align="center" nowrap ><div align="left"><span class="style11"><strong>DATE FORRMA: YYYY-MM-DD <strong><strong><strong></strong></strong></strong></strong></span></div></td>
                        </tr>
                        <tr class="style6">
                          <td width="46%" height="29" align="center" nowrap ><div align="right"><span class="style11"><strong>DATE/ FROM DATE </strong></span></div></td>
                          <td width="1%" align="center" nowrap ><span class="style11"><strong>: </strong></span></td>
                          <td width="53%" align="center" nowrap ><div align="left"><span class="style11"><strong><strong>
                                    <input name="idatefrom" type="text" class="style46" id="idatefrom" value="All" maxlength="10"> 
                                    TO: <strong>
                                    <input name="idateto" type="text" class="style46" id="idateto" value="All" maxlength="10">
                                    </strong>                          </strong>
                              </strong></span></div></td>
                          </tr>
                      </table></td>
                    </tr>
                    <tr class="style6">
                      <td height="13" align="center" nowrap >&nbsp;</td>
                    </tr>
                    <tr class="style6">
                      <td height="13" align="center" nowrap ><input name="Submit" type="submit" class="style46" value="Submit">
                        <span class="style44 ">
                        <input type=button onClick="location.href='index.php'" class='style46' value='Exit'>
</span></td>
                    </tr>
                    <tr class="style6">
                      <td height="13" align="center" nowrap >&nbsp;</td>
                    </tr>
                </table></td>
              </tr>
          </table></td>
        </tr>
      </table>
      <span class="style8"></span>
      </form>    
    </td>
  </tr>
</table>
<p/>
</body>
</html>
