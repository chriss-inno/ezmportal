<?php
session_start();
$loginUser_id = $_SESSION['SESS_USER_ID'];
require_once('../../../config/auth_content.php');
?> 
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Untitled Document</title>
<style type="text/css">
<!--
.style2 {
	color: #0E3793;
	font-weight: bold;
}
.style3 {
	font-size: 11px;
	font-family: tahoma;
	color: #FFFFFF;
}
.style43 {
	font-size: 11px;
	font-family: tahoma;
	color: #FFFFFF;
	}
.style4 {
	color: #FFFFFF;
	font-family: tahoma;
	font-size: 11px;
}
a:link {
	color: #FFFFFF;
	text-decoration: none;
}
a:visited {
	color: #FFFFFF;
	text-decoration: none;
}
a:hover {
	color: #FF0000;
	text-decoration: none;
}
a:active {
	color: #FFFFFF;
	text-decoration: none;
}
.style6 {font-size: 11px}
.style7 {
	color: #FFFFFF;
	font-weight: bold;
}
.style8 {color: #FFFFFF; font-family: tahoma; font-size: 11px; }
body {
	background-image: url(../../images/backgrounds/pagebg.png);
}
.style44 {color: #0E3793}
.style46 {
	color: #0E3793;
	font-family: tahoma;
	font-size: 11px;
}
.style1 {	font-family: tahoma;
	font-size: 12px;
	color: #FFFFFF;
}
-->
</style>
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_jumpMenu(targ,selObj,restore){ //v3.0
  eval(targ+".location='"+selObj.options[selObj.selectedIndex].value+"'");
  if (restore) selObj.selectedIndex=0;
}
//-->
</script>
</head>

<body>
<table width="100%" border="0" cellpadding="5" cellspacing="0">
  <tr>
    <td></td>
  </tr>
</table>
<table width="100%"  border="0" align="center" cellpadding="0" cellspacing="0" style="border-bottom: 1px solid #7F9DB9; border-left: 1px solid #7F9DB9; border-right: 1px solid #7F9DB9; border-top: 1px solid #7F9DB9; ">
  <tr>
    <td width="95%" height="20" nowrap><table width="100%" height="20"  border="0" align="center" cellpadding="0" cellspacing="0" style="border-bottom: 1px solid #7F9DB9;">
      <tr >
        <td width="96%" height="19" nowrap bgcolor="#E1204F" class="style2">&nbsp;<span class="style8">CUSTOMER ISSUE VIEW DETAILS</span></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="193" align="center" valign="top" nowrap><form action="vie-issuepriority.php" method="post" name="SubmitDepartment" id="SubmitDepartment">
      <table width="95%" height="21"  border="0" align="center" cellpadding="0" cellspacing="0" class="style4">
        <tr class="style6">
          <td width="29%" height="21" align="center" nowrap ><table width="100%" height="54"  border="0" align="center" cellpadding="0" cellspacing="0" class="style4" >
              <tr class="style6">
                <td width="29%" height="54" align="center" nowrap ><table width="100%" height="177"  border="0" align="center" cellpadding="0" cellspacing="0" class="style4" >
                    <tr class="style6">
                      <td height="13" align="center" nowrap >&nbsp;</td>
                    </tr>
                    <tr class="style6">
                      <td height="13" align="center" nowrap class="style7" >Please select searching criteria to search for a customer issue</td>
                    </tr>
                    <tr class="style6">
                      <td width="29%" height="21" align="center" nowrap ><p>
                          <select name="menu1" class="style46"  onChange="MM_jumpMenu('self',this,0)">
                             <option value="vie-issuepriority.php">Priority</option>
                            <option value="vie-issueproducttype.php">Product Type</option>
                            <option value="vie-issuereceivedmode.php">Mode of Receipt</option>
                            <option value="vie-issueall.php">All</option>
                            <option value="vie-issuestatus.php">Status</option>
                          </select>
                      </p></td>
                    </tr>
                    <tr class="style6">
                      <td height="13" align="center" nowrap ><strong>Please Select Issue Priority </strong></td>
                    </tr>
                    <tr class="style6">
                      <td height="13" align="center" nowrap >&nbsp;</td>
                    </tr>
                    <tr class="style6">
                      <td height="13" align="center" nowrap ><select name="ipriority" class="style46" id="ipriority">
                        <option value="Select Priority">Select Priority</option>
                        <option value="Low">Low</option>
                        <option value="Medium">Medium</option>
                        <option value="High">High</option>
                      </select></td>
                    </tr>
                    <tr class="style6">
                      <td height="13" align="center" nowrap >&nbsp;</td>
                    </tr>
                    <tr class="style6">
                      <td height="13" align="center" nowrap ><input name="Submit" type="submit" class="style46" value="Submit"></td>
                    </tr>
                    <tr class="style6">
                      <td height="13" align="center" nowrap >&nbsp;</td>
                    </tr>
                    <tr class="style6">
                      <td height="13" align="center" nowrap ><span class="style8">
                        <?php
    if (isset($_POST['Submit'])) 
{

              $ipriority = $_POST['ipriority'];

			  mysql_connect("localhost", "root", "") or die(mysql_error());
              mysql_select_db("bmpl_servicedeliveryportal") or die(mysql_error());  
              $query = mysql_query(" SELECT * FROM sd_issue WHERE iss_priority = '$ipriority' ORDER BY iss_code");                   
              $count = 1;
			  $result = $query;
		      if($result) 
		             {
			if(mysql_num_rows($result) != 0) 
			{
     echo "<table width=95%   border=0 align=center cellpadding=0 cellspacing=0 >
     <tr align=center bgcolor=#E1204F>
     <td width=20  height=25 nowrap style='border-top: 1px solid #7F9DB9; border-right: 1px solid #7F9DB9; border-bottom: 1px solid #7F9DB9; border-left: 1px solid #7F9DB9;'><span class=style2><span class=style3>S. #</td>
     <td width=60  height=25 nowrap style='border-top: 1px solid #7F9DB9; border-right: 1px solid #7F9DB9; border-bottom: 1px solid #7F9DB9;'><span class=style2><span class=style3>Issue Ref. #</span></td>
     <td width=60  height=25 nowrap style='border-top: 1px solid #7F9DB9; border-right: 1px solid #7F9DB9; border-bottom: 1px solid #7F9DB9;'><span class=style2><span class=style3>Customer Name</span></td>
	 <td width=60  height=25 nowrap style='border-top: 1px solid #7F9DB9; border-right: 1px solid #7F9DB9; border-bottom: 1px solid #7F9DB9;'><span class=style2><span class=style3>Product Type </span></span></td>
     <td width=60  height=25 nowrap style='border-top: 1px solid #7F9DB9; border-right: 1px solid #7F9DB9; border-bottom: 1px solid #7F9DB9;'><span class=style2><span class=style3>Received by </span></span></td>
	 <td width=60  height=25 nowrap style='border-top: 1px solid #7F9DB9; border-right: 1px solid #7F9DB9; border-bottom: 1px solid #7F9DB9;'><span class=style2><span class=style3>Mode of Receipts </span></span></td>
	 <td width=60  height=25 nowrap style='border-top: 1px solid #7F9DB9; border-right: 1px solid #7F9DB9; border-bottom: 1px solid #7F9DB9;'><span class=style2><span class=style3>Priority </span></span></td>
	 	 <td width=60  height=25 nowrap style='border-top: 1px solid #7F9DB9; border-right: 1px solid #7F9DB9; border-bottom: 1px solid #7F9DB9;'><span class=style2><span class=style3>Status </span></span></td>
	 <td width=60  height=25 nowrap style='border-top: 1px solid #7F9DB9; border-right: 1px solid #7F9DB9; border-bottom: 1px solid #7F9DB9;'><span class=style2><span class=style3>Department | Person Responsible </span></span></td>

     </tr>";


   while($row = mysql_fetch_array($query))
    { 
    echo "<tr align=center class=style4>";
	echo "<td  height=25 nowrap class=style1 style='border-bottom: 1px solid #7F9DB9; border-right: 1px solid #7F9DB9; border-left: 1px solid #7F9DB9;'><span class=style4> $count </span></td>";
	$a=$row['iss_reference_number'];
	echo "<td  height=25 nowrap class=style1 style='border-bottom: 1px solid #7F9DB9; border-right: 1px solid #7F9DB9'><span class=style4><a href='prg-viewall.php?iss_reference_number=".$a."'>".$a."</a></span></td>"; 
    echo '<td  height=25 nowrap class=style1 style="border-bottom: 1px solid #7F9DB9; border-right: 1px solid #7F9DB9"><span class=style4>'. $row["iss_customer_name"].'</span></td>';
	echo '<td  height=25 nowrap class=style1 style="border-bottom: 1px solid #7F9DB9; border-right: 1px solid #7F9DB9"><span class=style4>'. $row["iss_product_type"].'</span></td>';
	echo '<td  height=25 nowrap class=style1 style="border-bottom: 1px solid #7F9DB9; border-right: 1px solid #7F9DB9"><span class=style4>'. $row["iss_received_by"].'</span></td>';
	echo '<td  height=25 nowrap class=style1 style="border-bottom: 1px solid #7F9DB9; border-right: 1px solid #7F9DB9"><span class=style4>'. $row["iss_received_mode"].'</span></td>';	
	echo '<td  height=25 nowrap class=style1 style="border-bottom: 1px solid #7F9DB9; border-right: 1px solid #7F9DB9"><span class=style4>'. $row["iss_priority"].'</span></td>';	
		echo '<td  height=25 nowrap class=style1 style="border-bottom: 1px solid #7F9DB9; border-right: 1px solid #7F9DB9"><span class=style4>'. $row["iss_status"].'</span></td>';		
	echo '<td  height=25 nowrap class=style1 style="border-bottom: 1px solid #7F9DB9; border-right: 1px solid #7F9DB9"><span class=style4>'. $row["iss_responsible"].'</span></td>';    

	echo "</tr>"; 


	$count ++; 
	 }
	 echo "</table>";

	 }else
	 {
	 echo "<span class=style2><span class=style3>No customer issue  to display</span></span>";
	 }}}
     ?>
                      </span></td>
                    </tr>
                    <tr class="style6">
                      <td height="13" align="center" nowrap >&nbsp;</td>
                    </tr>
                    <tr class="style6">
                      <td height="13" align="center" nowrap ><span class="style44 ">
                        <input type=button onClick="location.href='index.php'" class='style46' value='Exit'>
                      </span></td>
                    </tr>
                    <tr class="style6">
                      <td height="13" align="center" nowrap ><div align="left"></div></td>
                    </tr>
                </table></td>
              </tr>
          </table></td>
        </tr>
      </table>
      <span class="style8"></span>
      <table width="100%" height="13"  border="0" align="center" cellpadding="0" cellspacing="0" class="style8" >
        <tr class="style6">
          
        </tr>
      </table>
      </form>    
    </td>
  </tr>
</table>
<p/>
</body>
</html>
