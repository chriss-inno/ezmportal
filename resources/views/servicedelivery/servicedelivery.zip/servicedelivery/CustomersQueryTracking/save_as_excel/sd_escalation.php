<?php

require_once ('sd_autoescalationreport.php');
 
$to = "rizwan.abdulkarim@bankm.com,av.raj@bankm.com,schola.mrina@bankm.com,sheena.sinare@bankm.com,vinesh.davda@bankm.com,adolph.mwakalinga@bankm.com,patrick.luyobya@bankm.com,nyabu.mbilima@bankm.com"; 
//$to = "ntinginya.musisa@bankm.com"; 
// The email you are sending to (example)
//$to = "ntinginya.musisa@bankm.com"; // The email you are sending to (example)
$from = "bankmportal@bankm.com"; // The email you are sending from (example)
$subject = "DAILY LOG OF CUSTOMER ISSUES"; // The Subject of the email
$fileatt = "DAILY LOG OF CUSTOMER ISSUES.xls"; // Path to the file (example)
$fileatt_name = "DAILY LOG OF CUSTOMER ISSUES.xls"; // Filename that will be used for the file as the attachment
$file = fopen($fileatt,'rb');
$data = fread($file,filesize($fileatt));
fclose($file);
//define the headers we want passed. Note that they are separated with \r\n
$headers = "From: bankmportal@bankm.com\r\nReply-To: support@bankm.com";
//add boundary string and mime type specification
$headers .= "\r\nContent-Type: multipart/mixed; boundary=\"PHP-mixed-".$random_hash."\"";
//read the atachment file contents into a string,
//encode it with MIME base64,
//and split it into smaller chunks
$attachment =chunk_split(base64_encode($data));
//define the body of the message.
ob_start(); //Turn on output buffering
?>
--PHP-mixed-<?php echo $random_hash; ?> 
Content-Type: multipart/alternative; boundary="PHP-alt-<?php echo $random_hash; ?>"

--PHP-alt-<?php echo $random_hash; ?> 
Content-Type: text/plain; charset="iso-8859-1"
Content-Transfer-Encoding: 7bit

Hello World!!!
This is simple text email message.

--PHP-alt-<?php echo $random_hash; ?> 
Content-Type: text/html; charset="iso-8859-1"
Content-Transfer-Encoding: 7bit

<style type="text/css">
<!--
.style2 {	color: #FFFFFF;
	font-weight: bold;
}
.style3 {font-size: 11px; font-family: tahoma;}
.style4 {
	font-family: tahoma;
	font-size: 12px;
	font-family: tahoma;
	color: #0E3793
}
.style5 {color: #0E3793}
.style6 {font-size: 12px}
.style7 {
	color: #0E3793;
	font-size: 12px;
	font-weight: bold;
}
-->
</style>
          <p align="left" class="style5"><span class="style5" style="font-family: tahoma; font-size: 15px;">Dear Team,  </br>    </br>     
           Below table has summary of daily issues logged on the Service Delivery Customer Issue Tracking Portal. </br></br>
		
		   </span>
		   
		   
		   <?php
		   
		  
		   
$con = mysql_connect("localhost","root","");
if (!$con) {die('Could not connect: ' . mysql_error());}
mysql_select_db("bmpl_servicedeliveryportal") or die(mysql_error());
	 
$date = date("Y-m-d", time()); 	
$time = date("H", time()); 
            	
  mysql_connect("localhost", "root", "") or die(mysql_error());
  mysql_select_db("bmpl_servicedeliveryportal") or die(mysql_error());  
            
             	
			 
			  $count = 1;
			  $query = mysql_query("SELECT * FROM sd_issue  WHERE  iss_status <> 'Resolved'  or iss_resolution_date = '$date' order by iss_reference_number");
			  $result = $query;
		      if($result) 
		             {
			if(mysql_num_rows($result) != 0) 
			{
     echo "<table width=95%   border=0 align=center cellpadding=0 cellspacing=0 >
     <tr align=center bgcolor=#E1204F>
     <td width=20  height=25 nowrap style='border-top: 1px solid #7F9DB9; border-right: 1px solid #7F9DB9; border-bottom: 1px solid #7F9DB9; border-left: 1px solid #7F9DB9;'><span class=style2><span class=style3>ISS. S.NO.</td>
     <td width=60  height=25 nowrap style='border-top: 1px solid #7F9DB9; border-right: 1px solid #7F9DB9; border-bottom: 1px solid #7F9DB9;'><span class=style2><span class=style3>ISS. REFERENCE NO.</span></td>
     <td width=60  height=25 nowrap style='border-top: 1px solid #7F9DB9; border-right: 1px solid #7F9DB9; border-bottom: 1px solid #7F9DB9;'><span class=style2><span class=style3>ISS. CUSTOMER NAME</span></span></td>
	 <td width=60  height=25 nowrap style='border-top: 1px solid #7F9DB9; border-right: 1px solid #7F9DB9; border-bottom: 1px solid #7F9DB9;'><span class=style2><span class=style3>ISS. PRODUCT TYPE</span></span></td>
	 <td width=60  height=25 nowrap style='border-top: 1px solid #7F9DB9; border-right: 1px solid #7F9DB9; border-bottom: 1px solid #7F9DB9;'><span class=style2><span class=style3>ISS. STATUS</span></span></td>	
	 <td width=60  height=25 nowrap style='border-top: 1px solid #7F9DB9; border-right: 1px solid #7F9DB9; border-bottom: 1px solid #7F9DB9;'><span class=style2><span class=style3>ISS. OPENED DATE</span></span></td>
     <td width=60  height=25 nowrap style='border-top: 1px solid #7F9DB9; border-right: 1px solid #7F9DB9; border-bottom: 1px solid #7F9DB9;'><span class=style2><span class=style3>ISS. CLOSED DATE</span></span></td>
	 <td width=60  height=25 nowrap style='border-top: 1px solid #7F9DB9; border-right: 1px solid #7F9DB9; border-bottom: 1px solid #7F9DB9;'><span class=style2><span class=style3>TAT </span></span></td>

     </tr>";


   while($row = mysql_fetch_array($query))
    { 
    echo "<tr align=center class=style4>";
	echo "<td  height=25 nowrap class=style4 style='border-bottom: 1px solid #7F9DB9; border-right: 1px solid #7F9DB9; border-left: 1px solid #7F9DB9;'><span class=style4>$count </span></td>";
	$a=$row['iss_reference_number'];
	echo "<td  height=25 nowrap class=style4 style='border-bottom: 1px solid #7F9DB9; border-right: 1px solid #7F9DB9'><span class=style4>".$a."</span></td>"; 
	$od =$row['iss_reported_date'];
	$oc =$row['iss_resolution_date'];
	echo '<td  height=25 nowrap class=style4 style="border-bottom: 1px solid #7F9DB9; border-right: 1px solid #7F9DB9"><span class=style4>'. $row["iss_customer_name"].'</span></td>';
	echo '<td  height=25 nowrap class=style4 style="border-bottom: 1px solid #7F9DB9; border-right: 1px solid #7F9DB9"><span class=style4>'. $row["iss_product_type"].'</span></td>';	
    echo '<td  height=25 nowrap class=style4 style="border-bottom: 1px solid #7F9DB9; border-right: 1px solid #7F9DB9"><span class=style4>'. $row["iss_status"].'</span></td>';
	echo '<td  height=25 nowrap class=style4 style="border-bottom: 1px solid #7F9DB9; border-right: 1px solid #7F9DB9"><span class=style4>'. $row["iss_reported_date"].'</span></td>';	
	
	
	if ( $oc == 0000-00-00 )
	{
	$CLOSED = "NOT CLOSED";
	}
	else 
	{
	 $CLOSED = $row['iss_resolution_date']; 
	}
	echo '<td  height=25 nowrap class=style4 style="border-bottom: 1px solid #7F9DB9; border-right: 1px solid #7F9DB9"><span class=style4>'. "$CLOSED".'</span></td>';		
	
	
	
	 if ( $oc <> "")
	 
		$TAT1 = '1';
		
    if ( $oc <> "$date")
	{
	$TAT1 = floor((strtotime($date) - strtotime($od))/86400);
	} 

	
	
	echo '<td  height=25 nowrap class=style4 style="border-bottom: 1px solid #7F9DB9; border-right: 1px solid #7F9DB9"><span class=style4>'."$TAT1".'</span></td>';    

	echo "</tr>"; 


	$count ++; 
	 }
 echo "</table>";
}
}
?>
           <p align="left" class="style5"><span class="style5" style="font-family: tahoma; font-size: 15px;">
		   Detailed report of issues description is attached for reference.</br></br>
		   </span>
		   
		   
--PHP-alt-<?php echo $random_hash; ?>--

--PHP-mixed-<?php echo $random_hash; ?> 
Content-Type: application/xls; name="DAILY LOG OF CUSTOMER ISSUES.xls" 
Content-Transfer-Encoding: base64 
Content-Disposition: attachment 

<?php echo $attachment; ?>
--PHP-mixed-<?php echo $random_hash; ?>--

<?php
//copy current buffer contents into $message variable and delete current output buffer
$message = ob_get_clean();
//send the email
$mail_sent = @mail( $to, $subject, $message, $headers );
//if the message is sent successfully print "Mail sent". Otherwise print "Mail failed"

?>

