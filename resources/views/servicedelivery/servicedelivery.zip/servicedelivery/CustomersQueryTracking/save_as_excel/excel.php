<html>
<head>
<script language="javascript">
function download()
{
	window.location='DAILY LOG OF CUSTOMER ISSUES.xls';
}
</script>
<style type="text/css">
<!--
.style1 {font-family: tahoma;
	font-size: 12px;
	color: #FFFFFF;
}
.style11 {font-family: tahoma; font-size: 11px; color: #ffffff; }
.style19 {font-size: 11px; font-family: tahoma; color: #FFFFFF; font-weight: bold; }
.style2 {	color: #0E3793;
	font-weight: bold;
}
.style4 {	color: #FFFFFF;
	font-family: tahoma;
	font-size: 11px;
}
.style6 {font-size: 11px}
.style8 {color: #FFFFFF; font-family: tahoma; font-size: 11px; }
body {
	background-image: url(../../../images/backgrounds/pagebg.png);
}
a:link {
	color: #FFFFFF;
	text-decoration: none;
}
a:visited {
	text-decoration: none;
	color: #FFFFFF;
}
a:hover {
	text-decoration: none;
	color: #FF0000;
}
a:active {
	text-decoration: none;
	color: #FFFFFF;
}
.style47 {
	font-size: 11px;
	font-weight: bold;
}
.style46 {	color: #0E3793;
	font-family: tahoma;
	font-size: 11px;
}
-->
</style>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"></head>
<body>
<table width="100%" border="0" cellpadding="5" cellspacing="0">
  <tr>
    <td></td>
  </tr>
</table>
<table width="100%"  border="0" align="center" cellpadding="0" cellspacing="0" style="border-bottom: 1px solid #7F9DB9; border-left: 1px solid #7F9DB9; border-right: 1px solid #7F9DB9; border-top: 1px solid #7F9DB9; ">
  <tr>
    <td width="95%" height="20" nowrap><table width="100%" height="20"  border="0" align="center" cellpadding="0" cellspacing="0" style="border-bottom: 1px solid #7F9DB9;">
        <tr >
          <td width="96%" height="19" nowrap bgcolor="#E1204F" class="style2">&nbsp;<span class="style8">GENERATED REPORT DOWNLOAD </span></td>
        </tr>
    </table></td>
  </tr>
  <tr>
    <td height="125" align="center" valign="top" nowrap><form action="../index.php" method="post" name="SubmitDepartment" id="SubmitDepartment">
        <table width="95%" height="21"  border="0" align="center" cellpadding="0" cellspacing="0" class="style4">
          <tr class="style6">
            <td width="29%" height="21" align="center" nowrap ><table width="100%" height="54"  border="0" align="center" cellpadding="0" cellspacing="0" class="style4" >
                <tr class="style6">
                  <td width="29%" height="54" align="center" nowrap ><table width="100%" height="78"  border="0" align="center" cellpadding="0" cellspacing="0" class="style4" >
                      <tr class="style6">
                        <td width="29%" height="13" align="center" nowrap ><span class="style11"><strong><span class="style19"> <strong>
                        </strong> </span></strong></span></td>
                      </tr>
                      <tr class="style6">
                        <td height="13" align="center" nowrap >&nbsp;</td>
                      </tr>
                      <tr class="style6">
                        <td height="13" align="center" nowrap ><a href="javascript:void(0);" class="style47" onClick="download();">Download Excel Report</a></td>
                      </tr>
                      <tr class="style6">
                        <td height="13" align="center" nowrap ><span class="style44 ">
                          <?php


$istatus   = $_POST['istatus'];
$idatefrom = $_POST['idatefrom'];
$idateto   = $_POST['idateto'];

mysql_connect("localhost","root","");
mysql_select_db("bmpl_servicedeliveryportal");
require_once ('days.php');
$day=new Days;

require_once("excelwriter.class.php");

$excel=new ExcelWriter("DAILY LOG OF CUSTOMER ISSUES.xls");
if($excel==false)	
echo $excel->error;

$myArr=array("ISS.CODE", "ISS.REFERENCE NUMBER", "ISS.REPORTED DATE", "ISS.REPORTED TIME", "ISS.INPUTER", "ISS.CUSTOMER NAME", "ISS.CON. PERSON", "ISS.PRODUCT TYPE", "ISS.RECEIVED BY", "ISS.RECEIVED MODE", "ISS.STATUS", "ISS.DESCRIPTION", "ISS.ROOT CAUSED", "ISS.RESPONSIBLE", "ISS.REMARKS", "ISS.RE.DATE", "ISS.RE.TIME", "TAT");
$excel->writeLine($myArr);

if ( $istatus == "All" && $idatefrom == "All" && ($idateto == "All" or $idateto <> "All") )
  {
  $qry=mysql_query("SELECT * FROM sd_issue"); 
  }

if ( $istatus <> "All" && $idatefrom == "All" && ($idateto == "All" or $idateto <> "All") )
  {
  $qry=mysql_query("SELECT * FROM sd_issue where iss_status = '$istatus' "); 
  }

if ( $istatus == "All" && $idatefrom <> "All" && $idateto == "All" )
  {
  $qry=mysql_query("SELECT * FROM sd_issue where iss_reported_date = '$idatefrom' "); 
  }

if ( $istatus == "All" && $idatefrom <> "All" && $idateto <> "All" )
  {
  $qry=mysql_query("SELECT * FROM sd_issue where iss_reported_date between '$idatefrom' AND '$idateto'  "); 
  }

if ( $istatus <> "All" && $idatefrom <> "All" && $idateto <> "All" )
  {
  $qry=mysql_query("SELECT * FROM sd_issue where iss_status = '$istatus' AND iss_reported_date between '$idatefrom' AND '$idateto'  "); 
  }




if(mysql_num_rows($qry)>0)
{
	$i=1;
	while($res=mysql_fetch_array($qry))
	{
	
		if($res['iss_resolution_date']==0000-00-00)
		{
		$myArr=array($i, $res['iss_reference_number'], $res['iss_reported_date'], $res['iss_reported_time'], $res['iss_inputed_by'], $res['iss_customer_name'],  $res['iss_contact_person'] , $res['iss_product_type'], $res['iss_received_by'], $res['iss_received_mode'], $res['iss_status'], $res['iss_issue_description'], $res['iss_root_caused'], $res['iss_responsible'], $res['iss_note'], $res['iss_resolution_date'], $res['iss_resolution_time'], 'NOT CLOSED');
		}
		else
		{
		$days=$day->calculateTime($res['iss_resolution_date'],$res['iss_reported_date']);
		$myArr=array($i, $res['iss_reference_number'], $res['iss_reported_date'], $res['iss_reported_time'], $res['iss_inputed_by'], $res['iss_customer_name'],  $res['iss_contact_person'] , $res['iss_product_type'], $res['iss_received_by'], $res['iss_received_mode'], $res['iss_status'], $res['iss_issue_description'], $res['iss_root_caused'], $res['iss_responsible'], $res['iss_note'], $res['iss_resolution_date'], $res['iss_resolution_time'],$days+1);
		}
		$excel->writeLine($myArr);
		$i++;
	}
}
?> 
                        </span></td>
                      </tr>
                      <tr class="style6">
                        <td height="13" align="center" nowrap >&nbsp;</td>
                      </tr>
                      <tr class="style6">
                        <td height="13" align="center" nowrap ><div align="center"><span class="style1"><span class="style44 ">
                          <input name="Submit" type=submit class='style46' onClick="location.href='index.php'" value='Exit'>
                        </span></span></div></td>
                      </tr>
                  </table></td>
                </tr>
            </table></td>
          </tr>
        </table>
        <span class="style8"></span>
    </form></td>
  </tr>
</table>
<h1 align="center">&nbsp;</h1>
</body>
</html>