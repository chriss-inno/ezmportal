<html>
<head>
<style type="text/css">
<!--
.style1 {font-family: tahoma;
	font-size: 12px;
	color: #FFFFFF;
}
.style11 {font-family: tahoma; font-size: 11px; color: #ffffff; }
.style19 {font-size: 11px; font-family: tahoma; color: #FFFFFF; font-weight: bold; }
.style2 {color: #0E3793;
	font-weight: bold;
}
.style4 {color: #FFFFFF;
	font-family: tahoma;
	font-size: 11px;
}
.style46 {color: #0E3793;
	font-family: tahoma;
	font-size: 11px;
}
.style6 {font-size: 11px}
.style8 {color: #FFFFFF; font-family: tahoma; font-size: 11px; }
body {
	background-image: url(../../../images/backgrounds/pagebg.png);
}
a:link {
	text-decoration: none;
	color: #FFFFFF;
}
a:visited {
	text-decoration: none;
	color: #FFFFFF;
}
a:hover {
	text-decoration: none;
	color: #FF0000;
}
a:active {
	text-decoration: none;
	color: #FFFFFF;
}
.style48 {font-family: tahoma; font-size: 11px; color: #ffffff; font-weight: bold; }
-->
</style>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"></head>
<body>
<script language="javascript">
function download()
{
	window.location='DAILY LOG OF CUSTOMER ISSUES.xls';
}
</script>
<table width="100%" border="0" cellpadding="5" cellspacing="0">
  <tr>
    <td></td>
  </tr>
</table>
<table width="100%"  border="0" align="center" cellpadding="0" cellspacing="0" style="border-bottom: 1px solid #7F9DB9; border-left: 1px solid #7F9DB9; border-right: 1px solid #7F9DB9; border-top: 1px solid #7F9DB9; ">
  <tr>
    <td width="95%" height="20" nowrap><table width="100%" height="20"  border="0" align="center" cellpadding="0" cellspacing="0" style="border-bottom: 1px solid #7F9DB9;">
        <tr >
          <td width="96%" height="19" nowrap bgcolor="#E1204F" class="style2">&nbsp;<span class="style8">GENERATED REPORT DOWNLOAD </span></td>
        </tr>
    </table></td>
  </tr>
  <tr>
    <td height="125" align="center" valign="top" nowrap><form action="../index.php" method="post" name="SubmitDepartment" id="SubmitDepartment">
        <table width="95%" height="21"  border="0" align="center" cellpadding="0" cellspacing="0" class="style4">
          <tr class="style6">
            <td width="29%" height="21" align="center" nowrap ><table width="100%" height="54"  border="0" align="center" cellpadding="0" cellspacing="0" class="style4" >
                <tr class="style6">
                  <td width="29%" height="54" align="center" nowrap ><table width="100%" height="78"  border="0" align="center" cellpadding="0" cellspacing="0" class="style4" >
                      <tr class="style6">
                        <td width="29%" height="13" align="center" nowrap ><span class="style11"><strong><span class="style19"> <strong> </strong> </span></strong></span></td>
                      </tr>
                      <tr class="style6">
                        <td height="13" align="center" nowrap >&nbsp;</td>
                      </tr>
                      <tr class="style6">
                        <td height="13" align="center" nowrap >&nbsp;</td>
                      </tr>
                      <tr class="style6">
                        <td height="13" align="center" nowrap ><span class="style44 ">
                          <?php
require_once ('days.php');
$day=new Days;

$date = date("Y-m-d", time()); 	
$time = date("H", time()); 




mysql_connect("localhost","root","");
mysql_select_db("bmpl_servicedeliveryportal");
require_once("excelwriter.class.php");






$ict=new ExcelWriter('DAILY LOG OF CUSTOMER ISSUES.xls');
if($ict==false)	
echo $ict->error;

$myArr=array("ISS.CODE", "ISS.REFERENCE NUMBER", "ISS.REPORTED DATE", "ISS.CUSTOMER NAME", "ISS.PRODUCT TYPE", "ISS.STATUS", "ISS.DESCRIPTION", "ISS.ROOT CAUSED", "ISS.RESPONSIBLE", "ISS.REMARKS", "ISS.CLOSED.DATE",  "TAT");
$ict->writeLine($myArr);

$qry=mysql_query("SELECT * FROM sd_issue  WHERE  iss_status <> 'Resolved'  or iss_resolution_date = '$date' ");

if(mysql_num_rows($qry)>0)
{
	$i=1;
	while($res=mysql_fetch_array($qry))
	{
	   
	        $today = date("Y-m-d", time());
			$TAT=$day->calculateTime($res['iss_reported_date'],$res['iss_resolution_date']);	 
	   
	        if ($res['iss_resolution_date'] === "0000-00-00" )
	   		{
            $TAT= "NOT CLOSED";	 
		    }

	    
		 $myArr=array($i,$res['iss_reference_number'],$res['iss_reported_date'],$res['iss_customer_name'],$res['iss_product_type'],$res['iss_status'],$res['iss_issue_description'],$res['iss_root_caused'],$res['iss_responsible'],$res['iss_note'],$res['iss_resolution_date'],$TAT);
		
		$ict->writeLine($myArr);
		$i++;
	}




}

?>
                        </span></td>
                      </tr>
                      <tr class="style6">
                        <td height="13" align="center" nowrap >&nbsp;</td>
                      </tr>
                      <tr class="style6">
                        <td height="13" align="center" nowrap ><div align="center"><span class="style1"><span class="style44 ">
                        </span></span></div></td>
                      </tr>
                  </table></td>
                </tr>
            </table></td>
          </tr>
        </table>
        <span class="style8"></span>
    </form></td>
  </tr>
</table>
<h6 align="center">&nbsp;</h6>
<h6 align="center">&nbsp;</h6>
</body>
</html>