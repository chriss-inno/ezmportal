<?php
session_start();
$loginUser_id = $_SESSION['SESS_USER_ID'];
require_once('../../config/auth_content.php');

$user_id       = $_SESSION['SESS_USER_ID'];
$log_ipaddress = $_SERVER['REMOTE_ADDR']; 
$log_compuser  = gethostbyaddr($_SERVER['REMOTE_ADDR']);
$log_datetime  = date("d/m/y : H:i:s", time());
$log_activity  = "SDCalenderYear2012Opened";
$log_comment   = "SDSWIFTCOPY";
mysql_connect("localhost","root",""); 
mysql_select_db("bmpl_system") or die("Unable to select database");
@mysql_query("INSERT INTO sys_log(user_id, log_datetime, log_activity, log_comment, log_ipaddress, log_compuser)
VALUES('$user_id','$log_datetime','$log_activity','$log_comment','$log_ipaddress', '$log_compuser')");	


?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Report Calender -2011</title>
<style type="text/css">
<!--
.style2 {
	color: #0E3793;
	font-weight: bold;
}
.style3 {
	font-size: 11px;
	font-family: tahoma;
	color: #FFFFFF;
}
a:link {
	color: #FFFFFF;
	text-decoration: none;
}
a:visited {
	color: #FFFFFF;
	text-decoration: none;
}
a:hover {
	color: #FF0000;
	text-decoration: none;
}
a:active {
	color: #FFFFFF;
	text-decoration: none;
}
body {
	background-image: url(../images/backgrounds/pagebg.png);
}
.style6 {font-size: 11px; font-family: tahoma; color: #FFFFFF; font-weight: bold; }
-->
</style>
</head>

<body>
<table width="100%" border="0" cellpadding="5" cellspacing="0">
  <tr>
    <td></td>
  </tr>
</table>
<table width="100%"  border="0" align="center" cellpadding="0" cellspacing="0" style="border-bottom: 1px solid #7F9DB9; border-left: 1px solid #7F9DB9; border-right: 1px solid #7F9DB9; border-top: 1px solid #7F9DB9; ">
  <tr>
    <td width="95%" height="20" nowrap ><table width="100%" height="20"  border="0" align="center" cellpadding="0" cellspacing="0" style="border-bottom: 1px solid #7F9DB9;">
      <tr >
        <td width="96%" height="19" nowrap bgcolor="#E1204F"><span class="style2">&nbsp;<span class="style3">SWIFT COPY CALENDER - 2012</span></span></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="19" valign="top" nowrap><div align="center">
	<span class="style6">
	 <?php
     $con = mysql_connect("localhost","root","");
     if (!$con) {die('Could not connect: ' . mysql_error());}
     mysql_select_db("bmpl_system") or die(mysql_error());
			  
			  
	 $query = mysql_query(" SELECT * FROM sys_user WHERE usr_id = '$loginUser_id' ");  
	 while($row = mysql_fetch_array($query))
     {
	 $deprtmnt = $row['usr_department'];
     }
	 
	 $queryl = mysql_query(" SELECT * FROM sys_user_right WHERE usr_id = '$loginUser_id' and rgt_name = 'SWIFTCOPYVIEW' ");  
	 while($row = mysql_fetch_array($queryl))
     {
	 $rgtname = $row['rgt_name'];
     }
	 
	 if ($rgtname != "SWIFTCOPYVIEW")
	 
	 {
 include_once 'unuthorized.php';	
	  exit;
	 }?></span><br/>
        <table width="1068" border="0" align="center" cellpadding="5" cellspacing="0" class="style1">
          <tr>
            <td width="38"><a href="calender2011.php" target="mainFrame" class="style19"><img src="../images/icons/back.jpg" width="38" height="30" border="0"></a></td>
            <td width="300"><table width="300" height="20" border="0" cellpadding="0" cellspacing="0">
                <tr>
                  <td width="414" height="15" bgcolor="#E1204F" class="style14"><div align="left"><strong class="style3">January</strong></div></td>
                </tr>
              </table>
                <table width="300" border="0" cellpadding="5" cellspacing="0" bordercolor="#999999">
                  <tr class="style3">
                    <td width="414" class="style15">Sun</td>
                    <td width="414" class="style13">Mon</td>
                    <td width="414" class="style13">Tue</td>
                    <td width="414" class="style13">Wed</td>
                    <td width="414" class="style13">Thu</td>
                    <td width="414" class="style13">Fri</td>
                    <td width="414" class="style15">Sat</td>
                  </tr>
                  <tr class="style3">
                    <td class="style15"><a href="2012/jan/01/dct-selectmenu.php?date=01-JAN-2012">1</a></td>
                    <td class="style13">2</td>
                    <td class="style13">3</td>
                    <td class="style13">4</td>
                    <td class="style13">5</td>
                    <td class="style13">6</td>
                    <td class="style15">7</td>
                  </tr>
                  <tr class="style3">
                    <td class="style15">8</td>
                    <td class="style13">9</td>
                    <td class="style13">10</td>
                    <td class="style13">11</td>
                    <td class="style13">12</td>
                    <td class="style13">13</td>
                    <td class="style15">14</td>
                  </tr>
                  <tr class="style3">
                    <td class="style15">15</td>
                    <td class="style13">16</td>
                    <td class="style13">17</td>
                    <td class="style13"><a href="documentserver/2012/jan/18/dct-selectmenu.php?date=JAN-18">18</a></td>
                    <td class="style13">19</td>
                    <td class="style13">20</td>
                    <td class="style15">21</td>
                  </tr>
                  <tr class="style3">
                    <td class="style15">22</td>
                    <td class="style13">23</td>
                    <td class="style13">24</td>
                    <td class="style13">25</td>
                    <td class="style13">26</td>
                    <td class="style13">27</td>
                    <td class="style15">28</td>
                  </tr>
                  <tr class="style3">
                    <td class="style15">29</td>
                    <td class="style13">30</td>
                    <td class="style13">31</td>
                    <td class="style13">&nbsp;</td>
                    <td class="style13">&nbsp;</td>
                    <td class="style13">&nbsp;</td>
                    <td>&nbsp;</td>
                  </tr>
              </table></td>
            <td width="13">&nbsp;</td>
            <td width="300"><table width="300" height="20" border="0" cellpadding="0" cellspacing="0">
                <tr>
                  <td width="414" height="13" bgcolor="#E1204F" class="style14"><div align="left"><strong class="style3">February</strong></div></td>
                </tr>
              </table>
                <table width="300" border="0" cellpadding="5" cellspacing="0" bordercolor="#999999">
                  <tr class="style3">
                    <td width="414" class="style15">Sun</td>
                    <td width="414" class="style13">Mon</td>
                    <td width="414" class="style13">Tue</td>
                    <td width="414" class="style13">Wed</td>
                    <td width="414" class="style13">Thu</td>
                    <td width="414" class="style13">Fri</td>
                    <td width="414" class="style15">Sat</td>
                  </tr>
                  <tr class="style3">
                    <td>&nbsp;</td>
                    <td class="style13">&nbsp;</td>
                    <td class="style13">&nbsp;</td>
                    <td class="style13">1</td>
                    <td class="style13">2</td>
                    <td class="style13">3</td>
                    <td class="style15">4</td>
                  </tr>
                  <tr class="style3">
                    <td class="style15">5</td>
                    <td class="style13">6</td>
                    <td class="style13">7</td>
                    <td class="style13">8</td>
                    <td class="style13">9</td>
                    <td class="style13">10</td>
                    <td class="style15">11</td>
                  </tr>
                  <tr class="style3">
                    <td class="style15">12</td>
                    <td class="style13">13</td>
                    <td class="style13">14</td>
                    <td class="style13">15</td>
                    <td class="style13">16</td>
                    <td class="style13">17</td>
                    <td class="style15">18</td>
                  </tr>
                  <tr class="style3">
                    <td class="style15">19</td>
                    <td class="style13">20</td>
                    <td class="style13">21</td>
                    <td class="style13">22</td>
                    <td class="style13">23</td>
                    <td class="style13">24</td>
                    <td class="style15">25</td>
                  </tr>
                  <tr class="style3">
                    <td class="style15">26</td>
                    <td class="style13">27</td>
                    <td class="style13">28</td>
                    <td class="style13">29</td>
                    <td>&nbsp;</td>
                    <td class="style13">&nbsp;</td>
                    <td>&nbsp;</td>
                  </tr>
              </table></td>
            <td width="7">&nbsp;</td>
            <td width="300"><table width="300" height="20" border="0" cellpadding="0" cellspacing="0">
                <tr>
                  <td width="414" height="13" bgcolor="#E1204F" class="style14"><div align="left"><strong class="style3">March</strong></div></td>
                </tr>
              </table>
                <table width="300" border="0" cellpadding="5" cellspacing="0" bordercolor="#999999">
                  <tr class="style3">
                    <td width="414" class="style15">Sun</td>
                    <td width="414" class="style13">Mon</td>
                    <td width="414" class="style13">Tue</td>
                    <td width="414" class="style13">Wed</td>
                    <td width="414" class="style13">Thu</td>
                    <td width="414" class="style13">Fri</td>
                    <td width="414" class="style15">Sat</td>
                  </tr>
                  <tr class="style3">
                    <td>&nbsp;</td>
                    <td class="style13">&nbsp;</td>
                    <td class="style13">&nbsp;</td>
                    <td class="style13">&nbsp;</td>
                    <td class="style13"><a href="reports/2011/Sep/01/userauthentication.php">1</a></td>
                    <td class="style13"><a href="reports/2011/Sep/02/userauthentication.php">2</a></td>
                    <td class="style15"><a href="reports/2011/Sep/03/userauthentication.php">3</a></td>
                  </tr>
                  <tr class="style3">
                    <td class="style15"><a href="reports/2011/Sep/04/userauthentication.php">4</a></td>
                    <td class="style13"><a href="reports/2011/Sep/05/userauthentication.php">5</a></td>
                    <td><a href="reports/2011/Sep/06/userauthentication.php"><span class="style13">6</span></a></td>
                    <td class="style13"><a href="reports/2011/Sep/07/userauthentication.php">7</a></td>
                    <td class="style13"><a href="reports/2011/Sep/08/userauthentication.php">8</a></td>
                    <td class="style13"><a href="reports/2011/Sep/09/userauthentication.php">9</a></td>
                    <td class="style15"><a href="reports/2011/Sep/10/userauthentication.php">10</a></td>
                  </tr>
                  <tr class="style3">
                    <td class="style15"><a href="reports/2011/Sep/11/userauthentication.php">11</a></td>
                    <td class="style13"><a href="reports/2011/Sep/12/userauthentication.php">12</a></td>
                    <td class="style13"><a href="reports/2011/Sep/13/userauthentication.php">13</a></td>
                    <td class="style13"><a href="reports/2011/Sep/14/userauthentication.php">14</a></td>
                    <td class="style13"><a href="reports/2011/Sep/15/userauthentication.php">15</a></td>
                    <td class="style13"><a href="reports/2011/Sep/16/userauthentication.php">16</a></td>
                    <td class="style15"><a href="reports/2011/Sep/17/userauthentication.php">17</a></td>
                  </tr>
                  <tr class="style3">
                    <td class="style15"><a href="reports/2011/Sep/18/userauthentication.php">18</a></td>
                    <td class="style13"><a href="reports/2011/Sep/19/userauthentication.php">19</a></td>
                    <td class="style13"><a href="reports/2011/Sep/20/userauthentication.php">20</a></td>
                    <td class="style13"><a href="reports/2011/Sep/21/userauthentication.php">21</a></td>
                    <td class="style13"><a href="reports/2011/Sep/22/userauthentication.php">22</a></td>
                    <td class="style13"><a href="reports/2011/Sep/23/userauthentication.php">23</a></td>
                    <td class="style15"><a href="reports/2011/Sep/24/userauthentication.php">24</a></td>
                  </tr>
                  <tr class="style3">
                    <td class="style15"><a href="reports/2011/Sep/25/userauthentication.php">25</a></td>
                    <td class="style13"><a href="reports/2011/Sep/26/userauthentication.php">26</a></td>
                    <td class="style13"><a href="reports/2011/Sep/27/userauthentication.php">27</a></td>
                    <td class="style13"><a href="reports/2011/Sep/28/userauthentication.php">28</a></td>
                    <td class="style13"><a href="reports/2011/Sep/29/userauthentication.php">29</a></td>
                    <td class="style13"><a href="reports/2011/Sep/30/userauthentication.php?date=SEP-30">30</a></td>
                    <td>31</td>
                  </tr>
              </table></td>
            <td width="40">&nbsp;</td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td><table width="300" height="20" border="0" cellpadding="0" cellspacing="0">
                <tr>
                  <td width="414" height="13" bgcolor="#E1204F" class="style14"><div align="left"><strong class="style3">April</strong></div></td>
                </tr>
              </table>
                <table width="300" border="0" cellpadding="5" cellspacing="0" bordercolor="#999999">
                  <tr class="style3">
                    <td width="414" class="style15">Sun</td>
                    <td width="414" class="style13">Mon</td>
                    <td width="414" class="style13">Tue</td>
                    <td width="414" class="style13">Wed</td>
                    <td width="414" class="style13">Thu</td>
                    <td width="414" class="style13">Fri</td>
                    <td width="414" class="style15">Sat</td>
                  </tr>
                  <tr class="style3">
                    <td class="style15">1</td>
                    <td class="style13">2</td>
                    <td class="style13">3</td>
                    <td class="style13">4</td>
                    <td class="style13">5</td>
                    <td class="style13">6</td>
                    <td class="style15">7</td>
                  </tr>
                  <tr class="style3">
                    <td class="style15">8</td>
                    <td class="style13">9</td>
                    <td class="style13">10</td>
                    <td class="style13">11</td>
                    <td class="style13">12</td>
                    <td class="style13">13</td>
                    <td class="style15">14</td>
                  </tr>
                  <tr class="style3">
                    <td class="style15">15</td>
                    <td class="style13">16</td>
                    <td class="style13">17</td>
                    <td class="style13">18</td>
                    <td class="style13">19</td>
                    <td class="style13">20</td>
                    <td class="style15">21</td>
                  </tr>
                  <tr class="style3">
                    <td class="style15">22</td>
                    <td class="style13">23</td>
                    <td class="style13">24</td>
                    <td class="style13">25</td>
                    <td class="style13">26</td>
                    <td class="style13">27</td>
                    <td class="style15">28</td>
                  </tr>
                  <tr class="style3">
                    <td class="style15">29</td>
                    <td class="style13">30</td>
                    <td>&nbsp;</td>
                    <td class="style13">&nbsp;</td>
                    <td class="style13">&nbsp;</td>
                    <td class="style13">&nbsp;</td>
                    <td>&nbsp;</td>
                  </tr>
              </table></td>
            <td>&nbsp;</td>
            <td><table width="300" height="20" border="0" cellpadding="0" cellspacing="0">
                <tr>
                  <td width="414" height="13" bgcolor="#E1204F" class="style14"><div align="left"><strong class="style3">May</strong></div></td>
                </tr>
              </table>
                <table width="300" border="0" cellpadding="5" cellspacing="0" bordercolor="#999999">
                  <tr class="style3">
                    <td width="414" class="style15">Sun</td>
                    <td width="414" class="style13">Mon</td>
                    <td width="414" class="style13">Tue</td>
                    <td width="414" class="style13">Wed</td>
                    <td width="414" class="style13">Thu</td>
                    <td width="414" class="style13">Fri</td>
                    <td width="414" class="style15">Sat</td>
                  </tr>
                  <tr class="style3">
                    <td class="style15">&nbsp;</td>
                    <td>&nbsp;</td>
                    <td class="style13"><a href="reports/2011/Nov/01/userauthentication.php?date=NOV-01">1</a></td>
                    <td><a href="reports/2011/Nov/02/userauthentication.php?date=NOV-02"><span class="style13">2</span></a></td>
                    <td class="style13"><a href="reports/2011/Nov/03/userauthentication.php?date=NOV-03">3</a></td>
                    <td class="style13"><a href="reports/2011/Nov/04/userauthentication.php?date=NOV-04">4</a></td>
                    <td class="style15"><a href="reports/2011/Nov/05/userauthentication.php?date=NOV-05">5</a></td>
                  </tr>
                  <tr class="style3">
                    <td class="style15"><a href="reports/2011/Nov/06/userauthentication.php?date=NOV-06">6</a></td>
                    <td class="style13"><a href="reports/2011/Nov/07/userauthentication.php?date=NOV-07">7</a></td>
                    <td class="style13"><a href="reports/2011/Nov/08/userauthentication.php?date=NOV-08">8</a></td>
                    <td class="style13"><a href="reports/2011/Nov/09/userauthentication.php?date=NOV-09">9</a></td>
                    <td class="style13"><a href="reports/2011/Nov/10/userauthentication.php?date=NOV-10">10</a></td>
                    <td class="style13"><a href="reports/2011/Nov/11/userauthentication.php?date=NOV-11">11</a></td>
                    <td class="style15"><a href="reports/2011/Nov/12/userauthentication.php?date=NOV-12">12</a></td>
                  </tr>
                  <tr class="style3">
                    <td class="style15"><a href="reports/2011/Nov/13/userauthentication.php?date=NOV-13">13</a></td>
                    <td class="style13"><a href="reports/2011/Nov/14/userauthentication.php?date=NOV-14">14</a></td>
                    <td class="style13"><a href="reports/2011/Nov/15/userauthentication.php?date=NOV-15">15</a></td>
                    <td class="style13"><a href="reports/2011/Nov/16/userauthentication.php?date=NOV-16">16</a></td>
                    <td class="style13"><a href="reports/2011/Nov/17/userauthentication.php?date=NOV-17">17</a></td>
                    <td class="style13"><a href="reports/2011/Nov/18/userauthentication.php?date=NOV-18">18</a></td>
                    <td class="style15"><a href="reports/2011/Nov/19/userauthentication.php?date=NOV-19">19</a></td>
                  </tr>
                  <tr class="style3">
                    <td class="style15"><a href="reports/2011/Nov/20/userauthentication.php?date=NOV-20">20</a></td>
                    <td class="style13"><a href="reports/2011/Nov/21/userauthentication.php?date=NOV-21">21</a></td>
                    <td class="style13"><a href="reports/2011/Nov/22/userauthentication.php?date=NOV-22">22</a></td>
                    <td class="style13"><a href="reports/2011/Nov/23/userauthentication.php?date=NOV-23">23</a></td>
                    <td class="style13"><a href="reports/2011/Nov/24/userauthentication.php?date=NOV-24">24</a></td>
                    <td class="style13"><a href="reports/2011/Nov/25/userauthentication.php?date=NOV-25">25</a></td>
                    <td class="style15"><a href="reports/2011/Nov/26/userauthentication.php?date=NOV-26">26</a></td>
                  </tr>
                  <tr class="style3">
                    <td class="style15"><a href="reports/2011/Nov/27/userauthentication.php?date=NOV-27">27</a></td>
                    <td class="style13"><a href="reports/2011/Nov/28/userauthentication.php?date=NOV-28">28</a></td>
                    <td class="style13"><a href="reports/2011/Nov/29/userauthentication.php?date=NOV-29">29</a></td>
                    <td class="style13"><a href="reports/2011/Nov/30/userauthentication.php?date=NOV-30">30</a></td>
                    <td>31</td>
                    <td>&nbsp;</td>
                    <td class="style15">&nbsp;</td>
                  </tr>
              </table></td>
            <td>&nbsp;</td>
            <td><table width="300" height="20" border="0" cellpadding="0" cellspacing="0">
                <tr>
                  <td width="414" height="13" bgcolor="#E1204F" class="style14"><div align="left"><strong class="style3">June</strong></div></td>
                </tr>
              </table>
                <table width="300" border="0" cellpadding="5" cellspacing="0" bordercolor="#999999">
                  <tr class="style3">
                    <td width="414" class="style15">Sun</td>
                    <td width="414" class="style13">Mon</td>
                    <td width="414" class="style13">Tue</td>
                    <td width="414" class="style13">Wed</td>
                    <td width="414" class="style13">Thu</td>
                    <td width="414" class="style13">Fri</td>
                    <td width="414" class="style15">Sat</td>
                  </tr>
                  <tr class="style3">
                    <td class="style15">&nbsp;</td>
                    <td class="style13">&nbsp;</td>
                    <td class="style13">&nbsp;</td>
                    <td class="style13">&nbsp;</td>
                    <td class="style13">&nbsp;</td>
                    <td class="style13">1</td>
                    <td class="style15">2</td>
                  </tr>
                  <tr class="style3">
                    <td class="style15">3</td>
                    <td class="style13">4</td>
                    <td class="style13">5</td>
                    <td class="style13">6</td>
                    <td class="style13">7</td>
                    <td class="style13">8</td>
                    <td class="style15">9</td>
                  </tr>
                  <tr class="style3">
                    <td class="style15">10</td>
                    <td class="style13"><a href="reports/2011/Jul/11/userauthentication.php">11</a></td>
                    <td class="style13"><a href="reports/2011/Jul/12/userauthentication.php">12</a></td>
                    <td class="style13"><a href="reports/2011/Jul/13/userauthentication.php">13</a></td>
                    <td class="style13"><a href="reports/2011/Jul/14/userauthentication.php">14</a></td>
                    <td class="style13"><a href="reports/2011/Jul/15/userauthentication.php">15</a></td>
                    <td class="style15"><a href="reports/2011/Jul/16/userauthentication.php">16</a></td>
                  </tr>
                  <tr class="style3">
                    <td class="style15"><a href="reports/2011/Jul/17/userauthentication.php">17</a></td>
                    <td class="style13"><a href="reports/2011/Jul/18/userauthentication.php">18</a></td>
                    <td class="style13"><a href="reports/2011/Jul/19/userauthentication.php">19</a></td>
                    <td class="style13"><a href="reports/2011/Jul/20/userauthentication.php">20</a></td>
                    <td class="style13"><a href="reports/2011/Jul/21/userauthentication.php">21</a></td>
                    <td class="style13"><a href="reports/2011/Jul/22/userauthentication.php">22</a></td>
                    <td class="style15"><a href="reports/2011/Jul/23/userauthentication.php">23</a></td>
                  </tr>
                  <tr class="style3">
                    <td class="style15"><a href="reports/2011/Jul/24/userauthentication.php">24</a></td>
                    <td class="style13"><a href="reports/2011/Jul/25/userauthentication.php">25</a></td>
                    <td class="style13"><a href="reports/2011/Jul/26/userauthentication.php">26</a></td>
                    <td class="style13"><a href="reports/2011/Jul/27/userauthentication.php">27</a></td>
                    <td class="style13"><a href="reports/2011/Jul/28/userauthentication.php">28</a></td>
                    <td class="style13"><a href="reports/2011/Jul/29/userauthentication.php">29</a></td>
                    <td class="style15"><a href="reports/2011/Jul/30/userauthentication.php">30</a></td>
                  </tr>
              </table></td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td><table width="300" height="20" border="0" cellpadding="0" cellspacing="0">
                <tr>
                  <td width="414" height="13" bgcolor="#E1204F" class="style14"><div align="left"><strong class="style3">July</strong></div></td>
                </tr>
              </table>
                <table width="300" border="0" cellpadding="5" cellspacing="0" bordercolor="#999999">
                  <tr class="style3">
                    <td width="414" class="style15">Sun</td>
                    <td width="414" class="style13">Mon</td>
                    <td width="414" class="style13">Tue</td>
                    <td width="414" class="style13">Wed</td>
                    <td width="414" class="style13">Thu</td>
                    <td width="414" class="style13">Fri</td>
                    <td width="414" class="style15">Sat</td>
                  </tr>
                  <tr class="style3">
                    <td class="style15">1</td>
                    <td class="style13">2</td>
                    <td class="style13">3</td>
                    <td class="style13">4</td>
                    <td class="style13">5</td>
                    <td class="style13">6</td>
                    <td class="style15">7</td>
                  </tr>
                  <tr class="style3">
                    <td class="style15">8</td>
                    <td class="style13">9</td>
                    <td class="style13">10</td>
                    <td class="style13">11</td>
                    <td class="style13"><a href="2012/jul/12/dct-selectmenu.php?date=12-JUL-2012">12</a></td>
                    <td class="style13">13</td>
                    <td class="style15">14</td>
                  </tr>
                  <tr class="style3">
                    <td class="style15">15</td>
                    <td class="style13">16</td>
                    <td class="style13">17</td>
                    <td class="style13">18</td>
                    <td class="style13">19</td>
                    <td class="style13">20</td>
                    <td class="style15">21</td>
                  </tr>
                  <tr class="style3">
                    <td class="style15">22</td>
                    <td class="style13">23</td>
                    <td class="style13">24</td>
                    <td class="style13">25</td>
                    <td class="style13">26</td>
                    <td class="style13">27</td>
                    <td class="style15">28</td>
                  </tr>
                  <tr class="style3">
                    <td class="style15">29</td>
                    <td class="style13">30</td>
                    <td class="style13">31</td>
                    <td class="style13">&nbsp;</td>
                    <td class="style13">&nbsp;</td>
                    <td class="style13">&nbsp;</td>
                    <td>&nbsp;</td>
                  </tr>
              </table></td>
            <td>&nbsp;</td>
            <td><table width="300" height="20" border="0" cellpadding="0" cellspacing="0">
                <tr>
                  <td width="414" height="13" bgcolor="#E1204F" class="style14"><div align="left"><strong class="style3">August</strong></div></td>
                </tr>
              </table>
                <table width="300" border="0" cellpadding="5" cellspacing="0" bordercolor="#999999">
                  <tr class="style3">
                    <td width="414" class="style15">Sun</td>
                    <td width="414" class="style13">Mon</td>
                    <td width="414" class="style13">Tue</td>
                    <td width="414" class="style13">Wed</td>
                    <td width="414" class="style13">Thu</td>
                    <td width="414" class="style13">Fri</td>
                    <td width="414" class="style15">Sat</td>
                  </tr>
                  <tr class="style3">
                    <td>&nbsp;</td>
                    <td class="style13">&nbsp;</td>
                    <td class="style13">&nbsp;</td>
                    <td class="style13">1</td>
                    <td class="style13">2</td>
                    <td class="style13">3</td>
                    <td class="style15">4</td>
                  </tr>
                  <tr class="style3">
                    <td class="style15">5</td>
                    <td class="style13">6</td>
                    <td class="style13">7</td>
                    <td class="style13">8</td>
                    <td class="style13">9</td>
                    <td class="style13">10</td>
                    <td class="style15">11</td>
                  </tr>
                  <tr class="style3">
                    <td class="style15">12</td>
                    <td class="style13">13</td>
                    <td class="style13">14</td>
                    <td class="style13">15</td>
                    <td class="style13">16</td>
                    <td class="style13">17</td>
                    <td class="style15">18</td>
                  </tr>
                  <tr class="style3">
                    <td class="style15">19</td>
                    <td class="style13">20</td>
                    <td class="style13">21</td>
                    <td class="style13">22</td>
                    <td class="style13">23</td>
                    <td class="style13">24</td>
                    <td class="style15">25</td>
                  </tr>
                  <tr class="style3">
                    <td class="style15">26</td>
                    <td class="style13">27</td>
                    <td class="style13">28</td>
                    <td class="style13">29</td>
                    <td>30</td>
                    <td class="style13">31</td>
                    <td>&nbsp;</td>
                  </tr>
              </table></td>
            <td>&nbsp;</td>
            <td><table width="300" height="20" border="0" cellpadding="0" cellspacing="0">
                <tr>
                  <td width="414" height="13" bgcolor="#E1204F" class="style14"><div align="left"><strong class="style3">September</strong></div></td>
                </tr>
              </table>
                <table width="300" border="0" cellpadding="5" cellspacing="0" bordercolor="#999999">
                  <tr class="style3">
                    <td width="414" class="style15">Sun</td>
                    <td width="414" class="style13">Mon</td>
                    <td width="414" class="style13">Tue</td>
                    <td width="414" class="style13">Wed</td>
                    <td width="414" class="style13">Thu</td>
                    <td width="414" class="style13">Fri</td>
                    <td width="414" class="style15">Sat</td>
                  </tr>
                  <tr class="style3">
                    <td class="style15"><a href="reports/2011/Oct/30/userauthentication.php?date=OCT-30">30</a></td>
                    <td class="style13">&nbsp;</td>
                    <td class="style13">&nbsp;</td>
                    <td class="style13">&nbsp;</td>
                    <td class="style13">&nbsp;</td>
                    <td class="style13">&nbsp;</td>
                    <td class="style15"><a href="reports/2011/Oct/01/userauthentication.php?date=OCT-01">1</a></td>
                  </tr>
                  <tr class="style3">
                    <td class="style15"><a href="reports/2011/Oct/02/userauthentication.php?date=OCT-02">2</a></td>
                    <td class="style13"><a href="reports/2011/Oct/03/userauthentication.php?date=OCT-03">3</a></td>
                    <td class="style13"><a href="reports/2011/Oct/04/userauthentication.php?date=OCT-04">4</a></td>
                    <td class="style13"><a href="reports/2011/Oct/05/userauthentication.php?date=OCT-05">5</a></td>
                    <td class="style13"><a href="reports/2011/Oct/06/userauthentication.php?date=OCT-06">6</a></td>
                    <td class="style13"><a href="reports/2011/Oct/07/userauthentication.php?date=OCT-07">7</a></td>
                    <td class="style15"><a href="reports/2011/Oct/08/userauthentication.php?date=OCT-08">8</a></td>
                  </tr>
                  <tr class="style3">
                    <td class="style15"><a href="reports/2011/Oct/09/userauthentication.php?date=OCT-09">9</a></td>
                    <td class="style13"><a href="reports/2011/Oct/10/userauthentication.php?date=OCT-10">10</a></td>
                    <td class="style13"><a href="reports/2011/Oct/11/userauthentication.php?date=OCT-11">11</a></td>
                    <td class="style13"><a href="reports/2011/Oct/12/userauthentication.php?date=OCT-12">12</a></td>
                    <td class="style13"><a href="reports/2011/Oct/13/userauthentication.php?date=OCT-13">13</a></td>
                    <td class="style13"><a href="reports/2011/Oct/14/userauthentication.php?date=OCT-14">14</a></td>
                    <td class="style15"><a href="reports/2011/Oct/15/userauthentication.php?date=OCT-15">15</a></td>
                  </tr>
                  <tr class="style3">
                    <td class="style15"><a href="reports/2011/Oct/16/userauthentication.php?date=OCT-16">16</a></td>
                    <td class="style13"><a href="reports/2011/Oct/17/userauthentication.php?date=OCT-17">17</a></td>
                    <td class="style13"><a href="reports/2011/Oct/18/userauthentication.php?date=OCT-18">18</a></td>
                    <td class="style13"><a href="reports/2011/Oct/19/userauthentication.php?date=OCT-19">19</a></td>
                    <td class="style13"><a href="reports/2011/Oct/20/userauthentication.php?date=OCT-20">20</a></td>
                    <td class="style13"><a href="reports/2011/Oct/21/userauthentication.php?date=OCT-21">21</a></td>
                    <td class="style15"><a href="reports/2011/Oct/22/userauthentication.php?date=OCT-22">22</a></td>
                  </tr>
                  <tr class="style3">
                    <td class="style15"><a href="reports/2011/Oct/23/userauthentication.php?date=OCT-23">23</a></td>
                    <td class="style13"><a href="reports/2011/Oct/24/userauthentication.php?date=OCT-24">24</a></td>
                    <td class="style13"><a href="reports/2011/Oct/25/userauthentication.php?date=OCT-25">25</a></td>
                    <td class="style13"><a href="reports/2011/Oct/26/userauthentication.php?date=OCT-26">26</a></td>
                    <td class="style13"><a href="reports/2011/Oct/27/userauthentication.php?date=OCT-27">27</a></td>
                    <td class="style13"><a href="reports/2011/Oct/28/userauthentication.php?date=OCT-28">28</a></td>
                    <td class="style15"><a href="reports/2011/Oct/29/userauthentication.php?date=OCT-29" >29</a></td>
                  </tr>
              </table></td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td><table width="300" height="20" border="0" cellpadding="0" cellspacing="0">
                <tr>
                  <td width="414" height="13" bgcolor="#E1204F" class="style14"><div align="left"><strong class="style3">October</strong></div></td>
                </tr>
              </table>
                <table width="300" border="0" cellpadding="5" cellspacing="0" bordercolor="#999999">
                  <tr class="style3">
                    <td width="414" class="style15">Sun</td>
                    <td width="414" class="style13">Mon</td>
                    <td width="414" class="style13">Tue</td>
                    <td width="414" class="style13">Wed</td>
                    <td width="414" class="style13">Thu</td>
                    <td width="414" class="style13">Fri</td>
                    <td width="414" class="style15">Sat</td>
                  </tr>
                  <tr class="style3">
                    <td>&nbsp;</td>
                    <td class="style13"><a href="reports/2011/Aug/01/userauthentication.php">1</a></td>
                    <td class="style13"><a href="reports/2011/Aug/02/userauthentication.php">2</a></td>
                    <td class="style13"><a href="reports/2011/Aug/03/userauthentication.php">3</a></td>
                    <td class="style13"><a href="reports/2011/Aug/04/userauthentication.php">4</a></td>
                    <td class="style13"><a href="reports/2011/Aug/05/userauthentication.php">5</a></td>
                    <td class="style15"><a href="reports/2011/Aug/06/userauthentication.php">6</a></td>
                  </tr>
                  <tr class="style3">
                    <td class="style15"><a href="reports/2011/Aug/07/userauthentication.php">7</a></td>
                    <td class="style13">8</td>
                    <td class="style13"><a href="reports/2011/Aug/09/userauthentication.php">9</a></td>
                    <td class="style13"><a href="reports/2011/Aug/10/userauthentication.php">10</a></td>
                    <td class="style13"><a href="reports/2011/Aug/11/userauthentication.php">11</a></td>
                    <td class="style13"><a href="reports/2011/Aug/12/userauthentication.php">12</a></td>
                    <td class="style15"><a href="reports/2011/Aug/13/userauthentication.php">13</a></td>
                  </tr>
                  <tr class="style3">
                    <td class="style15"><a href="reports/2011/Aug/14/userauthentication.php">14</a></td>
                    <td class="style13"><a href="reports/2011/Aug/15/userauthentication.php">15</a></td>
                    <td class="style13"><a href="reports/2011/Aug/16/userauthentication.php">16</a></td>
                    <td class="style13"><a href="reports/2011/Aug/17/userauthentication.php">17</a></td>
                    <td class="style13"><a href="reports/2011/Aug/18/userauthentication.php">18</a></td>
                    <td class="style13"><a href="reports/2011/Aug/19/userauthentication.php">19</a></td>
                    <td class="style15"><a href="reports/2011/Aug/20/userauthentication.php">20</a></td>
                  </tr>
                  <tr class="style3">
                    <td class="style15"><a href="reports/2011/Aug/21/userauthentication.php">21</a></td>
                    <td class="style13"><a href="reports/2011/Aug/22/userauthentication.php">22</a></td>
                    <td class="style13"><a href="reports/2011/Aug/23/userauthentication.php">23</a></td>
                    <td class="style13"><a href="reports/2011/Aug/24/userauthentication.php">24</a></td>
                    <td class="style13"><a href="reports/2011/Aug/25/userauthentication.php">25</a></td>
                    <td class="style13"><a href="reports/2011/Aug/26/userauthentication.php">26</a></td>
                    <td class="style15"><a href="reports/2011/Aug/27/userauthentication.php">27</a></td>
                  </tr>
                  <tr class="style3">
                    <td class="style15"><a href="reports/2011/Aug/28/userauthentication.php">28</a></td>
                    <td class="style13"><a href="reports/2011/Aug/29/userauthentication.php">29</a></td>
                    <td class="style13"><a href="reports/2011/Aug/30/userauthentication.php">30</a></td>
                    <td class="style13"><a href="reports/2011/Aug/31/userauthentication.php">31</a></td>
                    <td class="style13">&nbsp;</td>
                    <td class="style13">&nbsp;</td>
                    <td>&nbsp;</td>
                  </tr>
              </table></td>
            <td>&nbsp;</td>
            <td><table width="300" height="20" border="0" cellpadding="0" cellspacing="0">
                <tr>
                  <td width="414" height="13" bgcolor="#E1204F" class="style14"><div align="left"><strong class="style3">November</strong></div></td>
                </tr>
              </table>
                <table width="300" border="0" cellpadding="5" cellspacing="0" bordercolor="#999999">
                  <tr class="style3">
                    <td width="414" class="style15">Sun</td>
                    <td width="414" class="style13">Mon</td>
                    <td width="414" class="style13">Tue</td>
                    <td width="414" class="style13">Wed</td>
                    <td width="414" class="style13">Thu</td>
                    <td width="414" class="style13">Fri</td>
                    <td width="414" class="style15">Sat</td>
                  </tr>
                  <tr class="style3">
                    <td>&nbsp;</td>
                    <td class="style13">&nbsp;</td>
                    <td class="style13">&nbsp;</td>
                    <td class="style13">&nbsp;</td>
                    <td class="style13"><a href="reports/2011/Sep/01/userauthentication.php">1</a></td>
                    <td class="style13"><a href="reports/2011/Sep/02/userauthentication.php">2</a></td>
                    <td class="style15"><a href="reports/2011/Sep/03/userauthentication.php">3</a></td>
                  </tr>
                  <tr class="style3">
                    <td class="style15"><a href="reports/2011/Sep/04/userauthentication.php">4</a></td>
                    <td class="style13"><a href="reports/2011/Sep/05/userauthentication.php">5</a></td>
                    <td><a href="reports/2011/Sep/06/userauthentication.php"><span class="style13">6</span></a></td>
                    <td class="style13"><a href="reports/2011/Sep/07/userauthentication.php">7</a></td>
                    <td class="style13"><a href="reports/2011/Sep/08/userauthentication.php">8</a></td>
                    <td class="style13"><a href="reports/2011/Sep/09/userauthentication.php">9</a></td>
                    <td class="style15"><a href="reports/2011/Sep/10/userauthentication.php">10</a></td>
                  </tr>
                  <tr class="style3">
                    <td class="style15"><a href="reports/2011/Sep/11/userauthentication.php">11</a></td>
                    <td class="style13"><a href="reports/2011/Sep/12/userauthentication.php">12</a></td>
                    <td class="style13"><a href="reports/2011/Sep/13/userauthentication.php">13</a></td>
                    <td class="style13"><a href="reports/2011/Sep/14/userauthentication.php">14</a></td>
                    <td class="style13"><a href="reports/2011/Sep/15/userauthentication.php">15</a></td>
                    <td class="style13"><a href="reports/2011/Sep/16/userauthentication.php">16</a></td>
                    <td class="style15"><a href="reports/2011/Sep/17/userauthentication.php">17</a></td>
                  </tr>
                  <tr class="style3">
                    <td class="style15"><a href="reports/2011/Sep/18/userauthentication.php">18</a></td>
                    <td class="style13"><a href="reports/2011/Sep/19/userauthentication.php">19</a></td>
                    <td class="style13"><a href="reports/2011/Sep/20/userauthentication.php">20</a></td>
                    <td class="style13"><a href="reports/2011/Sep/21/userauthentication.php">21</a></td>
                    <td class="style13"><a href="reports/2011/Sep/22/userauthentication.php">22</a></td>
                    <td class="style13"><a href="reports/2011/Sep/23/userauthentication.php">23</a></td>
                    <td class="style15"><a href="reports/2011/Sep/24/userauthentication.php">24</a></td>
                  </tr>
                  <tr class="style3">
                    <td class="style15"><a href="reports/2011/Sep/25/userauthentication.php">25</a></td>
                    <td class="style13"><a href="reports/2011/Sep/26/userauthentication.php">26</a></td>
                    <td class="style13"><a href="reports/2011/Sep/27/userauthentication.php">27</a></td>
                    <td class="style13"><a href="reports/2011/Sep/28/userauthentication.php">28</a></td>
                    <td class="style13"><a href="reports/2011/Sep/29/userauthentication.php">29</a></td>
                    <td class="style13"><a href="reports/2011/Sep/30/userauthentication.php?date=SEP-30">30</a></td>
                    <td>&nbsp;</td>
                  </tr>
              </table></td>
            <td>&nbsp;</td>
            <td><table width="300" height="20" border="0" cellpadding="0" cellspacing="0">
                <tr>
                  <td width="414" height="13" bgcolor="#E1204F" class="style14"><div align="left"><strong class="style3">December</strong></div></td>
                </tr>
              </table>
                <table width="300" border="0" cellpadding="5" cellspacing="0" bordercolor="#999999">
                  <tr class="style3">
                    <td width="414" class="style15">Sun</td>
                    <td width="414" class="style13">Mon</td>
                    <td width="414" class="style13">Tue</td>
                    <td width="414" class="style13">Wed</td>
                    <td width="414" class="style13">Thu</td>
                    <td width="414" class="style13">Fri</td>
                    <td width="414" class="style15">Sat</td>
                  </tr>
                  <tr class="style3">
                    <td class="style15"><a href="reports/2011/Oct/30/userauthentication.php?date=OCT-30">30</a></td>
                    <td class="style13"><a href="reports/2011/Oct/31/userauthentication.php?date=OCT-31">31</a></td>
                    <td class="style13">&nbsp;</td>
                    <td class="style13">&nbsp;</td>
                    <td class="style13">&nbsp;</td>
                    <td class="style13">&nbsp;</td>
                    <td class="style15"><a href="reports/2011/Oct/01/userauthentication.php?date=OCT-01">1</a></td>
                  </tr>
                  <tr class="style3">
                    <td class="style15"><a href="reports/2011/Oct/02/userauthentication.php?date=OCT-02">2</a></td>
                    <td class="style13"><a href="reports/2011/Oct/03/userauthentication.php?date=OCT-03">3</a></td>
                    <td class="style13"><a href="reports/2011/Oct/04/userauthentication.php?date=OCT-04">4</a></td>
                    <td class="style13"><a href="reports/2011/Oct/05/userauthentication.php?date=OCT-05">5</a></td>
                    <td class="style13"><a href="reports/2011/Oct/06/userauthentication.php?date=OCT-06">6</a></td>
                    <td class="style13"><a href="reports/2011/Oct/07/userauthentication.php?date=OCT-07">7</a></td>
                    <td class="style15"><a href="reports/2011/Oct/08/userauthentication.php?date=OCT-08">8</a></td>
                  </tr>
                  <tr class="style3">
                    <td class="style15"><a href="reports/2011/Oct/09/userauthentication.php?date=OCT-09">9</a></td>
                    <td class="style13"><a href="reports/2011/Oct/10/userauthentication.php?date=OCT-10">10</a></td>
                    <td class="style13"><a href="reports/2011/Oct/11/userauthentication.php?date=OCT-11">11</a></td>
                    <td class="style13"><a href="reports/2011/Oct/12/userauthentication.php?date=OCT-12">12</a></td>
                    <td class="style13"><a href="reports/2011/Oct/13/userauthentication.php?date=OCT-13">13</a></td>
                    <td class="style13"><a href="reports/2011/Oct/14/userauthentication.php?date=OCT-14">14</a></td>
                    <td class="style15"><a href="reports/2011/Oct/15/userauthentication.php?date=OCT-15">15</a></td>
                  </tr>
                  <tr class="style3">
                    <td class="style15"><a href="reports/2011/Oct/16/userauthentication.php?date=OCT-16">16</a></td>
                    <td class="style13"><a href="reports/2011/Oct/17/userauthentication.php?date=OCT-17">17</a></td>
                    <td class="style13"><a href="reports/2011/Oct/18/userauthentication.php?date=OCT-18">18</a></td>
                    <td class="style13"><a href="reports/2011/Oct/19/userauthentication.php?date=OCT-19">19</a></td>
                    <td class="style13"><a href="reports/2011/Oct/20/userauthentication.php?date=OCT-20">20</a></td>
                    <td class="style13"><a href="reports/2011/Oct/21/userauthentication.php?date=OCT-21">21</a></td>
                    <td class="style15"><a href="reports/2011/Oct/22/userauthentication.php?date=OCT-22">22</a></td>
                  </tr>
                  <tr class="style3">
                    <td class="style15"><a href="reports/2011/Oct/23/userauthentication.php?date=OCT-23">23</a></td>
                    <td class="style13"><a href="reports/2011/Oct/24/userauthentication.php?date=OCT-24">24</a></td>
                    <td class="style13"><a href="reports/2011/Oct/25/userauthentication.php?date=OCT-25">25</a></td>
                    <td class="style13"><a href="reports/2011/Oct/26/userauthentication.php?date=OCT-26">26</a></td>
                    <td class="style13"><a href="reports/2011/Oct/27/userauthentication.php?date=OCT-27">27</a></td>
                    <td class="style13"><a href="reports/2011/Oct/28/userauthentication.php?date=OCT-28">28</a></td>
                    <td class="style15"><a href="reports/2011/Oct/29/userauthentication.php?date=OCT-29" >29</a></td>
                  </tr>
              </table></td>
            <td>&nbsp;</td>
          </tr>
        </table>
        <br/>
        <br/>
        <br/>
    </div>
    </td>
  </tr>
</table>
<p>&nbsp;</p>
</body>
</html>
