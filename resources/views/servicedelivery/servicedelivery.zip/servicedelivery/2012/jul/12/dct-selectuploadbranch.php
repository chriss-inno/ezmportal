<?php
session_start();
$user_id       = $_SESSION['SESS_USER_ID'];
$log_ipaddress = $_SERVER['REMOTE_ADDR']; 
$log_compuser  = gethostbyaddr($_SERVER['REMOTE_ADDR']);
$log_datetime  = date("d/m/y : H:i:s", time());
$log_activity  = "UploadBranchViewSelectionMenu";
$log_comment   = "DocumentServerBranches";
mysql_connect("localhost","root",""); 
mysql_select_db("bmpl_system") or die("Unable to select database");
@mysql_query("INSERT INTO sys_log(user_id, log_datetime, log_activity, log_comment, log_ipaddress, log_compuser)
VALUES('$user_id','$log_datetime','$log_activity','$log_comment','$log_ipaddress', '$log_compuser')");	
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Report Calender -2011</title>
<style type="text/css">
<!--
.style2 {
	color: #0E3793;
	font-weight: bold;
}
.style3 {
	font-size: 11px;
	font-family: tahoma;
	color: #FFFFFF;
}
a:link {
	color: #FFFFFF;
	text-decoration: none;
}
a:visited {
	color: #FFFFFF;
	text-decoration: none;
}
a:hover {
	color: #FF0000;
	text-decoration: none;
}
a:active {
	color: #FFFFFF;
	text-decoration: none;
}
body {
	background-image: url(js/swfupload/pagebg.png);
}
.style32 {font-family: tahoma; font-size: 11px; color: #0E3793; }
.style32 {font-family: tahoma; font-size: 11px; color: #0E3793; }
.style37 {font-size: 11px}
.style37 {font-size: 11px}
.style40 {color: #FFFFFF}
-->
</style>
</head>

<body>
<table width="100%" border="0" cellpadding="5" cellspacing="0">
  <tr>
    <td></td>
  </tr>
</table>
<table width="100%"  border="0" align="center" cellpadding="0" cellspacing="0" style="border-left: 1px solid #7F9DB9; border-right: 1px solid #7F9DB9; border-top: 1px solid #7F9DB9; border-bottom: 1px solid #7F9DB9;">
  <tr>
    <td width="95%" height="20" nowrap ><table width="100%" height="20"  border="0" align="center" cellpadding="0" cellspacing="0" style="border-bottom: 1px solid #7F9DB9;">
        <tr >
          <td width="96%" height="19" nowrap bgcolor="#E1204F"><span class="style2">&nbsp;<span class="style3">DOCUMENT SERVER - UPLOAD </span></span></td>
        </tr>
    </table></td>
  </tr>
  <tr>
    <td height="19" valign="top" nowrap>&nbsp;</td>
  </tr>
  <tr>
    <td height="50" valign="top" nowrap><table width="60%" height="50"  border="0" align="left"  cellpadding="0" cellspacing="0" class="style32" >
        <tr class="style37">
          <td width="4%"  nowrap >&nbsp;</td>
          <td width="96%" height="25"  nowrap ><div align="left"><span class="style2"><span class="style3">Upload Document from Branch</span></span></div></td>
        </tr>
        <tr class="style37">
          <td  nowrap >&nbsp;</td>
          <td height="25"  nowrap ><table width="60%" height="25"  border="0" align="left"  cellpadding="0" cellspacing="0" class="style32" >
              <tr class="style37">
                <td width="11%"  nowrap class="style40" ><div align="center">1</div></td>
                <td width="89%" height="25"  nowrap ><span class="style40"><a href="HeadOffice-upload.html">Head Office </a></span></td>
              </tr>
          </table></td>
        </tr>
      </table>
    <p>&nbsp;</p></td>
  </tr>
</table>
<p>&nbsp;</p>
</body>
</html>
