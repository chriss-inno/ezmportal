<?php
session_start();
$user_id       = $_SESSION['SESS_USER_ID'];
$log_ipaddress = $_SERVER['REMOTE_ADDR']; 
$log_compuser  = gethostbyaddr($_SERVER['REMOTE_ADDR']);
$log_datetime  = date("d/m/y : H:i:s", time());
$log_activity  = "FileUploadedToHQ";
$log_comment   = "FileUpload";
mysql_connect("localhost","root",""); 
mysql_select_db("bmpl_system") or die("Unable to select database");
@mysql_query("INSERT INTO sys_log(user_id, log_datetime, log_activity, log_comment, log_ipaddress, log_compuser)
VALUES('$user_id','$log_datetime','$log_activity','$log_comment','$log_ipaddress', '$log_compuser')");	


$uploaddir = './headoffice-files/'; 
$file = $uploaddir . basename($_FILES['uploadfile']['name']); 
$size=$_FILES['uploadfile']['size'];
if($size>1048576)
{
	echo "error file size > 3 MB";
	unlink($_FILES['uploadfile']['tmp_name']);
	exit;
}
if (move_uploaded_file($_FILES['uploadfile']['tmp_name'], $file)) { 
  echo "success"; 
} else {
	echo "error ".$_FILES['uploadfile']['error']." --- ".$_FILES['uploadfile']['tmp_name']." %%% ".$file."($size)";
}
?>