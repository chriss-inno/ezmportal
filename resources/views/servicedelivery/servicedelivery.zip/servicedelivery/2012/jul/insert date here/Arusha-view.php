<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Untitled Document</title>
<style type="text/css">
<!--
.style2 {color: #0E3793;
	font-weight: bold;
}
.style3 {font-size: 11px;
	font-family: tahoma;
	color: #FFFFFF;
}
body {
	background-image: url(js/swfupload/pagebg.png);
}
.style5 {font-size: 14px}
.style6 {color: #FFFFFF; font-family: tahoma;}
a:link {
	color: #FFFFFF;
}
a:visited {
	color: #FFFFFF;
}
a:hover {
	color: #FF0000;
}
a:active {
	color: #FFFFFF;
}
.style7 {font-size: 11px}
-->
</style>
</head>

<body>
<table width="100%" border="0" cellpadding="5" cellspacing="0">
  <tr>
    <td></td>
  </tr>
</table>
<table width="100%"  border="0" align="center" cellpadding="0" cellspacing="0" style="border-left: 1px solid #7F9DB9; border-right: 1px solid #7F9DB9; border-top: 1px solid #7F9DB9; border-bottom: 1px solid #7F9DB9;">
  <tr>
    <td width="95%" height="20" nowrap="nowrap" ><table width="100%" height="28"  border="0" align="center" cellpadding="0" cellspacing="0" style="border-bottom: 1px solid #7F9DB9;">
        <tr >
          <td width="96%" height="27" nowrap="nowrap" bgcolor="#E1204F"><span class="style2">&nbsp;<span class="style3">VIEW DOCUMENT </span></span></td>
        </tr>
    </table></td>
  </tr>
  <tr>
    <td height="95" valign="top" nowrap="nowrap"><div align="left" class="style5"><span class="style6">
        </span></div>        
      <table width="100%"  border="0" align="center" cellpadding="0" cellspacing="0">
        <tr>
          <td width="2%" valign="top" nowrap="nowrap">&nbsp;</td>
          <td width="96%" valign="top" nowrap="nowrap"><span class="style5"><span class="style6">
            <?php
 if ($handle = opendir('arusha-files/')) {
   while (false !== ($file = readdir($handle)))
      {
          if ($file != "." && $file != "..")
	  {
          	$thelist .= '<a href="arusha-files/'.$file.'" target="_blank" >'.$file.'</a><br/><br/>';
          }
       }
  closedir($handle);
  }
?>
          </span></span></td>
          <td width="2%" height="19" valign="top" nowrap="nowrap"><div align="left" class="style5"><span class="style6">
          </span> </div></td>
        </tr>
        <tr>
          <td valign="top" nowrap="nowrap">&nbsp;</td>
          <td valign="top" nowrap="nowrap" bgcolor="#E1204F"><span class="style3 style7">List of files:</span></td>
          <td height="19" valign="top" nowrap="nowrap">&nbsp;</td>
        </tr>
        <tr>
          <td valign="top" nowrap="nowrap">&nbsp;</td>
          <td valign="top" nowrap="nowrap">&nbsp;</td>
          <td height="19" valign="top" nowrap="nowrap">&nbsp;</td>
        </tr>
        <tr>
          <td valign="top" nowrap="nowrap">&nbsp;</td>
          <td valign="top" nowrap="nowrap"><span class="style3">
            <?=$thelist?>
          </span></td>
          <td height="19" valign="top" nowrap="nowrap"><span class="style3">
          </span> </td>
        </tr>
      </table>      
    <P align="left">&nbsp; </p></td>
  </tr>
</table>
</body>
</html>
